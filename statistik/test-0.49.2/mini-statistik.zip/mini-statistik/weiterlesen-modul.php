<?php
/** Modul Weiterlesen und Exit-Popup (1AB). Kein eigenes Plugin: wird aus der Mini-Statistik per require_once geladen.
 *  Einbau: require_once __DIR__.'/1ab-weiterlesen-modul.php'; AB1_Weiterlesen::init(); register_activation_hook(..., array('AB1_Weiterlesen','aktivieren'));
 *  Reiter: AB1_Weiterlesen::tab(); Filter: ab1_wl_eigenes_menue (false = kein eigenes Einstellungen-Menü), ab1_wl_seiten_url (URL des Reiters). */
if (!defined('ABSPATH')) exit;

class AB1_Weiterlesen {
    const VERSION = '0.2.0';
    const OPT = 'ab1_wl_opt';
    const REST = 'ab1-wl/v1';
    const SEITEN_OHNE_POPUP = 'impressum|datenschutz|kontakt|privacy|aviso-legal|mentions-legales|legal';

    /* ---------- Reine Funktionen (ohne WordPress, testbar) ---------- */

    /** Wörter eines Titels, klein, ohne Kurzwörter. */
    public static function woerter($t) {
        $t = function_exists('mb_strtolower') ? mb_strtolower((string) $t) : strtolower((string) $t);
        preg_match_all('/[\p{L}\p{N}]{4,}/u', $t, $m);
        return array_values(array_unique($m[0]));
    }

    /** Wichtigste Wörter eines Artikeltextes (Häufigkeit), für die Textähnlichkeit. */
    public static function textwoerter($html, $n = 15) {
        $html = preg_replace('#<(script|style)[^>]*>.*?</\\1>#is', ' ', (string) $html);
        $html = str_replace('<', ' <', $html);
        $t = function_exists('mb_strtolower') ? mb_strtolower(strip_tags($html)) : strtolower(strip_tags($html));
        preg_match_all('/[\p{L}]{5,}/u', $t, $m);
        $stop = array_flip(array('dieser', 'diese', 'dieses', 'werden', 'wurde', 'wurden', 'haben', 'einen', 'einem', 'einer', 'können', 'sollte', 'sollten', 'auch', 'oder', 'aber', 'dabei', 'damit', 'durch', 'weil', 'wenn', 'dann', 'noch', 'schon', 'mehr', 'sehr', 'ihre', 'ihren', 'immer', 'viele', 'sowie', 'which', 'their', 'about', 'there', 'would', 'could', 'avec', 'pour', 'dans', 'nous', 'vous', 'cette', 'para', 'como', 'pero', 'esta'));
        $z = array();
        foreach ($m[0] as $w) { if (!isset($stop[$w])) $z[$w] = ($z[$w] ?? 0) + 1; }
        arsort($z);
        return array_slice(array_keys($z), 0, $n);
    }

    /** Qualitätswert 0..1 aus Scrolltiefe (%), Verweildauer (s) und Klickrate. */
    public static function qualitaet_wert($scroll, $sekunden, $klickrate = 0) {
        return 0.4 * min(max($scroll, 0) / 100, 1) + 0.4 * min(max($sekunden, 0) / 180, 1) + 0.2 * min(max($klickrate, 0) * 20, 1);
    }

    /** Kartenzahlen für die Varianten A bis D aus "3,4,5,6". */
    public static function kartenzahlen($str) {
        $z = array();
        foreach (explode(',', (string) $str) as $x) { $x = (int) trim($x); if ($x >= 1 && $x <= 8 && !in_array($x, $z, true)) $z[] = $x; }
        sort($z);
        return array_slice($z ?: array(4), 0, 4);
    }

    /** Klickrate je Variante, bereinigt um die Grundbeliebtheit jedes Zielartikels. $s[v][ziel]=gezeigt, $c[v][ziel]=Klicks. */
    public static function normalisiere(array $s, array $c) {
        $sz = array(); $cz = array();
        foreach ($s as $zs) foreach ($zs as $z => $n) $sz[$z] = ($sz[$z] ?? 0) + $n;
        foreach ($c as $zs) foreach ($zs as $z => $n) $cz[$z] = ($cz[$z] ?? 0) + $n;
        $out = array();
        foreach ($s as $v => $zs) {
            $erw = 0; $ist = 0;
            foreach ($zs as $z => $n) { $r = !empty($sz[$z]) ? ($cz[$z] ?? 0) / $sz[$z] : 0; $erw += $n * $r; $ist += $c[$v][$z] ?? 0; }
            $out[$v] = array('erwartet' => $erw, 'klicks' => $ist, 'lift' => $erw > 0 ? $ist / $erw : null);
        }
        return $out;
    }

    /** Ähnlichkeitswert zweier Artikel. Mehr = passender. */
    public static function bewerte(array $a, array $b, $gewicht = 0) {
        $kat = count(array_intersect($a['kat'], $b['kat']));
        $tag = count(array_intersect($a['tag'], $b['tag']));
        $wa = self::woerter($a['titel']); $wb = self::woerter($b['titel']);
        $u = count(array_unique(array_merge($wa, $wb)));
        $jac = $u ? count(array_intersect($wa, $wb)) / $u : 0;
        $text = 0;
        if (!empty($a['wort']) && !empty($b['wort'])) {
            $uw = count(array_unique(array_merge($a['wort'], $b['wort'])));
            $text = $uw ? count(array_intersect($a['wort'], $b['wort'])) / $uw : 0;
        }
        return 3 * $kat + 2 * $tag + 5 * $jac + 6 * $text + (float) $gewicht;
    }

    /** Themengruppen aus Text: je Zeile "Name: wort1, wort2". Rückgabe slug => array('name'=>..., 'woerter'=>[...]). */
    public static function themen_parsen($str) {
        $out = array();
        foreach (preg_split('/\r?\n/', (string) $str) as $zeile) {
            if (strpos($zeile, ':') === false) continue;
            list($name, $w) = array_map('trim', explode(':', $zeile, 2));
            $slug = trim(preg_replace('/[^a-z0-9]+/', '', strtolower(strtr(function_exists('mb_strtolower') ? mb_strtolower($name) : $name, array('ä' => 'ae', 'ö' => 'oe', 'ü' => 'ue', 'ß' => 'ss', 'é' => 'e', 'è' => 'e', 'ñ' => 'n')))));
            $woerter = self::liste_woerter($w);
            if ($slug === '' || !$woerter || isset($out[$slug])) continue;
            $out[$slug] = array('name' => $name, 'woerter' => $woerter);
        }
        return $out;
    }

    /** Thema aus Zählungen je Gruppe ($z[slug]=Treffer): Gruppen-Kürzel, 'mix' (mehrere Themen gleichstark) oder '' (kein klares Thema). */
    public static function thema_aus_zaehlungen(array $z) {
        arsort($z);
        $summe = array_sum($z);
        if ($summe < 3) return '';
        $k = array_keys($z); $v = array_values($z);
        $zweit = $v[1] ?? 0;
        return $v[0] >= 2 * $zweit ? $k[0] : 'mix';
    }

    /** Darf ein Push-Platz mit Thema $push ('alle' oder Gruppen-Kürzel) unter einem Artikel mit Thema $art stehen? */
    public static function thema_passt($art, $push) {
        if ($push === '' || $push === 'alle' || $art === '' || $art === 'mix') return true;
        return $art === $push;
    }

    /** Wörter einer Liste "a,b,c", klein, ohne Leerstellen. */
    public static function liste_woerter($str) {
        $x = function_exists('mb_strtolower') ? mb_strtolower((string) $str) : strtolower((string) $str);
        return array_values(array_filter(array_map('trim', explode(',', $x)), 'strlen'));
    }

    /** Harte Regeln: darf $b unter $a stehen? */
    public static function darf_verlinken(array $a, array $b) {
        if ($a['id'] === $b['id']) return false;                       // keine Selbstverlinkung
        if ($b['noindex']) return false;                               // nichts auf noindex
        if ($a['sprache'] !== $b['sprache']) return false;             // nie Sprachen mischen
        if ($a['kat'] && !array_intersect($a['kat'], $b['kat'])) return false; // gleiches Thema
        $ta = $a['thema'] ?? ''; $tb = $b['thema'] ?? '';
        if ($ta !== '' && $ta !== 'mix' && $tb !== '' && $tb !== 'mix' && $ta !== $tb) return false; // verschiedene Themengruppen nie mischen (z. B. Maulwurf und Wühlmaus)
        if ($a['fokus'] !== '' && $a['fokus'] === $b['fokus']) return false;   // Kannibalisierung
        return true;
    }

    /** Offene Blockelemente im HTML-Stück? Nur zwischen Top-Level-Absätzen einfügen. */
    public static function ist_toplevel($html) {
        foreach (array('ul', 'ol', 'table', 'div', 'figure', 'blockquote', 'section', 'aside', 'svg', 'details', 'script', 'style') as $t) {
            $auf = preg_match_all('/<' . $t . '[\s>]/i', $html);
            $zu = preg_match_all('/<\/' . $t . '>/i', $html);
            if ($auf !== $zu) return false;
        }
        return true;
    }

    /** Teaser nach dem n-ten Top-Level-Absatz einfügen, sonst unverändert. */
    public static function fuege_nach_absatz($inhalt, $html, $n) {
        $teile = preg_split('/(<\/p>)/i', $inhalt, -1, PREG_SPLIT_DELIM_CAPTURE);
        $absatz = 0; $vor = '';
        for ($i = 0; $i < count($teile); $i += 2) {
            $vor .= $teile[$i] . ($teile[$i + 1] ?? '');
            if (isset($teile[$i + 1])) {
                $absatz++;
                if ($absatz >= $n && self::ist_toplevel($vor)) {
                    return $vor . $html . implode('', array_slice($teile, $i + 2));
                }
            }
        }
        return $inhalt;
    }

    /** Wilson-Untergrenze/Obergrenze (95 %) für Klickraten. */
    public static function wilson($k, $n) {
        if ($n <= 0) return array(0, 0);
        $z = 1.96; $p = $k / $n;
        $d = 1 + $z * $z / $n;
        $m = ($p + $z * $z / (2 * $n)) / $d;
        $h = $z * sqrt($p * (1 - $p) / $n + $z * $z / (4 * $n * $n)) / $d;
        return array(max(0, $m - $h), min(1, $m + $h));
    }

    /** Wöchentlich wechselnde Kennung aus IP und Browser, nicht umkehrbar. */
    public static function kennung($ip, $ua, $geheim, $zeit) {
        $salz = hash_hmac('sha256', (string) floor($zeit / 604800), $geheim);
        return hash_hmac('sha256', $ip . '|' . $ua, $salz);
    }

    /** Popup-Variante aus Kennung und Tageszahl: wechselt täglich, nichts im Browser. */
    public static function popup_variante($kennung, $tageszahl, array $verfuegbar) {
        $verfuegbar = array_values($verfuegbar);
        if (!$verfuegbar) return '';
        $h = hash('sha256', $kennung . '|' . (int) $tageszahl);
        return $verfuegbar[hexdec(substr($h, 0, 8)) % count($verfuegbar)];
    }

    /* ---------- Einstellungen ---------- */

    /** Titel ohne HTML-Entitäten (z. B. &#038; wird zu &), damit esc_html nicht doppelt umwandelt. */
    public static function titel($id) {
        return html_entity_decode(wp_strip_all_tags(get_the_title($id)), ENT_QUOTES, 'UTF-8');
    }

    public static function std() {
        return array(
            'weiterlesen' => 0, 'popup' => 0, 'anzahl' => 4, 'ueberschrift' => 'Weiterlesen',
            'push' => array(), 'push_thema' => array(), 'push_sperre' => '', 'themen' => '',
            'push_themenfrei' => 1, 'ab' => 1,
            'teaser_oben' => 0, 'teaser_absatz' => 3,
            'pop_sek' => 12, 'pop_tage' => 7, 'pop_titel' => 'Bevor du gehst',
            'pop_knopf' => 'Jetzt lesen', 'pop_nein' => 'Nicht mehr anzeigen', 'pop_top3' => 1,
            'ueberschrift_frage' => 'Willst du mehr erfahren?', 'kartenzahlen' => '3,4,5,6',
            'test_optik' => 0, 'test_frage' => 0, 'test_kartenzahl' => 0, 'qualitaet' => 1,
            'bio_woerter' => '',
        );
    }
    public static function opt($k = null) {
        $g = (array) get_option(self::OPT, array());
        if (isset($g['thema_m']) || isset($g['thema_w'])) { // Einstellungen aus 0.42 (Maulwurf-Voreinstellungen) neutralisieren
            unset($g['thema_m'], $g['thema_w']);
            if (($g['push_sperre'] ?? '') === 'wasser') $g['push_sperre'] = '';
            if (strpos((string) ($g['bio_woerter'] ?? ''), 'nistkasten,wildblume') === 0) $g['bio_woerter'] = '';
            $g['push_thema'] = array_fill(0, 10, 'alle');
        }
        $o = array_merge(self::std(), $g);
        return $k === null ? $o : $o[$k];
    }

    /* ---------- Start ---------- */

    public static function init() {
        add_action('ab1_wl_taeglich', array(__CLASS__, 'aufraeumen'));
        add_action('rest_api_init', array(__CLASS__, 'rest'));
        add_action('init', array(__CLASS__, 'nein_link'));
        add_action('save_post', array(__CLASS__, 'cache_leeren'));
        add_action('add_meta_boxes', array(__CLASS__, 'metabox'));
        add_action('save_post', array(__CLASS__, 'metabox_speichern'), 10, 2);
        add_action('admin_menu', array(__CLASS__, 'menue'));
        add_action('admin_post_ab1_wl_speichern', array(__CLASS__, 'einstellungen_speichern'));
        add_action('admin_post_ab1_wl_bio', array(__CLASS__, 'bio_speichern'));
        add_filter('the_content', array(__CLASS__, 'inhalt'), 30);
        add_shortcode('ab1_weiterlesen', array(__CLASS__, 'shortcode'));
        add_action('wp_footer', array(__CLASS__, 'popup_ausgeben'), 50);
    }

    public static function aktivieren() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $c = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$wpdb->prefix}ab1_wl_zaehler (
            tag date NOT NULL, bereich varchar(4) NOT NULL, variante char(1) NOT NULL, ereignis char(1) NOT NULL,
            quelle bigint(20) unsigned NOT NULL DEFAULT 0, ziel bigint(20) unsigned NOT NULL DEFAULT 0,
            pos tinyint(3) unsigned NOT NULL DEFAULT 0, n int(10) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (tag,bereich,variante,ereignis,quelle,ziel,pos)
        ) $c;");
        dbDelta("CREATE TABLE {$wpdb->prefix}ab1_wl_pop2 (
            tag date NOT NULL, geraet char(1) NOT NULL DEFAULT '', variante char(1) NOT NULL DEFAULT '', ereignis char(1) NOT NULL, grund char(1) NOT NULL DEFAULT '',
            schnell tinyint(1) NOT NULL DEFAULT 0, quelle bigint(20) unsigned NOT NULL DEFAULT 0, n int(10) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (tag,geraet,variante,ereignis,grund,schnell,quelle)
        ) $c;");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ab1_wl_pop");
        dbDelta("CREATE TABLE {$wpdb->prefix}ab1_wl_kennung (
            kennung char(64) NOT NULL, popup_bis datetime NOT NULL, zuletzt char(1) NOT NULL DEFAULT '',
            nein tinyint(1) NOT NULL DEFAULT 0, zeit datetime NOT NULL,
            PRIMARY KEY  (kennung)
        ) $c;");
        if (!wp_next_scheduled('ab1_wl_taeglich')) wp_schedule_event(time() + 3600, 'daily', 'ab1_wl_taeglich');
    }

    public static function aufraeumen() {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->prefix}ab1_wl_kennung WHERE zeit < (UTC_TIMESTAMP() - INTERVAL 8 DAY)");
        $wpdb->query("DELETE FROM {$wpdb->prefix}ab1_wl_zaehler WHERE tag < (CURDATE() - INTERVAL 400 DAY)");
    }

    /* ---------- Auswahl der Artikel ---------- */

    public static function info($id) {
        $kat = wp_get_post_categories($id);
        $tags = wp_get_post_tags($id, array('fields' => 'ids'));
        $sprache = function_exists('pll_get_post_language') ? (string) pll_get_post_language($id) : (string) apply_filters('ab1_wl_sprache', get_locale(), $id);
        return array(
            'id' => (int) $id, 'titel' => self::titel($id), 'kat' => array_map('intval', (array) $kat),
            'tag' => array_map('intval', (array) $tags), 'sprache' => $sprache,
            'noindex' => get_post_meta($id, '_yoast_wpseo_meta-robots-noindex', true) === '1' || get_post_meta($id, '_aioseo_robots_noindex', true) === '1',
            'fokus' => strtolower(trim((string) get_post_meta($id, '_yoast_wpseo_focuskw', true))),
            'wort' => self::wort_von($id), 'thema' => self::thema_von($id),
        );
    }

    /** Thema eines Artikels aus den Themengruppen der Einstellungen (Titel dreifach, plus Text), im Metafeld zwischengespeichert. */
    public static function thema_von($id) {
        $gr = self::themen_parsen(self::opt('themen'));
        if (!$gr) return '';
        $mod = get_post_modified_time('U', true, $id);
        $sig = $mod . '|' . md5(self::opt('themen'));
        $c = get_post_meta($id, '_ab1_wl_thema', true);
        if (is_array($c) && ($c[0] ?? '') === $sig) return $c[1];
        $t = self::titel($id) . ' ' . self::titel($id) . ' ' . self::titel($id) . ' ' . wp_strip_all_tags((string) get_post_field('post_content', $id));
        $t = function_exists('mb_strtolower') ? mb_strtolower($t) : strtolower($t);
        $z = array();
        foreach ($gr as $k => $g) { $z[$k] = 0; foreach ($g['woerter'] as $x) $z[$k] += substr_count($t, $x); }
        $r = self::thema_aus_zaehlungen($z);
        update_post_meta($id, '_ab1_wl_thema', array($sig, $r));
        return $r;
    }

    /** Steht ein Sperrwort (z. B. Wasser) im Titel? Solche Artikel werden nie gepusht. */
    public static function push_gesperrt($id) {
        $t = function_exists('mb_strtolower') ? mb_strtolower(self::titel($id)) : strtolower(self::titel($id));
        foreach (self::liste_woerter(self::opt('push_sperre')) as $x) if (strpos($t, $x) !== false) return true;
        return false;
    }

    /** Textwörter eines Artikels, im Beitrags-Metafeld zwischengespeichert (nur neu berechnet, wenn der Artikel geändert wurde). */
    public static function wort_von($id) {
        $mod = get_post_modified_time('U', true, $id);
        $c = get_post_meta($id, '_ab1_wl_wort', true);
        if (is_array($c) && ($c[0] ?? 0) == $mod) return $c[1];
        $w = self::textwoerter(get_post_field('post_content', $id));
        update_post_meta($id, '_ab1_wl_wort', array($mod, $w));
        return $w;
    }

    /** Artikel mit Biodiversitätsbezug: Haken im Artikel. */
    public static function ist_bio($id) { return get_post_meta($id, '_ab1_wl_bio', true) === '1'; }

    /** Qualitätswert je Artikel (0..1) aus Scrolltiefe, Verweildauer, Klickrate (Mini-Statistik) und, falls dort leer, aus dem GA-Import. */
    public static function qualitaeten() {
        $c = get_transient('ab1wl_q');
        if (is_array($c)) return $c;
        global $wpdb;
        $out = array();
        $t = $wpdb->prefix . 'mini_statistik';
        if (self::opt('qualitaet') && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) {
            $host = preg_replace('/^www\./', '', strtolower((string) parse_url(home_url(), PHP_URL_HOST)));
            $w = $wpdb->prepare("site IN (%s,%s) AND day >= (CURDATE() - INTERVAL 60 DAY)", $host, 'www.' . $host);
            $views = array(); $klicks = array();
            foreach ($wpdb->get_results("SELECT path, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY path", ARRAY_A) as $r) $views[$r['path']] = (int) $r['n'];
            foreach ($wpdb->get_results("SELECT path, COUNT(*) n FROM $t WHERE kind='click' AND $w GROUP BY path", ARRAY_A) as $r) $klicks[$r['path']] = (int) $r['n'];
            $rows = $wpdb->get_results("SELECT path, COUNT(DISTINCT visitor) n, AVG(scroll) g, SUM(secs)/COUNT(DISTINCT visitor) s FROM $t WHERE kind='time' AND $w GROUP BY path HAVING n >= 20 LIMIT 500", ARRAY_A);
            foreach ($rows as $r) {
                $id = url_to_postid(home_url($r['path']));
                if (!$id) continue;
                $v = max(1, $views[$r['path']] ?? 1);
                $out[$id] = self::qualitaet_wert((float) $r['g'], (float) $r['s'], ($klicks[$r['path']] ?? 0) / $v);
            }
            // GA-Import als Ersatz für Seiten ohne eigene Zeitdaten. Annahme: secs = Gesamtzeit je Tag, Durchschnitt je Nutzer = secs/users.
            $g = $wpdb->prefix . 'mini_statistik_ga';
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $g)) === $g) {
                $gr = $wpdb->get_results($wpdb->prepare("SELECT path, SUM(users) u, SUM(secs) s FROM $g WHERE site IN (%s,%s) GROUP BY path HAVING u >= 50 LIMIT 500", $host, 'www.' . $host), ARRAY_A);
                foreach ($gr as $r) {
                    $id = url_to_postid(home_url($r['path']));
                    if ($id && !isset($out[$id])) $out[$id] = 0.8 * min(((float) $r['s'] / max(1, (float) $r['u'])) / 180, 1);
                }
            }
        }
        set_transient('ab1wl_q', $out, 6 * HOUR_IN_SECONDS);
        return $out;
    }

    /** Seiten-Cache der Website leeren, damit Schalter und Plätze sofort für Besucher gelten (Hoster-Cache, gängige Cache-Plugins). Fehlende Funktionen werden übersprungen. */
    public static function seitencache_leeren() {
        foreach (array('sg_cachepress_purge_cache', 'rocket_clean_domain', 'w3tc_flush_all', 'wp_cache_clear_cache', 'litespeed_purge_all', 'autoptimizeCache::clearall') as $f) {
            if (strpos($f, '::') !== false) { list($c, $m) = explode('::', $f); if (class_exists($c) && method_exists($c, $m)) { try { call_user_func(array($c, $m)); } catch (\Throwable $e) {} } continue; }
            if (function_exists($f)) { try { call_user_func($f); } catch (\Throwable $e) {} }
        }
        do_action('ab1_wl_seitencache_leeren');
    }

    public static function cache_leeren($id = 0) {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_ab1wl\_%' OR option_name LIKE '\_transient\_timeout\_ab1wl\_%'");
    }

    public static function max_karten($o) {
        return $o['test_kartenzahl'] ? max(self::kartenzahlen($o['kartenzahlen'])) : max(1, (int) $o['anzahl']);
    }

    /** Die drei erfolgreichsten Artikel (Qualitätswert), gleiche Sprache, ohne noindex, ohne $ausser. */
    public static function top3($ausser) {
        $q = self::qualitaeten();
        arsort($q);
        $a = self::info($ausser);
        $out = array();
        foreach (array_keys($q) as $pid) {
            if ($pid === (int) $ausser || get_post_type($pid) !== 'post' || get_post_status($pid) !== 'publish') continue;
            $b = self::info($pid); $b['kat'] = $a['kat'];
            if (!self::darf_verlinken($a, $b)) continue;
            $out[] = $pid;
            if (count($out) >= 3) break;
        }
        return $out;
    }

    /** Liste der Artikel-IDs für Quelle $id. Rückgabe: array('liste'=>[ids], 'push'=>[idA,idB]) */
    public static function auswahl($id) {
        $key = 'ab1wl_' . $id . '_' . get_post_modified_time('U', true, $id);
        $c = get_transient($key);
        if (is_array($c)) return $c;
        $o = self::opt();
        $a = self::info($id);
        $modus = get_post_meta($id, '_ab1_wl_modus', true) ?: 'auto';
        $liste = array();
        $max = self::max_karten($o);

        $manuell = array_filter(array_map('intval', explode(',', (string) get_post_meta($id, '_ab1_wl_manuell', true))));
        if ($modus !== 'auto') {
            foreach ($manuell as $m) {
                if (get_post_status($m) === 'publish' && $m !== $id) $liste[] = $m; // manuell: Redakteur entscheidet (Ausnahme erlaubt)
            }
        }
        $push = array(); // Buchstabe => Beitrags-ID, Buchstabe bleibt am Platz in den Einstellungen hängen
        foreach (array_values((array) $o['push']) as $i => $p) {
            $p = (int) $p;
            if ($i > 9 || !$p || get_post_status($p) !== 'publish' || self::push_gesperrt($p)) continue;
            if (!self::thema_passt($a['thema'], (string) ($o['push_thema'][$i] ?? 'alle'))) continue;
            $b = self::info($p);
            if ($o['push_themenfrei']) $b['kat'] = $a['kat']; // Redakteur hat bewusst gewählt: Thema nicht prüfen
            if (self::darf_verlinken($a, $b)) $push[chr(97 + $i)] = $p;
        }
        if ($modus !== 'manuell' && count($liste) < $max) {
            $q = new WP_Query(array(
                'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 60, 'fields' => 'ids',
                'post__not_in' => array($id), 'category__in' => $a['kat'] ?: array(), 'no_found_rows' => true,
                'orderby' => 'date', 'order' => 'DESC',
            ));
            $kand = array(); $qual = self::qualitaeten();
            foreach ($q->posts as $pid) {
                if (in_array($pid, $liste, true) || in_array($pid, $push, true)) continue;
                $b = self::info($pid);
                if (!self::darf_verlinken($a, $b)) continue;
                $bonus = (float) get_post_meta($pid, '_ab1_wl_gewicht', true) + (self::ist_bio($pid) ? 4 : 0) + 3 * ($qual[$pid] ?? 0);
                $kand[$pid] = self::bewerte($a, $b, $bonus);
            }
            arsort($kand);
            foreach (array_keys($kand) as $pid) { if (count($liste) >= $max) break; $liste[] = $pid; }
        }
        $c = array('liste' => array_slice(array_values(array_unique($liste)), 0, $max), 'push' => $push);
        set_transient($key, $c, 12 * HOUR_IN_SECONDS);
        return $c;
    }

    /* ---------- Anzeige Weiterlesen ---------- */

    private static function karte($pid, $pos, $extra = '') {
        $bild = get_the_post_thumbnail_url($pid, 'medium');
        $t = self::titel($pid);
        $h = '<li data-z="' . (int) $pid . '" data-p="' . (int) $pos . '"' . $extra . '><a href="' . esc_url(get_permalink($pid)) . '">';
        if ($bild) $h .= '<img src="' . esc_url($bild) . '" alt="" loading="lazy" decoding="async" width="300" height="200">';
        return $h . '<span>' . esc_html($t) . '</span></a></li>';
    }

    public static function box_html($id) {
        $o = self::opt();
        $w = self::auswahl($id);
        $liste = $w['liste'];
        $push = $w['push'];
        if (!$liste && !$push) return '';
        $max = self::max_karten($o);
        $kz = $o['test_kartenzahl'] ? self::kartenzahlen($o['kartenzahlen']) : array();
        $h = '<aside class="ab1wl" data-q="' . (int) $id . '" aria-label="' . esc_attr($o['ueberschrift']) . '"><h2 data-a="' . esc_attr($o['ueberschrift']) . '" data-f="' . esc_attr($o['ueberschrift_frage']) . '">' . esc_html($o['ueberschrift']) . '</h2><ul>';
        $pos = 1;
        if ($push) {
            // gepushte Artikel teilen sich Platz 1: je Aufruf zufällig einer (Varianten A bis E)
            $erste = true;
            foreach ($push as $buchstabe => $pid) {
                $h .= self::karte($pid, 1, ($o['ab'] && count($push) > 1) ? ' data-s="' . $buchstabe . '"' . ($erste ? '' : ' hidden') : '');
                $erste = false;
                if (!$o['ab']) break;
            }
            $pos = 2;
        }
        foreach ($liste as $pid) { if ($pos > $max) break; $h .= self::karte($pid, $pos++); }
        $h .= '</ul></aside>';
        // Testschalter für das Skript (welche Dimensionen laufen, Kartenzahlen je Variante A bis D)
        $h .= '<script type="application/json" class="ab1wl-cfg">' . wp_json_encode(array('kz' => $kz, 'o' => (int) $o['test_optik'], 'f' => (int) $o['test_frage'])) . '</script>';
        return $h;
    }

    public static function teaser_html($id, $push) {
        $ziel = reset($push);
        return '<p class="ab1wl-tz" data-q="' . (int) $id . '" data-z="' . (int) $ziel . '" data-p="0"><strong>' . esc_html__('Das könnte dich auch interessieren:', 'ab1-wl') . '</strong> <a href="' . esc_url(get_permalink($ziel)) . '">' . esc_html(self::titel($ziel)) . '</a></p>';
    }

    private static $js_geladen = false;

    public static function inhalt($inhalt) {
        $o = self::opt();
        if (!$o['weiterlesen'] || !is_singular('post') || !in_the_loop() || !is_main_query()) return $inhalt;
        $id = get_the_ID();
        if (get_post_meta($id, '_ab1_wl_modus', true) === 'aus') return $inhalt;
        $w = self::auswahl($id);
        if ($o['teaser_oben'] && $w['push']) {
            $inhalt = self::fuege_nach_absatz($inhalt, '<div class="ab1wl-tz-platz" hidden>' . self::teaser_html($id, $w['push']) . '</div>', max(1, (int) $o['teaser_absatz']));
        }
        $box = self::box_html($id);
        if ($box) { self::$js_geladen = true; add_action('wp_footer', array(__CLASS__, 'weiterlesen_skript'), 40); }
        return $inhalt . $box;
    }

    public static function shortcode() {
        $id = get_the_ID();
        if (!$id) return '';
        self::$js_geladen = true;
        add_action('wp_footer', array(__CLASS__, 'weiterlesen_skript'), 40);
        return self::box_html($id);
    }

    public static function weiterlesen_skript() {
        static $fertig = false;
        if ($fertig) return; $fertig = true;
        $css = '.ab1wl{margin:2.5em 0;clear:both}.ab1wl h2{font-size:1.3em;margin:0 0 .8em}.ab1wl ul{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}'
            . '.ab1wl li{margin:0;padding:0}.ab1wl li[hidden]{display:none}.ab1wl a{display:block;text-decoration:none;color:inherit;border:1px solid rgba(0,0,0,.1);border-radius:12px;overflow:hidden;background:#fff;height:100%;transition:box-shadow .2s,transform .2s}'
            . '.ab1wl a:hover,.ab1wl a:focus{box-shadow:0 6px 18px rgba(0,0,0,.12);transform:translateY(-2px)}.ab1wl img{display:block;width:100%;height:auto;aspect-ratio:3/2;object-fit:cover}'
            . '.ab1wl.ab1wl-t img{display:none}.ab1wl span{display:block;padding:10px 12px;font-weight:600;line-height:1.3}@media(max-width:800px){.ab1wl ul{grid-template-columns:repeat(2,1fr)}}'
            . '.ab1wl-tz{margin:1.5em 0;padding:12px 16px;background:#f4f8f2;border-left:4px solid #6a9a5b;border-radius:6px}@media(prefers-reduced-motion:reduce){.ab1wl a{transition:none}}';
        $cfg = array('u' => esc_url_raw(rest_url(self::REST . '/ereignis')));
        $js = <<<'JS'
(function(){var C=__CFG__;
function s(a){try{var b=new Blob([JSON.stringify({ev:a})],{type:"text/plain"});if(navigator.sendBeacon)navigator.sendBeacon(C.u,b);else fetch(C.u,{method:"POST",body:b,keepalive:true})}catch(e){}}
function r(n){return Math.floor(Math.random()*n)}
function go(){var b=document.querySelector(".ab1wl");if(!b)return;
var q=+b.getAttribute("data-q"),K={},cj=document.querySelector(".ab1wl-cfg"),D={},i;try{K=JSON.parse(cj.textContent)}catch(e){}
var L=[].map.call(b.querySelectorAll("[data-s]"),function(e){return e.getAttribute("data-s")});
D.wl=L.length?L[r(L.length)]:"a";
[].forEach.call(b.querySelectorAll("[data-s]"),function(e){e.hidden=e.getAttribute("data-s")!==D.wl});
var li=[].slice.call(b.querySelectorAll("li:not([hidden])"));
if(K.kz&&K.kz.length){i=r(K.kz.length);if(K.kz.length>1)D.wk="abcd".charAt(i);li.forEach(function(e,j){if(j>=K.kz[i])e.hidden=true})}
if(K.o){D.wo="ab".charAt(r(2));if(D.wo==="b")b.classList.add("ab1wl-t")}
if(K.f){D.wf="ab".charAt(r(2));if(D.wf==="b"){var h=b.querySelector("h2");h.textContent=h.getAttribute("data-f")}}
var pl=document.querySelector(".ab1wl-tz-platz"),tzz=0;
if(pl){D.wp="ab".charAt(r(2));if(D.wp==="b"){pl.hidden=false;tzz=+pl.querySelector("[data-z]").getAttribute("data-z")}else pl.parentNode.removeChild(pl)}
var done=0;function imp(){if(done)return;done=1;var ev=[],sh=[].slice.call(b.querySelectorAll("li:not([hidden])")),k;
for(k in D){ev.push({b:k,v:D[k],e:"i",q:q,z:0,p:0});sh.forEach(function(e){ev.push({b:k,v:D[k],e:"s",q:q,z:+e.getAttribute("data-z"),p:+e.getAttribute("data-p")})});if(k==="wp"&&tzz)ev.push({b:k,v:"b",e:"s",q:q,z:tzz,p:0})}
if(tzz)ev.push({b:"tz",v:"b",e:"i",q:q,z:0,p:0});s(ev)}
if("IntersectionObserver"in window){var io=new IntersectionObserver(function(x){if(x[0].isIntersecting){imp();io.disconnect()}},{threshold:.5});io.observe(b)}
document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest(".ab1wl a,.ab1wl-tz a");if(!a)return;var h=a.closest("[data-z]");if(!h)return;var ev=[],k,z=+h.getAttribute("data-z"),p=+h.getAttribute("data-p");
for(k in D)ev.push({b:k,v:D[k],e:"c",q:q,z:z,p:p});if(a.closest(".ab1wl-tz"))ev.push({b:"tz",v:"b",e:"c",q:q,z:z,p:0});s(ev)},true)}
(window.requestIdleCallback||function(f){setTimeout(f,300)})(go)})();
JS;
        echo '<style id="ab1wl-css">' . $css . '</style><script id="ab1wl-js">' . str_replace('__CFG__', wp_json_encode($cfg), $js) . '</script>';
    }

    /* ---------- Exit-Popup ---------- */

    public static function popup_inhalte($id) {
        $v = array();
        foreach (self::auswahl($id)['push'] as $buchstabe => $pid) $v[$buchstabe] = array('typ' => 'karte', 'ids' => array($pid));
        if (self::opt('pop_top3')) {
            $t = self::top3($id);
            if (count($t) === 3) $v['z'] = array('typ' => 'liste', 'ids' => $t);
        }
        return $v;
    }

    public static function popup_ausgeben() {
        $o = self::opt();
        if (!$o['popup'] || !is_singular('post')) return;
        $id = get_the_ID();
        if (preg_match('/(' . self::SEITEN_OHNE_POPUP . ')/i', (string) get_post_field('post_name', $id))) return;
        $v = self::popup_inhalte($id);
        if (count($v) < 1) return;
        $html = '';
        foreach ($v as $k => $d) {
            $html .= '<div class="ab1p-v" data-v="' . $k . '" hidden>';
            if ($d['typ'] === 'karte') {
                $p = $d['ids'][0]; $bild = get_the_post_thumbnail_url($p, 'medium_large');
                $html .= '<a class="ab1p-karte" href="' . esc_url(get_permalink($p)) . '" data-z="' . (int) $p . '">';
                if ($bild) $html .= '<img src="' . esc_url($bild) . '" alt="" width="480" height="300" decoding="async">';
                $html .= '<span class="ab1p-t">' . esc_html(self::titel($p)) . '</span><span class="ab1p-k">' . esc_html($o['pop_knopf']) . ' &rarr;</span></a>';
            } else {
                $html .= '<ul class="ab1p-liste">';
                foreach ($d['ids'] as $i => $p) $html .= '<li><a href="' . esc_url(get_permalink($p)) . '" data-z="' . (int) $p . '">' . esc_html(self::titel($p)) . '</a></li>';
                $html .= '</ul>';
            }
            $html .= '</div>';
        }
        $cfg = array(
            'u' => esc_url_raw(rest_url(self::REST . '/')), 'q' => (int) $id, 'sek' => (int) $o['pop_sek'],
            'v' => array_keys($v), 'nein' => esc_url_raw(add_query_arg('ab1wl_nein', '1', home_url('/'))),
        );
        $css = '#ab1p{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(20,30,20,.55);opacity:0;transition:opacity .25s}'
            . '#ab1p.an{opacity:1}#ab1p[hidden]{display:none}.ab1p-box{position:relative;max-width:460px;width:100%;background:#fff;border-radius:18px;box-shadow:0 20px 60px rgba(0,0,0,.35);padding:22px 22px 16px;transform:translateY(12px);transition:transform .25s}'
            . '#ab1p.an .ab1p-box{transform:none}.ab1p-h{font-size:1.25em;font-weight:700;margin:0 28px 12px 0;color:#2d4a26}.ab1p-x{position:absolute;top:8px;right:10px;border:0;background:none;font-size:28px;line-height:1;cursor:pointer;color:#666;padding:4px 8px}'
            . '.ab1p-karte{display:block;text-decoration:none;color:inherit;border-radius:12px;overflow:hidden;border:1px solid rgba(0,0,0,.1)}.ab1p-karte img{display:block;width:100%;height:auto;aspect-ratio:8/5;object-fit:cover}'
            . '.ab1p-t{display:block;padding:12px 14px 4px;font-weight:700;font-size:1.05em;line-height:1.3}.ab1p-k{display:block;padding:0 14px 14px;color:#2f7d32;font-weight:600}'
            . '.ab1p-liste{list-style:none;margin:0;padding:0}.ab1p-liste li{margin:0;border-top:1px solid rgba(0,0,0,.08)}.ab1p-liste li:first-child{border-top:0}.ab1p-liste a{display:block;padding:12px 4px;font-weight:600;text-decoration:none;color:#2f7d32}'
            . '.ab1p-n{display:block;margin-top:12px;font-size:.8em;color:#777;text-align:center}@media(prefers-reduced-motion:reduce){#ab1p,.ab1p-box{transition:none}}';
        $js = '(function(){var C=' . wp_json_encode($cfg) . ',t0=Date.now(),done=0,V,P,att={},tr="",ts=0,cl=0,dev=matchMedia("(pointer:coarse)").matches?"m":"d";'
            . 'function post(u,o){try{var b=new Blob([JSON.stringify(o)],{type:"text/plain"});if(navigator.sendBeacon)navigator.sendBeacon(u,b)}catch(e){}}'
            . 'function zu(g){if(g&&!cl){cl=1;post(C.u+"ereignis",{b:"pu",v:V,e:"x",g:g,s:Date.now()-ts<2000?1:0,q:C.q,z:0,p:0,d:dev})}P.classList.remove("an");setTimeout(function(){P.hidden=true},260);document.removeEventListener("keydown",kd)}'
            . 'function kd(e){if(e.key==="Escape")zu("k")}'
            . 'function mel(g){if(att[g])return;att[g]=1;post(C.u+"ereignis",{b:"pu",v:"z",e:"v",g:g,q:C.q,z:0,p:0,d:dev})}'
            . 'function zeig(a){if(done)return mel("b");if(Date.now()-t0<C.sek*1000)return mel("z");done=1;tr=a;'
            . 'fetch(C.u+"popup?q="+C.q+"&v="+C.v.join(""),{credentials:"omit"}).then(function(r){return r.json()}).then(function(j){if(!j||!j.zeigen||C.v.indexOf(j.v)<0){mel(j&&j.grund==="nein"?"n":"g");return}V=j.v;'
            . 'P=document.getElementById("ab1p");[].forEach.call(P.querySelectorAll(".ab1p-v"),function(e){e.hidden=e.getAttribute("data-v")!==V});P.hidden=false;ts=Date.now();void P.offsetWidth;P.classList.add("an");'
            . 'P.querySelector(".ab1p-x").focus();document.addEventListener("keydown",kd);post(C.u+"ereignis",{b:"pu",v:V,e:"i",q:C.q,z:0,p:0,d:dev,a:tr})}).catch(function(){})}'
            . 'function start(){var P0=document.getElementById("ab1p");P0.addEventListener("click",function(e){var a=e.target.closest("a[data-z]");if(a)post(C.u+"ereignis",{b:"pu",v:V,e:"c",q:C.q,z:+a.getAttribute("data-z"),p:0,d:dev,a:tr});if(e.target===P0)zu("o");else if(e.target.classList.contains("ab1p-x"))zu("x");else if(e.target.closest(".ab1p-n")&&!cl){cl=1;post(C.u+"ereignis",{b:"pu",v:V,e:"x",g:"n",s:Date.now()-ts<2000?1:0,q:C.q,z:0,p:0,d:dev})}});'
            . 'var touch=matchMedia("(pointer:coarse)").matches;'
            . 'if(!touch){document.addEventListener("mouseout",function(e){if(!e.relatedTarget&&e.clientY<=0)zeig("m")})}'
            . '{var ly=scrollY,mx=0;addEventListener("scroll",function(){var h=document.documentElement.scrollHeight-innerHeight||1,p=scrollY/h;if(p>mx)mx=p;if(mx>.45&&ly-scrollY>140)zeig("h");if(scrollY>ly)ly=scrollY},{passive:true})}}'
            . '(window.requestIdleCallback||function(f){setTimeout(f,1500)})(start)})();';
        echo '<style id="ab1p-css">' . $css . '</style><div id="ab1p" role="dialog" aria-modal="true" aria-labelledby="ab1p-h" hidden><div class="ab1p-box"><button type="button" class="ab1p-x" aria-label="Schließen">&times;</button><p class="ab1p-h" id="ab1p-h">'
            . esc_html($o['pop_titel']) . '</p>' . $html . '<a class="ab1p-n" href="' . esc_url($cfg['nein']) . '" rel="nofollow">' . esc_html($o['pop_nein']) . '</a></div></div><script id="ab1p-js">' . $js . '</script>';
    }

    /* ---------- Server: Zähler, Kennung, REST ---------- */

    private static function meine_kennung() {
        $ip = apply_filters('ab1_wl_ip', isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '');
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 300) : '';
        return self::kennung($ip, $ua, wp_salt('auth'), time());
    }

    public static function rest() {
        register_rest_route(self::REST, '/ereignis', array(
            'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => array(__CLASS__, 'rest_ereignis'),
        ));
        register_rest_route(self::REST, '/suche', array(
            'methods' => 'GET', 'permission_callback' => function () { return current_user_can('manage_options'); }, 'callback' => array(__CLASS__, 'rest_suche'),
        ));
        register_rest_route(self::REST, '/popup', array(
            'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => array(__CLASS__, 'rest_popup'),
        ));
    }

    public static function rest_ereignis($req) {
        global $wpdb;
        $leer = new WP_REST_Response(null, 204);
        $d = json_decode($req->get_body(), true);
        if (!is_array($d)) return $leer;
        $liste = isset($d['ev']) && is_array($d['ev']) ? array_slice($d['ev'], 0, 80) : array($d);
        $ok = array(); $zeilen = array(); $popz = array();
        foreach ($liste as $x) {
            if (!is_array($x)) continue;
            $b = (string) ($x['b'] ?? ''); $v = (string) ($x['v'] ?? ''); $e = (string) ($x['e'] ?? '');
            $q = (int) ($x['q'] ?? 0); $z = (int) ($x['z'] ?? 0); $p = max(0, min(20, (int) ($x['p'] ?? 0)));
            $dv = in_array((string) ($x['d'] ?? ''), array('d', 'm'), true) ? (string) $x['d'] : '';
            $au = in_array((string) ($x['a'] ?? ''), array('m', 'h'), true) ? (string) $x['a'] : '';
            if ($b === 'pu' && $e === 'x') { // Schließen des Popups (x X-Knopf, o dunkler Hintergrund, k Escape, n „Nicht mehr anzeigen“); schnell = unter 2 Sekunden nach dem Einblenden
                $g = (string) ($x['g'] ?? ''); if (!in_array($g, array('x', 'o', 'k', 'n'), true) || !$q || !preg_match('/^[a-jz]$/', $v)) continue;
                if (!isset($ok[$q])) $ok[$q] = get_post_status($q) === 'publish'; if (empty($ok[$q])) continue;
                $popz[] = $wpdb->prepare('(%s,%s,%s,%s,%s,%d,%d,1)', gmdate('Y-m-d'), $dv, $v, 'x', $g, empty($x['s']) ? 0 : 1, $q); continue;
            }
            if ($b === 'pu' && $e === 'v') { // Auslöseversuch des Popups, der nicht zur Einblendung führte (Grund: z zu früh, b schon gezeigt, n „nicht mehr anzeigen“, g Besucher gesperrt)
                $g = (string) ($x['g'] ?? ''); if (!in_array($g, array('z', 'b', 'n', 'g'), true) || !$q) continue;
                if (!isset($ok[$q])) $ok[$q] = get_post_status($q) === 'publish'; if (empty($ok[$q])) continue;
                $popz[] = $wpdb->prepare('(%s,%s,%s,%s,%s,%d,%d,1)', gmdate('Y-m-d'), $dv, '', 'v', $g, 0, $q); continue;
            }
            if (!in_array($b, array('wl', 'wk', 'wo', 'wf', 'wp', 'tz', 'pu'), true) || !preg_match('/^[a-jz]$/', $v) || !in_array($e, array('i', 'c', 's'), true)) continue;
            foreach (array($q, $z) as $pid) if ($pid && !isset($ok[$pid])) $ok[$pid] = get_post_status($pid) === 'publish';
            if (!$q || empty($ok[$q]) || ($z && empty($ok[$z]))) continue;
            $zeilen[] = $wpdb->prepare('(%s,%s,%s,%s,%d,%d,%d,1)', gmdate('Y-m-d'), $b, $v, $e, $q, $z, $p);
            if ($b === 'pu' && ($e === 'i' || $e === 'c')) $popz[] = $wpdb->prepare('(%s,%s,%s,%s,%s,%d,%d,1)', gmdate('Y-m-d'), $dv, $v, $e, $au, 0, $q);
        }
        if ($popz) $wpdb->query('INSERT INTO ' . $wpdb->prefix . 'ab1_wl_pop2 (tag,geraet,variante,ereignis,grund,schnell,quelle,n) VALUES ' . implode(',', $popz) . ' ON DUPLICATE KEY UPDATE n=n+1');
        if ($zeilen) $wpdb->query('INSERT INTO ' . $wpdb->prefix . 'ab1_wl_zaehler (tag,bereich,variante,ereignis,quelle,ziel,pos,n) VALUES ' . implode(',', $zeilen) . ' ON DUPLICATE KEY UPDATE n=n+1');
        return $leer;
    }

    public static function rest_popup($req) {
        global $wpdb;
        $o = self::opt();
        $t = $wpdb->prefix . 'ab1_wl_kennung';
        $k = self::meine_kennung();
        $erlaubt = array_values(array_filter(str_split(preg_replace('/[^a-jz]/', '', (string) $req->get_param('v')))));
        $res = new WP_REST_Response(array('zeigen' => false));
        $res->header('Cache-Control', 'no-store');
        if (!$o['popup'] || !$erlaubt) return $res;
        $r = $wpdb->get_row($wpdb->prepare("SELECT popup_bis, nein FROM $t WHERE kennung=%s", $k), ARRAY_A);
        $jetzt = gmdate('Y-m-d H:i:s');
        if ($r && ((int) $r['nein'] === 1 || $r['popup_bis'] > $jetzt)) { $res->set_data(array('zeigen' => false, 'grund' => (int) $r['nein'] === 1 ? 'nein' : 'gesperrt')); return $res; }
        $v = self::popup_variante($k, (int) floor(time() / 86400), $erlaubt);
        $bis = gmdate('Y-m-d H:i:s', time() + max(1, (int) $o['pop_tage']) * DAY_IN_SECONDS);
        $wpdb->query($wpdb->prepare("INSERT INTO $t (kennung,popup_bis,zuletzt,nein,zeit) VALUES (%s,%s,%s,0,%s) ON DUPLICATE KEY UPDATE popup_bis=VALUES(popup_bis),zuletzt=VALUES(zuletzt),zeit=VALUES(zeit)", $k, $bis, $v, $jetzt));
        $res->set_data(array('zeigen' => true, 'v' => $v));
        return $res;
    }

    /** „Nicht mehr anzeigen“ als normaler Link, serverseitig, ohne Speicherung im Browser. */
    public static function nein_link() {
        if (empty($_GET['ab1wl_nein'])) return;
        global $wpdb;
        $t = $wpdb->prefix . 'ab1_wl_kennung';
        $k = self::meine_kennung(); $jetzt = gmdate('Y-m-d H:i:s');
        $wpdb->query($wpdb->prepare("INSERT INTO $t (kennung,popup_bis,zuletzt,nein,zeit) VALUES (%s,%s,'',1,%s) ON DUPLICATE KEY UPDATE nein=1,zeit=VALUES(zeit)", $k, $jetzt, $jetzt));
        $ziel = wp_get_referer();
        if (!$ziel || strpos($ziel, home_url()) !== 0) $ziel = home_url('/');
        nocache_headers();
        wp_safe_redirect($ziel);
        exit;
    }

    /* ---------- Admin ---------- */

    public static function metabox() {
        add_meta_box('ab1_wl', 'Weiterlesen (1AB)', array(__CLASS__, 'metabox_html'), 'post', 'side');
    }
    public static function metabox_html($post) {
        wp_nonce_field('ab1_wl_mb', 'ab1_wl_mb_n');
        $m = get_post_meta($post->ID, '_ab1_wl_modus', true) ?: 'auto';
        echo '<p><label>Modus<br><select name="ab1_wl_modus">';
        foreach (array('auto' => 'Automatisch', 'manuell' => 'Manuell', 'gemischt' => 'Gemischt (manuelle zuerst)', 'aus' => 'Keine Empfehlungen') as $k => $l) echo '<option value="' . esc_attr($k) . '"' . selected($m, $k, false) . '>' . esc_html($l) . '</option>';
        echo '</select></label></p><p><label>Manuell: Artikel-IDs, kommagetrennt (bis 4)<br><input type="text" class="widefat" name="ab1_wl_manuell" value="' . esc_attr(get_post_meta($post->ID, '_ab1_wl_manuell', true)) . '"></label></p>';
        echo '<p><label><input type="checkbox" name="ab1_wl_bio" value="1"' . checked(self::ist_bio($post->ID), true, false) . '> Bezug zu Biodiversität (wird bevorzugt empfohlen)</label></p>';
        echo '<p><label>Gewicht dieses Artikels (0–5, Säulenartikel höher)<br><input type="number" min="0" max="5" step="0.5" name="ab1_wl_gewicht" value="' . esc_attr(get_post_meta($post->ID, '_ab1_wl_gewicht', true)) . '"></label></p>';
    }
    public static function metabox_speichern($id, $post) {
        if (!isset($_POST['ab1_wl_mb_n']) || !wp_verify_nonce($_POST['ab1_wl_mb_n'], 'ab1_wl_mb') || !current_user_can('edit_post', $id) || wp_is_post_autosave($id)) return;
        $m = isset($_POST['ab1_wl_modus']) ? sanitize_key($_POST['ab1_wl_modus']) : 'auto';
        update_post_meta($id, '_ab1_wl_modus', in_array($m, array('auto', 'manuell', 'gemischt', 'aus'), true) ? $m : 'auto');
        $ids = array_slice(array_filter(array_map('intval', explode(',', (string) ($_POST['ab1_wl_manuell'] ?? '')))), 0, 4);
        update_post_meta($id, '_ab1_wl_manuell', implode(',', $ids));
        update_post_meta($id, '_ab1_wl_bio', empty($_POST['ab1_wl_bio']) ? '0' : '1');
        update_post_meta($id, '_ab1_wl_gewicht', max(0, min(5, (float) ($_POST['ab1_wl_gewicht'] ?? 0))));
    }

    public static function menue() {
        if (apply_filters('ab1_wl_eigenes_menue', true)) add_options_page('Weiterlesen (1AB)', 'Weiterlesen (1AB)', 'manage_options', 'ab1-wl', array(__CLASS__, 'seite'));
    }

    public static function einstellungen_speichern() {
        if (!current_user_can('manage_options')) wp_die('Keine Berechtigung');
        check_admin_referer('ab1_wl_s');
        $s = self::std(); $in = wp_unslash($_POST);
        $n = array();
        foreach (array('weiterlesen', 'popup', 'ab', 'teaser_oben', 'push_themenfrei', 'pop_top3', 'test_optik', 'test_frage', 'test_kartenzahl', 'qualitaet') as $k) $n[$k] = empty($in[$k]) ? 0 : 1;
        foreach (array('anzahl' => array(1, 6), 'teaser_absatz' => array(1, 20), 'pop_sek' => array(3, 120), 'pop_tage' => array(1, 90)) as $k => $r) $n[$k] = max($r[0], min($r[1], (int) ($in[$k] ?? $s[$k])));
        foreach (array('ueberschrift', 'ueberschrift_frage', 'pop_titel', 'pop_knopf', 'pop_nein', 'bio_woerter', 'push_sperre') as $k) $n[$k] = sanitize_text_field($in[$k] ?? $s[$k]);
        $n['themen'] = sanitize_textarea_field($in['themen'] ?? '');
        $gr = self::themen_parsen($n['themen']);
        $typen = self::such_typen();
        $n['kartenzahlen'] = implode(',', self::kartenzahlen($in['kartenzahlen'] ?? $s['kartenzahlen']));
        $push = array();
        $pt = array();
        for ($i = 0; $i < 10; $i++) {
            $p = (int) ($in['push'][$i] ?? 0);
            $push[] = ($p && in_array(get_post_type($p), $typen, true) && get_post_status($p) === 'publish') ? $p : 0;
            $th = (string) ($in['push_thema'][$i] ?? 'alle');
            $pt[] = ($th === 'alle' || isset($gr[$th])) ? $th : 'alle';
        }
        $n['push'] = $push; $n['push_thema'] = $pt;
        update_option(self::OPT, $n);
        self::cache_leeren();
        self::seitencache_leeren();
        wp_safe_redirect(add_query_arg('ok', '1', apply_filters('ab1_wl_seiten_url', admin_url('options-general.php?page=ab1-wl'))));
        exit;
    }

    public static function bio_speichern() {
        if (!current_user_can('manage_options')) wp_die('Keine Berechtigung');
        check_admin_referer('ab1_wl_bio');
        $alle = array_filter(array_map('intval', explode(',', (string) ($_POST['bio_alle'] ?? ''))));
        $an = array_map('intval', (array) ($_POST['bio_ids'] ?? array()));
        foreach ($alle as $id) if (current_user_can('edit_post', $id)) update_post_meta($id, '_ab1_wl_bio', in_array($id, $an, true) ? '1' : '0');
        self::cache_leeren();
        self::seitencache_leeren();
        wp_safe_redirect(add_query_arg('ok', '1', apply_filters('ab1_wl_seiten_url', admin_url('options-general.php?page=ab1-wl'))));
        exit;
    }

    /** Artikel, deren Titel oder Text Biodiversitäts-Stichwörter enthalten (Vorschlag zum Abhaken). */
    public static function bio_kandidaten($max = 40) {
        $w = array_filter(array_map('trim', explode(',', function_exists('mb_strtolower') ? mb_strtolower(self::opt('bio_woerter')) : strtolower(self::opt('bio_woerter')))));
        if (!$w) return array();
        $ids = get_posts(array('numberposts' => 300, 'fields' => 'ids', 'post_status' => 'publish'));
        $out = array();
        foreach ($ids as $id) {
            $heu = strtolower(self::titel($id) . ' ' . implode(' ', self::wort_von($id)));
            $treffer = 0;
            foreach ($w as $x) if ($x !== '' && strpos($heu, $x) !== false) $treffer++;
            if ($treffer || self::ist_bio($id)) $out[$id] = $treffer;
        }
        arsort($out);
        return array_slice($out, 0, $max, true);
    }

    /** Beitragstypen, die als Push-Artikel gewählt werden dürfen (alle öffentlichen außer Medien). */
    public static function such_typen() {
        $t = array_values(array_diff(get_post_types(array('public' => true)), array('attachment')));
        return $t ?: array('post', 'page');
    }

    /** Suche für die Plätze: Artikel und Seiten, auch ohne Suchbegriff (neueste), auch per Nummer. */
    public static function rest_suche($req) {
        $q = trim((string) $req->get_param('q'));
        $ids = array();
        if (ctype_digit($q) && get_post_status((int) $q) === 'publish') $ids[] = (int) $q;
        $arg = array('post_type' => self::such_typen(), 'post_status' => 'publish', 'posts_per_page' => 25, 'fields' => 'ids', 'no_found_rows' => true, 'orderby' => $q === '' ? 'date' : 'relevance', 'order' => 'DESC');
        if ($q !== '') $arg['s'] = $q;
        $w = new WP_Query($arg);
        $ids = array_values(array_unique(array_merge($ids, $w->posts)));
        $out = array();
        foreach (array_slice($ids, 0, 25) as $id) {
            $o = get_post_type_object(get_post_type($id));
            $out[] = array('id' => (int) $id, 'titel' => html_entity_decode(self::titel($id), ENT_QUOTES, 'UTF-8'), 'typ' => $o ? $o->labels->singular_name : '', 'bild' => (string) get_the_post_thumbnail_url($id, 'medium'));
        }
        return new WP_REST_Response($out);
    }

    /** Aufrufe je Artikel (30 Tage): Mini-Statistik, falls vorhanden; sonst eigene Einblendungen der Box. */
    public static function besucher() {
        global $wpdb;
        $v = array(); $quelle = '';
        $t = $wpdb->prefix . 'mini_statistik';
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t) {
            $quelle = 'Mini-Statistik';
            $host = preg_replace('/^www\./', '', strtolower((string) parse_url(home_url(), PHP_URL_HOST)));
            $rows = $wpdb->get_results($wpdb->prepare("SELECT path, COUNT(*) n FROM $t WHERE kind='view' AND site IN (%s,%s) AND day >= (CURDATE() - INTERVAL 30 DAY) GROUP BY path ORDER BY n DESC LIMIT 300", $host, 'www.' . $host), ARRAY_A);
            foreach ($rows as $r) { $id = url_to_postid(home_url($r['path'])); if ($id) $v[$id] = ($v[$id] ?? 0) + (int) $r['n']; }
        } else {
            $quelle = 'eigene Einblendungen der Weiterlesen-Box';
            $z = $wpdb->prefix . 'ab1_wl_zaehler';
            $rows = $wpdb->get_results("SELECT quelle, SUM(n) n FROM $z WHERE bereich='wl' AND ereignis='i' AND tag >= (CURDATE() - INTERVAL 30 DAY) GROUP BY quelle ORDER BY n DESC LIMIT 300", ARRAY_A);
            foreach ($rows as $r) $v[(int) $r['quelle']] = (int) $r['n'];
        }
        return array($v, $quelle);
    }

    /** Fünf Vorschläge: meistbesuchte Artikel, ohne noindex, höchstens zwei je Kategorie. */
    public static function vorschlaege($n = 5) {
        list($v, $quelle) = self::besucher();
        $out = array(); $kat = array();
        foreach ($v as $id => $aufrufe) {
            if (get_post_type($id) !== 'post' || get_post_status($id) !== 'publish') continue;
            $i = self::info($id);
            if ($i['noindex'] || self::push_gesperrt($id)) continue;
            $k = $i['kat'] ? $i['kat'][0] : 0;
            if (($kat[$k] ?? 0) >= 2) continue;
            $kat[$k] = ($kat[$k] ?? 0) + 1;
            $out[] = array('id' => $id, 'aufrufe' => $aufrufe);
            if (count($out) >= $n) break;
        }
        if (count($out) < $n) { // Notbehelf: neueste Artikel, wenn noch keine Zahlen da sind
            $ids = get_posts(array('numberposts' => $n * 3, 'fields' => 'ids', 'post_status' => 'publish'));
            foreach ($ids as $id) { if (count($out) >= $n) break; if (!in_array($id, array_column($out, 'id'), true)) $out[] = array('id' => $id, 'aufrufe' => 0); }
        }
        return array($out, $quelle);
    }

    private static function variante_name($bereich, $v) {
        $o = self::opt();
        $L = array(
            'wo' => array('a' => 'Bild und Titel', 'b' => 'nur Titel'),
            'wf' => array('a' => 'Aussage: ' . $o['ueberschrift'], 'b' => 'Frage: ' . $o['ueberschrift_frage']),
            'wp' => array('a' => 'nur am Artikelende', 'b' => 'Ende und Teaser oben'),
        );
        if ($bereich === 'wk') { $z = self::kartenzahlen($o['kartenzahlen']); $i = ord($v) - 97; return isset($z[$i]) ? $z[$i] . ' Karten' : ''; }
        if ($bereich === 'wl' || $bereich === 'pu') {
            if ($bereich === 'pu' && $v === 'z') return 'Die 3 erfolgreichsten Artikel';
            $pid = (int) (array_values((array) $o['push'])[ord($v) - 97] ?? 0);
            return $pid ? self::titel($pid) : '';
        }
        return $L[$bereich][$v] ?? '';
    }

    /** Exit-Popup: Auslöseversuche mit Ablehnungsgrund, nach Gerät und Seite filterbar (letzte 30 Tage) */
    private static function popup_diagnose() {
        global $wpdb;
        $t = $wpdb->prefix . 'ab1_wl_pop2';
        if (!$wpdb->get_var("SHOW TABLES LIKE '$t'")) return '';
        $g = isset($_GET['pg']) && in_array($_GET['pg'], array('d', 'm'), true) ? $_GET['pg'] : '';
        $sq = isset($_GET['pq']) ? (int) $_GET['pq'] : 0;
        $wh = 'tag >= (CURDATE() - INTERVAL 30 DAY)' . ($g ? $wpdb->prepare(' AND geraet=%s', $g) : '') . ($sq ? $wpdb->prepare(' AND quelle=%d', $sq) : '');
        $rows = $wpdb->get_results("SELECT ereignis, grund, SUM(n) n FROM $t WHERE $wh GROUP BY ereignis, grund", ARRAY_A);
        $m = array('i' => 0, 'c' => 0, 'z' => 0, 'b' => 0, 'n' => 0, 'g' => 0);
        $au = array('i' => array('m' => 0, 'h' => 0), 'c' => array('m' => 0, 'h' => 0));
        $xs = array('x' => 0, 'o' => 0, 'k' => 0, 'n' => 0); $xq = 0;
        foreach ($rows as $r) { if ($r['ereignis'] === 'x') { $xs[$r['grund']] = ($xs[$r['grund']] ?? 0) + (int) $r['n']; continue; } if ($r['ereignis'] === 'v') $m[$r['grund']] = (int) $r['n']; else { $m[$r['ereignis']] += (int) $r['n']; if (isset($au[$r['ereignis']][$r['grund']])) $au[$r['ereignis']][$r['grund']] += (int) $r['n']; } }
        $v = $m['i'] + $m['z'] + $m['b'] + $m['n'] + $m['g'];
        $xq = (int) $wpdb->get_var("SELECT SUM(n) FROM $t WHERE ereignis='x' AND schnell=1 AND $wh");
        $va = $wpdb->get_results("SELECT variante, ereignis, grund, SUM(n) n FROM $t WHERE ereignis IN ('i','c','x') AND $wh GROUP BY variante, ereignis, grund ORDER BY variante", ARRAY_A);
        $seiten = $wpdb->get_results("SELECT quelle, SUM(CASE WHEN ereignis='v' OR ereignis='i' THEN n ELSE 0 END) v, SUM(CASE WHEN ereignis='i' THEN n ELSE 0 END) i, SUM(CASE WHEN ereignis='c' THEN n ELSE 0 END) c FROM $t WHERE tag >= (CURDATE() - INTERVAL 30 DAY)" . ($g ? $wpdb->prepare(' AND geraet=%s', $g) : '') . " GROUP BY quelle ORDER BY v DESC LIMIT 30", ARRAY_A);
        $h = '<div class="ab1-karte"><h3>Exit-Popup: Auslöser und Gründe <small>(letzte 30 Tage)</small></h3><form method="get" style="margin:0 0 10px"><input type="hidden" name="page" value="mini-statistik-weiterlesen"> Gerät: <select name="pg"><option value="">alle</option><option value="d"' . selected($g, 'd', false) . '>Desktop</option><option value="m"' . selected($g, 'm', false) . '>Touch (Handy, Tablet)</option></select> Seite: <select name="pq"><option value="0">alle</option>';
        foreach ($seiten as $r) $h .= '<option value="' . (int) $r['quelle'] . '"' . selected($sq, (int) $r['quelle'], false) . '>' . esc_html(wp_html_excerpt(self::titel((int) $r['quelle']), 60, '…')) . ' (' . (int) $r['v'] . ')</option>';
        $h .= '</select> <button class="button button-small">Filtern</button></form>';
        if (!$v) return $h . '<p class="d">Noch keine Daten. Die Zählung der Auslöseversuche läuft ab Version 0.49.1.</p></div>';
        $pc = function ($x) use ($v) { return number_format_i18n(100 * $x / max(1, $v), 1) . ' %'; };
        $h .= '<table class="ab1-t"><thead><tr><th>Was passierte beim Auslösen</th><th>Anzahl</th><th>Anteil</th></tr></thead><tbody>'
            . '<tr><td><b>Popup eingeblendet</b></td><td>' . $m['i'] . '</td><td>' . $pc($m['i']) . '</td></tr>'
            . '<tr><td>&nbsp;&nbsp;davon: Maus oben aus dem Fenster (nur Desktop)</td><td>' . $au['i']['m'] . '</td><td>' . $pc($au['i']['m']) . '</td></tr>'
            . '<tr><td>&nbsp;&nbsp;davon: schnelles Hochscrollen nach über 45 %</td><td>' . $au['i']['h'] . '</td><td>' . $pc($au['i']['h']) . '</td></tr>'
            . '<tr><td>Zu früh (vor Ablauf der eingestellten Sekunden)</td><td>' . $m['z'] . '</td><td>' . $pc($m['z']) . '</td></tr>'
            . '<tr><td>Besucher gesperrt (Popup schon in den letzten Tagen gesehen)</td><td>' . $m['g'] . '</td><td>' . $pc($m['g']) . '</td></tr>'
            . '<tr><td>Besucher hat „Nicht mehr anzeigen“ gewählt</td><td>' . $m['n'] . '</td><td>' . $pc($m['n']) . '</td></tr>'
            . '<tr><td>Auf dieser Seite schon gezeigt</td><td>' . $m['b'] . '</td><td>' . $pc($m['b']) . '</td></tr></tbody></table>'
            . '<p class="d">Klicks im Popup: ' . $m['c'] . ($m['i'] ? ' (' . number_format_i18n(100 * $m['c'] / $m['i'], 1) . ' % der Einblendungen)' : '') . '. Ein Auslöseversuch ist: Maus fährt oben aus dem Fenster (nur Desktop) oder schnelles Hochscrollen nach über 45 % (Desktop und Touch). Klicks nach Auslöser: Maus ' . $au['c']['m'] . ', Hochscrollen ' . $au['c']['h'] . '.  Je Grund und Seitenaufruf wird nur einmal gezählt.</p>';
        $zu = array_sum($xs); $sonst = max(0, $m['i'] - $zu - $m['c']);
        $ap = function ($x) use ($m) { return $m['i'] ? number_format_i18n(100 * $x / $m['i'], 1) . ' %' : '–'; };
        $h .= '<table class="ab1-t" style="margin-top:10px"><thead><tr><th>Wie wurde das Popup beendet (Anteil der Einblendungen)</th><th>Anzahl</th><th>Anteil</th></tr></thead><tbody>'
            . '<tr><td>Klick auf einen Inhalt</td><td>' . $m['c'] . '</td><td>' . $ap($m['c']) . '</td></tr>'
            . '<tr><td>X-Knopf</td><td>' . $xs['x'] . '</td><td>' . $ap($xs['x']) . '</td></tr>'
            . '<tr><td>Klick daneben (dunkler Hintergrund)</td><td>' . $xs['o'] . '</td><td>' . $ap($xs['o']) . '</td></tr>'
            . '<tr><td>Escape-Taste</td><td>' . $xs['k'] . '</td><td>' . $ap($xs['k']) . '</td></tr>'
            . '<tr><td>„Nicht mehr anzeigen“</td><td>' . $xs['n'] . '</td><td>' . $ap($xs['n']) . '</td></tr>'
            . '<tr><td>Seite verlassen oder ohne Schließen weitergescrollt</td><td>' . $sonst . '</td><td>' . $ap($sonst) . '</td></tr></tbody></table>'
            . '<p class="d">Davon sofort weggeklickt (unter 2 Sekunden, meist Reflex): ' . $xq . ($zu ? ' von ' . $zu . ' Schließungen (' . number_format_i18n(100 * $xq / $zu, 0) . ' %)' : '') . '.</p>';
        $vm = array();
        foreach ($va as $r) { $k = $r['variante']; $vm[$k] = $vm[$k] ?? array('i' => 0, 'c' => 0, 'x' => 0, 'o' => 0, 'k' => 0, 'n' => 0); if ($r['ereignis'] === 'x') $vm[$k][$r['grund']] += (int) $r['n']; else $vm[$k][$r['ereignis']] += (int) $r['n']; }
        if ($vm) {
            $h .= '<table class="ab1-t" style="margin-top:10px"><thead><tr><th>Variante</th><th>Eingeblendet</th><th>Klicks</th><th>X</th><th>Daneben</th><th>Esc</th><th>Nicht mehr</th></tr></thead><tbody>';
            foreach ($vm as $k => $r) $h .= '<tr><td><b>' . esc_html(strtoupper($k)) . '</b></td><td>' . $r['i'] . '</td><td>' . $r['c'] . '</td><td>' . $r['x'] . '</td><td>' . $r['o'] . '</td><td>' . $r['k'] . '</td><td>' . $r['n'] . '</td></tr>';
            $h .= '</tbody></table>';
        }
        $h .= '<table class="ab1-t" style="margin-top:10px"><thead><tr><th>Seite</th><th>Versuche</th><th>Eingeblendet</th><th>Klicks</th></tr></thead><tbody>';
        foreach (array_slice($seiten, 0, 10) as $r) $h .= '<tr><td>' . esc_html(self::titel((int) $r['quelle'])) . '</td><td>' . (int) $r['v'] . '</td><td>' . (int) $r['i'] . '</td><td>' . (int) $r['c'] . '</td></tr>';
        return $h . '</tbody></table></div>';
    }

    private static function ergebnis_tabelle($bereich, $titel, $beschreibung) {
        global $wpdb;
        $t = $wpdb->prefix . 'ab1_wl_zaehler';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT variante,ereignis,ziel,SUM(n) n FROM $t WHERE bereich=%s AND tag >= (CURDATE() - INTERVAL 30 DAY) GROUP BY variante,ereignis,ziel", $bereich), ARRAY_A);
        $m = array(); $sz = array(); $cz = array();
        foreach ($rows as $r) {
            $n = (int) $r['n'];
            if ($r['ereignis'] === 's') { $sz[$r['variante']][(int) $r['ziel']] = $n; continue; }
            $m[$r['variante']][$r['ereignis']] = ($m[$r['variante']][$r['ereignis']] ?? 0) + $n;
            if ($r['ereignis'] === 'c') $cz[$r['variante']][(int) $r['ziel']] = $n;
        }
        $h = '<div class="ab1-karte"><h3>' . esc_html($titel) . '</h3><p class="d">' . esc_html($beschreibung) . '</p>';
        if (!$m) return $h . '<p class="d">Noch keine Daten. Die Messung beginnt, sobald die Funktion eingeschaltet ist.</p></div>';
        ksort($m);
        $norm = $sz ? self::normalisiere($sz, $cz) : array();
        $max = 0.0001;
        foreach ($m as $e) { $i = $e['i'] ?? 0; if ($i) $max = max($max, ($e['c'] ?? 0) / $i); }
        $h .= '<table class="ab1-t"><thead><tr><th>Variante</th><th>Was</th><th>Einblendungen</th><th>Klicks</th><th>Klickrate</th><th>95-%-Bereich</th>' . ($norm ? '<th title="Klicks geteilt durch die Klicks, die man bei der durchschnittlichen Beliebtheit der gezeigten Artikel erwartet. 1,0 = wie erwartet.">Bereinigt</th>' : '') . '</tr></thead><tbody>';
        foreach ($m as $v => $e) {
            $i = $e['i'] ?? 0; $c = $e['c'] ?? 0; list($lo, $hi) = self::wilson($c, $i);
            $rate = $i ? $c / $i : 0;
            $h .= '<tr><td><b>' . esc_html(strtoupper($v)) . '</b></td><td>' . esc_html(self::variante_name($bereich, $v)) . '</td><td>' . (int) $i . '</td><td>' . (int) $c . '</td><td><div class="ab1-bar"><i style="width:' . round(100 * $rate / $max) . '%"></i></div>' . ($i ? esc_html(number_format_i18n(100 * $rate, 1)) . ' %' : '–') . '</td><td>' . ($i ? esc_html(number_format_i18n(100 * $lo, 1) . ' – ' . number_format_i18n(100 * $hi, 1)) . ' %' : '–') . '</td>'
                . ($norm ? '<td>' . (isset($norm[$v]['lift']) && $norm[$v]['lift'] !== null ? esc_html(number_format_i18n($norm[$v]['lift'], 2)) : '–') . '</td>' : '') . '</tr>';
        }
        $h .= '</tbody></table>';
        $voll = true; foreach ($m as $e) if (($e['i'] ?? 0) < 300) $voll = false;
        $h .= '<p class="d">' . ($voll ? 'Genug Einblendungen je Variante. Ein Sieger ist erst klar, wenn sich die 95-%-Bereiche nicht überlappen.' : 'Vorläufig: unter 300 Einblendungen je Variante, noch kein Sieger erkennbar.') . ' Es wird nichts automatisch umgestellt.</p></div>';
        return $h;
    }

    /** Als Reiter in der Mini-Statistik: AB1_Weiterlesen::seite() ausgeben (ohne umgebendes wrap). */
    public static function tab() { self::seite(); }

    public static function seite() {
        if (!current_user_can('manage_options')) return;
        $o = self::opt();
        $push = array_pad(array_values((array) $o['push']), 10, 0);
        $gr = self::themen_parsen($o['themen']);
        list($vor, $vquelle) = self::vorschlaege(5);
        $ck = function ($n, $l, $d = '') use ($o) {
            return '<label class="ab1-ck"><input type="checkbox" name="' . esc_attr($n) . '" value="1"' . checked($o[$n], 1, false) . '> <b>' . esc_html($l) . '</b>' . ($d ? '<span class="d">' . esc_html($d) . '</span>' : '') . '</label>';
        };
        $f = function ($n, $l, $w = 'regular-text') use ($o) {
            return '<label class="ab1-f">' . esc_html($l) . '<input name="' . esc_attr($n) . '" value="' . esc_attr($o[$n]) . '" class="' . $w . '"></label>';
        };
        echo '<style>.ab1-w{max-width:1000px}.ab1-karte{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:16px 20px;margin:16px 0}.ab1-karte h3{margin:0 0 4px;font-size:1.15em}.d{display:block;color:#646970;margin:2px 0 8px;font-size:12.5px}'
            . '.ab1-slots{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px}.ab1-slot{border:2px solid #e3e8e0;border-radius:12px;padding:10px;background:#f8faf7;position:relative}.ab1-slot .b{position:absolute;top:-10px;left:10px;background:#2f7d32;color:#fff;border-radius:10px;padding:0 9px;font-weight:700}'
            . '.ab1-slot img{width:100%;aspect-ratio:3/2;object-fit:cover;border-radius:8px;background:#e5eadf}.ab1-slot .t{font-weight:600;min-height:2.6em;margin:6px 0}.ab1-slot input[type=search]{width:100%}.ab1-erg{list-style:none;margin:2px 0 0;padding:0;max-height:180px;overflow:auto;background:#fff;border:1px solid #dcdcde;border-radius:6px}.ab1-erg:empty{display:none}.ab1-erg li{padding:6px 8px;cursor:pointer;margin:0}.ab1-erg li:hover{background:#eef5ec}'
            . '.ab1-vor{display:flex;flex-wrap:wrap;gap:8px}.ab1-vor button{border:1px solid #2f7d32;background:#fff;color:#2f7d32;border-radius:20px;padding:4px 12px;cursor:pointer}.ab1-vor button:hover{background:#2f7d32;color:#fff}'
            . '.ab1-ck{display:block;margin:8px 0}.ab1-f{display:block;margin:8px 0}.ab1-f input{display:block}.ab1-t{border-collapse:collapse;width:100%}.ab1-t th,.ab1-t td{text-align:left;padding:7px 8px;border-bottom:1px solid #eee}.ab1-bar{height:8px;background:#eef2ec;border-radius:4px;margin-bottom:3px;width:140px}.ab1-bar i{display:block;height:100%;background:#2f7d32;border-radius:4px}</style>';
        echo '<div class="wrap ab1-w"><h1>Weiterlesen und Exit-Popup (1AB)</h1>';
        if (!empty($_GET['ok'])) echo '<div class="notice notice-success is-dismissible"><p>Gespeichert.</p></div>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="ab1_wl_speichern">';
        wp_nonce_field('ab1_wl_s');
        echo '<div class="ab1-karte"><h3>Schalter</h3><p class="d">Beides ist standardmäßig aus. Contextual Related Posts bleibt aktiv, bis es nach dem Test bewusst abgeschaltet wird.</p>'
            . $ck('weiterlesen', 'Weiterlesen-Box unter den Artikeln') . $ck('popup', 'Exit-Popup') . $ck('ab', 'A/B-Test der gepushten Artikel in der Weiterlesen-Box')
            . $ck('teaser_oben', 'Position testen: Teaser weiter oben im Artikel gegen nur am Ende', 'Nur zwischen normalen Absätzen, nie in Listen, Tabellen oder Boxen.')
            . $ck('test_optik', 'Optik testen: Bild und Titel gegen nur Titel') . $ck('test_frage', 'Überschrift testen: Frage gegen Aussage')
            . $ck('test_kartenzahl', 'Kartenzahl testen (Varianten A bis D, Zahlen unten)') . $ck('pop_top3', 'Popup-Variante Z: die drei erfolgreichsten Artikel')
            . $ck('qualitaet', 'Erfolgreiche Artikel häufiger empfehlen (Scrolltiefe, Verweildauer, Klicks aus der Statistik; sonst GA-Import)') . '</div>';
        echo '<div class="ab1-karte"><h3>Gepushte Artikel (bis zu zehn, Varianten A bis J)</h3><p class="d">Tippe einen Titel in ein Feld und wähle den Artikel. Jeder gepushte Artikel erscheint im Popup und auf Platz 1 der Weiterlesen-Box. Welcher, entscheidet je Besucher die serverseitige Kennung plus Tageszahl (wechselt täglich, nichts im Browser).</p><div class="ab1-slots">';
        foreach ($push as $i => $pid) {
            $L = chr(65 + $i);
            $bild = $pid ? get_the_post_thumbnail_url($pid, 'medium') : '';
            echo '<div class="ab1-slot" data-i="' . $i . '"><span class="b">' . $L . '</span>' . ($bild ? '<img src="' . esc_url($bild) . '" alt="">' : '<img alt="" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==">')
                . '<div class="t">' . ($pid ? esc_html(self::titel($pid)) : 'noch leer') . '</div><input type="hidden" name="push[' . $i . ']" value="' . (int) $pid . '">'
                . '<input type="search" placeholder="Artikel suchen …" autocomplete="off"><ul class="ab1-erg"></ul><label class="d">Zeigen unter: <select name="push_thema[' . $i . ']">' . implode('', array_map(function ($k, $l) use ($o, $i) { return '<option value="' . esc_attr($k) . '"' . selected((string) ($o['push_thema'][$i] ?? 'alle'), $k, false) . '>' . esc_html($l) . '</option>'; }, array_merge(array('alle'), array_keys($gr)), array_merge(array('allen Artikeln'), array_map(function ($g) { return $g['name'] . '-Artikeln'; }, array_values($gr))))) . '</select></label><a href="#" class="ab1-weg">entfernen</a></div>';
        }
        echo '</div>' . $ck('push_themenfrei', 'Gepushte Artikel auch unter Artikeln anderer Kategorie zeigen', 'Sprache, noindex und gleiches Fokus-Keyword werden weiter geprüft. Aus = nur bei gleicher Kategorie, dann sehen weniger Seiten den Test.') . '</div>';
        echo '<div class="ab1-karte"><h3>Vorschläge nach Besucherzahlen</h3><p class="d">Meistbesuchte Artikel der letzten 30 Tage (Quelle: ' . esc_html($vquelle) . '), höchstens zwei je Kategorie. Klick übernimmt in den nächsten freien Platz.</p><div class="ab1-vor">';
        foreach ($vor as $r) echo '<button type="button" data-id="' . (int) $r['id'] . '" data-t="' . esc_attr(self::titel($r['id'])) . '" data-b="' . esc_url(get_the_post_thumbnail_url($r['id'], 'medium')) . '">' . esc_html(self::titel($r['id'])) . ($r['aufrufe'] ? ' · ' . (int) $r['aufrufe'] : '') . '</button>';
        echo '</div></div>';
        echo '<div class="ab1-karte"><h3>Einstellungen</h3>' . $f('ueberschrift', 'Überschrift der Box (Aussage)') . $f('ueberschrift_frage', 'Überschrift der Box (Frage)') . $f('kartenzahlen', 'Kartenzahlen für den Test, kommagetrennt, bis zu vier', 'regular-text') . $f('bio_woerter', 'Stichwörter für Biodiversität', 'large-text') . '<label class="ab1-f">Themengruppen dieser Seite (optional). Eine Zeile je Gruppe: <code>Name: Wort1, Wort2</code>. Artikel verschiedener Gruppen werden nie gegenseitig empfohlen, und Push-Plätze lassen sich auf eine Gruppe begrenzen. Beispiel: <code>Maulwurf: maulwurf, maulwürf</code> und <code>Wühlmaus: wühlmaus, wühlmäus, schermaus</code>.<textarea name="themen" rows="4" class="large-text" placeholder="Name: Wort1, Wort2">' . esc_textarea($o['themen']) . '</textarea></label>' . $f('push_sperre', 'Sperrwörter im Titel: solche Artikel werden nie gepusht', 'regular-text') . $f('anzahl', 'Anzahl Karten (1–6)', 'small-text') . $f('teaser_absatz', 'Teaser nach Absatz Nr.', 'small-text')
            . $f('pop_sek', 'Popup frühestens nach … Sekunden', 'small-text') . $f('pop_tage', 'Popup höchstens alle … Tage je Besucher', 'small-text')
            . $f('pop_titel', 'Popup-Titel') . $f('pop_knopf', 'Popup-Knopftext') . $f('pop_nein', 'Text „Nicht mehr anzeigen“') . '</div>';
        echo '<p><button class="button button-primary button-hero">Speichern</button></p></form>';
        $bio = self::bio_kandidaten(40);
        echo '<div class="ab1-karte"><h3>Artikel mit Biodiversitätsbezug</h3><p class="d">Diese Artikel enthalten Stichwörter aus der Liste oder sind schon markiert. Hake die an, die wirklich zu Biodiversitätsmaßnahmen führen. Sie werden bei den Empfehlungen bevorzugt.</p><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="ab1_wl_bio">';
        wp_nonce_field('ab1_wl_bio');
        echo '<input type="hidden" name="bio_alle" value="' . esc_attr(implode(',', array_keys($bio))) . '">';
        foreach ($bio as $id => $tr) echo '<label class="ab1-ck"><input type="checkbox" name="bio_ids[]" value="' . (int) $id . '"' . checked(self::ist_bio($id), true, false) . '> ' . esc_html(self::titel($id)) . ' <span class="d" style="display:inline">(' . (int) $tr . ' Treffer)</span></label>';
        if (!$bio) echo '<p class="d">Keine Treffer.</p>';
        echo '<p><button class="button">Markierung speichern</button></p></form></div>';
        echo '<h2>Vorläufige Ergebnisse, letzte 30 Tage</h2>'
            . self::ergebnis_tabelle('pu', 'Exit-Popup', 'Eine Einblendung zählt, wenn das Popup erscheint; ein Klick, wenn der Artikel angeklickt wird.')
            . self::popup_diagnose()
            . self::ergebnis_tabelle('wl', 'Weiterlesen-Box, Platz 1', 'Einblendung zählt, wenn mindestens die Hälfte der Box im Sichtbereich war.')
            . self::ergebnis_tabelle('wk', 'Weiterlesen-Box: Kartenzahl', 'Welche Anzahl Karten wird am besten geklickt (Spalte „Bereinigt“ rechnet die Beliebtheit der gezeigten Artikel heraus).')
            . self::ergebnis_tabelle('wo', 'Weiterlesen-Box: Bild und Titel gegen nur Titel', 'Gleiche Artikel, nur andere Optik.')
            . self::ergebnis_tabelle('wf', 'Weiterlesen-Box: Frage gegen Aussage', 'Gleiche Artikel, nur andere Überschrift.')
            . self::ergebnis_tabelle('wp', 'Position: Teaser oben gegen nur Ende', 'Klicks auf alle Empfehlungen des Artikels.')
            . self::ergebnis_tabelle('tz', 'Teaser weiter oben', 'Nur der Teaser selbst.');
        $z = $GLOBALS['wpdb']->prefix . 'ab1_wl_zaehler';
        $top = $GLOBALS['wpdb']->get_results("SELECT ziel, SUM(n) n FROM $z WHERE ereignis='c' AND bereich='wl' AND tag >= (CURDATE() - INTERVAL 30 DAY) GROUP BY ziel ORDER BY n DESC LIMIT 10", ARRAY_A);
        if ($top) { echo '<div class="ab1-karte"><h3>Meistgeklickte Weiterlesen-Ziele</h3><ol>'; foreach ($top as $r) echo '<li>' . esc_html(self::titel((int) $r['ziel'])) . ' (' . (int) $r['n'] . ')</li>'; echo '</ol></div>'; }
        $api = esc_url_raw(rest_url(self::REST . '/suche'));
        echo '</div><script>(function(){var A=' . wp_json_encode($api) . ',N=' . wp_json_encode(wp_create_nonce('wp_rest')) . ';'
            . 'function set(sl,id,t,b){sl.querySelector("input[type=hidden]").value=id;sl.querySelector(".t").textContent=t||"noch leer";if(b)sl.querySelector("img").src=b;sl.querySelector(".ab1-erg").innerHTML="";}'
            . 'function suche(inp,ul,sl){var q=inp.value.trim();ul.innerHTML="<li>Suche …</li>";fetch(A+"?q="+encodeURIComponent(q),{headers:{"X-WP-Nonce":N},credentials:"same-origin"}).then(function(r){if(!r.ok)throw new Error(r.status);return r.json()}).then(function(j){ul.innerHTML="";if(!j.length){ul.innerHTML="<li>Nichts gefunden</li>";return}j.forEach(function(p){var li=document.createElement("li");li.textContent=p.titel+" ("+p.typ+", Nr. "+p.id+")";li.onclick=function(){set(sl,p.id,p.titel,p.bild);inp.value=""};ul.appendChild(li)})}).catch(function(e){ul.innerHTML="<li>Suche nicht möglich ("+e.message+"). Seite neu laden.</li>"})}'
            . '[].forEach.call(document.querySelectorAll(".ab1-slot"),function(sl){var inp=sl.querySelector("input[type=search]"),ul=sl.querySelector(".ab1-erg"),tm;'
            . 'inp.addEventListener("input",function(){clearTimeout(tm);tm=setTimeout(function(){suche(inp,ul,sl)},250)});inp.addEventListener("focus",function(){if(!inp.value.trim())suche(inp,ul,sl)});'
            . 'sl.querySelector(".ab1-weg").onclick=function(e){e.preventDefault();set(sl,0,"","")}});'
            . '[].forEach.call(document.querySelectorAll(".ab1-vor button"),function(b){b.onclick=function(){var s=[].slice.call(document.querySelectorAll(".ab1-slot")).filter(function(x){return x.querySelector("input[type=hidden]").value==="0"})[0];if(s)set(s,b.getAttribute("data-id"),b.getAttribute("data-t"),b.getAttribute("data-b"))}})})();</script>';
    }
}

