<?php
/**
 * Plugin Name: 1AB-Test-Statistik
 * Description: Cookielose, datensparsame Besucherstatistik für mehrere Seiten (Aufrufe, Verweildauer, Scrolltiefe, Klicks auf Partnerlinks, Echtzeit). Eine Seite ist die Zentrale (Hub), die anderen senden dorthin.
 * Version: 0.50.1
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/weiterlesen-modul.php';

class Mini_Statistik {
    const OPT = 'mini_statistik';
    const VERSION = '0.50.1';
    const DB_VERSION = '15';
    // Ein gemeinsames Repo mit dem Amazon-Plugin: die Statistik liegt im Unterordner statistik/
    const UPDATE_REPO = 'https://github.com/Aleeeb/schlanke-amazon-box-/';
    const UPDATE_DIR = 'https://github.com/Aleeeb/schlanke-amazon-box-/raw/main/statistik/';
    const UPDATE_JSON = 'https://raw.githubusercontent.com/Aleeeb/schlanke-amazon-box-/main/statistik/update.json';

    static function opts() {
        return wp_parse_args(get_option(self::OPT, []), [
            'mode' => 'off',      // off | hub | client
            'hub_url' => '',      // nur Client: https://hub-seite.de
            'site_key' => '',     // Kennwort dieser Seite, am Hub eingetragen
            'sites' => '',        // nur Hub: eine Zeile je Seite "domain|key"
            'keep_days' => 0,     // nur Hub: Aufbewahrung in Tagen, 0 = unbegrenzt
            'salt_days' => 7,     // nur Hub: so viele Tage bleibt die Besucher-Kennung gültig (1 = täglich neu)
            'mail_status' => 1,   // nur Hub: Mail bei Verschlechterung des Status (höchstens einmal täglich)
            'mail_to' => '',      // nur Hub: Empfänger, leer = Admin-Adresse der Seite
            'mail_alarm' => 1,    // nur Hub: Sofortwarnung bei roten Werten, Fehlern oder fehlenden Messwerten
        ]);
    }

    static function init() {
        register_activation_hook(__FILE__, [__CLASS__, 'activate']);
        add_filter('ab1_wl_eigenes_menue', '__return_false');
        add_filter('ab1_wl_seiten_url', function () { return admin_url('admin.php?page=mini-statistik-weiterlesen'); });
        AB1_Weiterlesen::init();
        add_action('rest_api_init', [__CLASS__, 'routes']);
        add_action('wp_footer', [__CLASS__, 'print_script'], 99);
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('mini_statistik_cleanup', [__CLASS__, 'cleanup']);
        add_action('ms_status_mail', [__CLASS__, 'status_mail']);
        add_action('ms_status_alarm', [__CLASS__, 'alarm']);
        add_action('admin_bar_menu', [__CLASS__, 'admin_leiste'], 90);
        add_action('wp_ajax_mini_statistik_live', [__CLASS__, 'live']);
        add_action('admin_init', [__CLASS__, 'maybe_upgrade']);
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'update_pruefen']);
        add_filter('upgrader_pre_download', [__CLASS__, 'update_summe_pruefen'], 5, 2); // Priorität 5: vor der Prüfung des Amazon-Plugins, damit dessen Summe nie auf unser ZIP angewendet wird
        add_action('ms_update_check', [__CLASS__, 'update_cron']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($l) { array_unshift($l, '<a href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=mini-statistik&ms_update_jetzt=1'), 'ms_update_jetzt')) . '">Nach Updates suchen</a>'); return $l; });
        add_action('admin_init', [__CLASS__, 'update_admin']);
    }

    // ---------- Update-Prüfung mit wechselndem Abstand (wie bei 1AB Affiliate Help) ----------

    /** Alter der letzten Neuerung (Sekunden) => Abstand der Prüfung (Sekunden); danach einmal am Tag. Viele Versionen nacheinander: Minutentakt. */
    const UPD_STUFEN = [[1800, 60], [7200, 180], [21600, 600], [86400, 1800], [259200, 7200]];

    static function update_intervall() {
        $st = (array)get_option('ms_upd_stat', []); $alter = time() - (int)($st['neu'] ?? 0);
        foreach (self::UPD_STUFEN as $u) { if ($alter <= $u[0]) return $u[1]; }
        return DAY_IN_SECONDS;
    }

    /** Merkt, wann zuletzt eine neue Version zu sehen war (bei GitHub oder frisch installiert): davon hängt der Prüfabstand ab. */
    private static function update_merken($json_version) {
        $st = (array)get_option('ms_upd_stat', []); $neu = false;
        if ($json_version !== '' && ($st['json'] ?? '') !== $json_version) { $st['json'] = $json_version; $neu = true; }
        if (($st['inst'] ?? '') !== self::VERSION) { $st['inst'] = self::VERSION; $neu = true; }
        if ($neu) { $st['neu'] = time(); update_option('ms_upd_stat', $st, false); }
    }

    /** Fragt GitHub jetzt (oder wenn der Abstand um ist) nach einer neuen Version und trägt sie sofort bei WordPress ein. @return string neue Version oder leer */
    static function update_nachsehen($jetzt = false) {
        if (!$jetzt && time() < (int)get_option('ms_upd_naechste', 0)) return '';
        delete_transient('ms_update_json');
        $key = plugin_basename(__FILE__);
        $t = get_site_transient('update_plugins'); if (!is_object($t)) $t = new stdClass();
        if (empty($t->checked) || !is_array($t->checked)) $t->checked = [];
        if (!isset($t->checked[$key])) $t->checked[$key] = self::VERSION;
        if (empty($t->last_checked)) $t->last_checked = time();
        foreach (['response', 'no_update'] as $f) { if (!isset($t->$f) || !is_array($t->$f)) $t->$f = []; }
        unset($t->response[$key], $t->no_update[$key]);
        $t = self::update_pruefen($t);
        set_site_transient('update_plugins', $t);
        $st = (array)get_option('ms_update_status', []);
        $abstand = ($st['code'] ?? '200') === '200' ? self::update_intervall() : HOUR_IN_SECONDS; // bei Fehlern (z. B. Repo nicht erreichbar) selten wiederholen
        update_option('ms_upd_naechste', time() + $abstand, false);
        return isset($t->response[$key]) ? (string)$t->response[$key]->new_version : '';
    }

    /** Nur im Admin: Abstand um? Dann nachsehen (ein Optionswert pro Aufruf, im Frontend läuft nichts). Hält die Kette der Hintergrundläufe am Leben. */
    static function update_admin() {
        if (!current_user_can('update_plugins') || (defined('DOING_AJAX') && DOING_AJAX)) return;
        self::update_nachsehen(false);
        if (!wp_next_scheduled('ms_update_check')) wp_schedule_single_event(time() + max(60, self::update_intervall()), 'ms_update_check');
    }

    /** Hintergrundlauf: nachsehen, bei neuer Version und eingeschalteten Auto-Updates nur dieses Plugin einspielen lassen, nächsten Lauf planen. */
    static function update_cron() {
        $neu = self::update_nachsehen(true); $key = plugin_basename(__FILE__);
        if ($neu !== '' && in_array($key, (array)get_site_option('auto_update_plugins', []), true) && function_exists('wp_maybe_auto_update')) {
            $nur = function ($u, $i) use ($key) { return is_object($i) && (string)($i->plugin ?? '') === $key; };
            add_filter('auto_update_plugin', $nur, 99999, 2); wp_maybe_auto_update(); remove_filter('auto_update_plugin', $nur, 99999);
        }
        $st = (array)get_option('ms_update_status', []);
        wp_schedule_single_event(time() + max(60, ($st['code'] ?? '200') === '200' ? self::update_intervall() : HOUR_IN_SECONDS), 'ms_update_check');
    }

    /** Steht in der update-JSON eine SHA-256-Summe, wird das ZIP vor dem Einspielen damit geprüft; bei Abweichung wird nichts installiert. Nur für unser ZIP. */
    static function update_summe_pruefen($reply, $package) {
        if ($reply !== false || !is_string($package) || strpos($package, self::UPDATE_DIR) !== 0) return $reply;
        $m = get_transient('ms_update_json');
        $h = is_array($m) ? strtolower((string)($m['sha256'] ?? '')) : '';
        if (!preg_match('/^[a-f0-9]{64}$/', $h)) return $reply;
        if (!function_exists('download_url')) require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url($package, 300);
        if (is_wp_error($file)) return $file;
        if (!hash_equals($h, (string)hash_file('sha256', $file))) { @unlink($file); return new WP_Error('ms_summe', 'Prüfsumme des Updates stimmt nicht. Es wurde nichts installiert.'); }
        return $file;
    }

    /** Meldet WordPress eine neuere Version aus update.json im GitHub-Repo; das ZIP muss aus diesem Repo stammen. */
    static function update_pruefen($t) {
        if (!is_object($t) || empty($t->checked)) return $t;
        if (isset($_GET['force-check'])) delete_transient('ms_update_json');
        $m = get_transient('ms_update_json');
        if ($m === false) {
            $r = wp_remote_get(self::UPDATE_JSON . '?t=' . time(), ['timeout' => 8]);
            $code = is_wp_error($r) ? $r->get_error_message() : wp_remote_retrieve_response_code($r);
            $m = (!is_wp_error($r) && $code === 200) ? json_decode((string)wp_remote_retrieve_body($r), true) : [];
            update_option('ms_update_status', ['ts' => time(), 'code' => (string)$code, 'version' => is_array($m) ? (string)($m['version'] ?? '') : ''], false);
            self::update_merken(is_array($m) ? (string)($m['version'] ?? '') : '');
            set_transient('ms_update_json', is_array($m) ? $m : [], $m ? max(60, self::update_intervall()) : 5 * MINUTE_IN_SECONDS);
        }
        $v = (string)($m['version'] ?? ''); $zip = (string)($m['zip'] ?? '');
        $key = plugin_basename(__FILE__);
        if ($v === '' || strpos($zip, self::UPDATE_DIR) !== 0) { // Quelle nicht erreichbar: trotzdem als „kein Update“ melden, damit WordPress den Schalter „Automatische Updates“ anbietet
            $t->no_update[$key] = (object)['id' => 'github.com/Aleeeb/schlanke-amazon-box-/statistik', 'slug' => 'mini-statistik', 'plugin' => $key, 'new_version' => self::VERSION, 'package' => '', 'url' => self::UPDATE_REPO];
            return $t;
        }
        $e = (object)['id' => 'github.com/Aleeeb/schlanke-amazon-box-/statistik', 'slug' => 'mini-statistik', 'plugin' => $key, 'new_version' => $v, 'package' => $zip, 'url' => self::UPDATE_REPO];
        if (version_compare($v, self::VERSION, '<=')) $t->no_update[$key] = $e; else $t->response[$key] = $e;
        return $t;
    }

    static function table() { global $wpdb; return $wpdb->prefix . 'mini_statistik'; }
    static function table_ga() { global $wpdb; return $wpdb->prefix . 'mini_statistik_ga'; }

    static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $t = self::table();
        dbDelta("CREATE TABLE $t (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            day DATE NOT NULL,
            ts DATETIME NOT NULL,
            kind VARCHAR(5) NOT NULL DEFAULT 'view',
            site VARCHAR(100) NOT NULL,
            path VARCHAR(255) NOT NULL,
            visitor CHAR(16) NOT NULL,
            ref VARCHAR(100) NOT NULL DEFAULT '',
            device VARCHAR(10) NOT NULL DEFAULT '',
            cc CHAR(2) NOT NULL DEFAULT '',
            target VARCHAR(100) NOT NULL DEFAULT '',
            label VARCHAR(80) NOT NULL DEFAULT '',
            item VARCHAR(20) NOT NULL DEFAULT '',
            img VARCHAR(500) NOT NULL DEFAULT '',
            pn VARCHAR(100) NOT NULL DEFAULT '',
            via VARCHAR(3) NOT NULL DEFAULT '',
            secs SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            scroll TINYINT UNSIGNED NOT NULL DEFAULT 0,
            hum TINYINT UNSIGNED NOT NULL DEFAULT 0,
            br VARCHAR(10) NOT NULL DEFAULT '',
            os VARCHAR(10) NOT NULL DEFAULT '',
            lg CHAR(2) NOT NULL DEFAULT '',
            wb TINYINT UNSIGNED NOT NULL DEFAULT 0,
            utm VARCHAR(60) NOT NULL DEFAULT '',
            ld SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            lc SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            cl SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            ip SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            tt SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            fc SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            kb SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            rq SMALLINT UNSIGNED NOT NULL DEFAULT 0,
            cn TINYINT UNSIGNED NOT NULL DEFAULT 0,
            je TINYINT UNSIGNED NOT NULL DEFAULT 0,
            pf TINYINT UNSIGNED NOT NULL DEFAULT 0,
            rf TINYINT UNSIGNED NOT NULL DEFAULT 0,
            hr VARCHAR(200) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            KEY day_site (day, site),
            KEY ts (ts),
            KEY vis (visitor, day)
        ) {$wpdb->get_charset_collate()};");
        $g = self::table_ga();
        dbDelta("CREATE TABLE $g (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            day DATE NOT NULL,
            site VARCHAR(100) NOT NULL,
            path VARCHAR(255) NOT NULL DEFAULT '',
            views INT UNSIGNED NOT NULL DEFAULT 0,
            users INT UNSIGNED NOT NULL DEFAULT 0,
            secs INT UNSIGNED NOT NULL DEFAULT 0,
            to_day DATE NULL DEFAULT NULL,
            PRIMARY KEY (id),
            KEY site_day (site, day)
        ) {$wpdb->get_charset_collate()};");
        AB1_Weiterlesen::aktivieren();
        if (!wp_next_scheduled('mini_statistik_cleanup')) wp_schedule_event(time() + 3600, 'daily', 'mini_statistik_cleanup');
        if (!wp_next_scheduled('ms_status_mail')) wp_schedule_event(time() + 7200, 'daily', 'ms_status_mail');
        if (!wp_next_scheduled('ms_status_alarm')) wp_schedule_event(time() + 1800, 'hourly', 'ms_status_alarm');
    }

    static function maybe_upgrade() {
        if (get_option('mini_statistik_db') !== self::DB_VERSION) {
            self::activate();
            global $wpdb; $t = self::table();
            // einmalig: bisherige Zeilen von Besuchern mit Bewegungssignal als „Mensch“ markieren (hum = 1)
            if ($wpdb->get_var("SHOW COLUMNS FROM $t LIKE 'hum'")) $wpdb->query("UPDATE $t a JOIN (SELECT DISTINCT site, day, visitor FROM $t WHERE kind='human') h ON h.site=a.site AND h.day=a.day AND h.visitor=a.visitor SET a.hum=1 WHERE a.hum=0 AND a.kind<>'robot'");
            update_option('mini_statistik_db', self::DB_VERSION, false);
        }
    }

    static function cleanup() {
        global $wpdb;
        $keep = (int)self::opts()['keep_days'];
        if ($keep < 1) return; // 0 = nichts löschen
        $wpdb->query($wpdb->prepare('DELETE FROM ' . self::table() . ' WHERE day < %s', gmdate('Y-m-d', time() - $keep * 86400)));
    }

    // ---------- Zählskript (alle Seiten) ----------
    static function print_script() {
        $o = self::opts();
        $why = $o['mode'] === 'off' ? 'aus' : (is_admin() ? 'admin' : (is_user_logged_in() ? 'angemeldet' : ((is_preview() || is_customize_preview()) ? 'vorschau' : (($o['mode'] === 'client' && !$o['hub_url']) ? 'keine-zentrale' : 'ok'))));
        echo "\n<!-- mini-statistik 0.50.1 {$o['mode']} {$why} -->\n";
        if ($why === 'angemeldet' && current_user_can('edit_posts')) echo '<script>try{localStorage.setItem("ms_off","1")}catch(e){}</script>' . "\n"; // eigenes Gerät markieren: Besuche ohne Anmeldung zählen dann auch nicht
        if ($why !== 'ok') return;
        // ?rest_route= funktioniert unabhängig von den Permalink-Einstellungen
        if ($o['mode'] === 'hub') $endpoint = home_url('/?rest_route=/mini-statistik/v1/hit');
        else $endpoint = trailingslashit($o['hub_url']) . '?rest_route=/mini-statistik/v1/hit';
        if ($o['mode'] === 'client' && !$o['hub_url']) return;
        $site = wp_parse_url(home_url(), PHP_URL_HOST);
        $key = $o['site_key'];
        if ($o['mode'] === 'hub' && $key === '') $key = self::allowed_sites()[preg_replace('/^www\./', '', strtolower($site))] ?? '';
        $payload = ['e' => $endpoint, 's' => $site, 'k' => $key];
        if (is_404()) $payload['n4'] = 1;
        if (is_search()) { $payload['q'] = mb_substr((string)get_search_query(false), 0, 100); $payload['f'] = (int)$GLOBALS['wp_query']->found_posts; }
        // Roboter ohne JavaScript sieht nur der Server: Zugriff vermerken (je Roboter und Seite höchstens alle 10 Minuten; der Seitenaufbau wartet nicht darauf)
        $ua_ = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (self::is_bot($ua_) && !is_404() && ($bi = self::bot_info($ua_))) {
            $rp = substr(wp_parse_url('http://x' . (string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/', 0, 255);
            $tk = 'ms_rb_' . md5($bi[0] . $rp);
            if (get_transient($tk) === false) {
                set_transient($tk, 1, 600);
                if ($o['mode'] === 'hub') self::note_robot(preg_replace('/^www\./', '', strtolower($site)), $rp, $ua_, 'srv');
                else wp_remote_post($endpoint, ['blocking' => false, 'timeout' => 0.5, 'headers' => ['Content-Type' => 'text/plain'], 'body' => wp_json_encode(['t' => 'r', 's' => $site, 'k' => $key, 'p' => $rp, 'u' => $ua_])]);
            }
        }
        ?>
<script>(function(){var c=<?php echo wp_json_encode($payload); ?>;if(navigator.doNotTrack==="1")return;try{if(localStorage.getItem("ms_off"))return;}catch(e){}
function send(d){d.s=c.s;d.k=c.k;d.p=location.pathname;try{var b=new Blob([JSON.stringify(d)],{type:"text/plain"});
if(!(navigator.sendBeacon&&navigator.sendBeacon(c.e,b)))fetch(c.e,{method:"POST",body:b,keepalive:true,mode:"no-cors"});}catch(e){}}
var tz="";try{tz=Intl.DateTimeFormat().resolvedOptions().timeZone||"";}catch(e){}
var wd=0;try{wd=(navigator.webdriver===true||/HeadlessChrome|PhantomJS/i.test(navigator.userAgent)||!navigator.languages||!navigator.languages.length)?1:0;}catch(e){}
var sq=c.q||"";if(!sq){try{sq=new URLSearchParams(location.search).get("s")||"";}catch(e){}}
var um="";try{var up=new URLSearchParams(location.search);um=(up.get("utm_source")||"")+"|"+(up.get("utm_medium")||"")+"|"+(up.get("utm_campaign")||"");if(um==="||")um="";}catch(e){}
var cls=0,cw=0,cs=0,cl0=0,inp=0,fcp=0,jn=0,rn=0,ec=0;
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.hadRecentInput)return;var t=e.startTime;if(cw&&t-cl0<1000&&t-cs<5000){cw+=e.value;}else{cw=e.value;cs=t;}cl0=t;if(cw>cls)cls=cw;});}).observe({type:"layout-shift",buffered:true});}catch(e){}
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.interactionId&&e.duration>inp)inp=Math.round(e.duration);});}).observe({type:"event",durationThreshold:40,buffered:true});}catch(e){}
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.name==="first-contentful-paint")fcp=Math.round(e.startTime);});}).observe({type:"paint",buffered:true});}catch(e){}
function ps(u){try{var a=new URL(u,location.href);return(a.host===location.host?"":a.host)+a.pathname;}catch(x){return "";}}
function ev(k,x){if(ec>=3)return;ec++;send({t:"e",ek:k,x:String(x).slice(0,120)});}
addEventListener("error",function(e){var t=e.target;if(t&&t!==window&&t.tagName){if(/^(IMG|SCRIPT|LINK|IFRAME)$/.test(t.tagName)){rn++;ev("r",t.tagName.toLowerCase()+" "+ps(t.src||t.href||""));}return;}jn++;ev("j",(e.error&&e.error.name||"Error")+" @ "+ps(e.filename||"")+":"+(e.lineno||0));},true);
addEventListener("unhandledrejection",function(){jn++;ev("j","UnhandledRejection");});
function nv(){try{var n=performance.getEntriesByType("navigation")[0],r=performance.getEntriesByType("resource"),i,kb=n?n.transferSize||0:0;for(i=0;i<r.length;i++)kb+=r[i].transferSize||0;return{tt:n?Math.round(n.responseStart):0,kb:Math.round(kb/1024),rq:r.length+1};}catch(x){return{tt:0,kb:0,rq:0};}}
var lcp=0;try{new PerformanceObserver(function(l){var e=l.getEntries();if(e.length)lcp=Math.round(e[e.length-1].startTime);}).observe({type:"largest-contentful-paint",buffered:true});}catch(e){}
send({t:"v",r:document.referrer,w:screen.width,z:tz,g:(navigator.language||""),a:wd,q:sq.slice(0,100),f:c.f,n4:c.n4||0,u:um.slice(0,90),vw:window.innerWidth||screen.width});
var hs=0,hev=["pointermove","pointerdown","touchstart","keydown","wheel","scroll"];function hu(){if(hs)return;hs=1;hev.forEach(function(n){removeEventListener(n,hu,true);});send({t:"h"});}
hev.forEach(function(n){addEventListener(n,hu,{capture:true,passive:true});});
var act=0,last=Date.now(),vis=!document.hidden,sc=0,pend=0,out=0;
function tick(){var n=Date.now();if(vis)act+=n-last;last=n;}
function scrolled(){var h=document.documentElement.scrollHeight||1,p=Math.round(100*((window.pageYOffset||0)+window.innerHeight)/h);if(p>sc)sc=Math.min(100,p);}
var ls=0;function lt(){try{var n=performance.getEntriesByType("navigation")[0];return n&&n.loadEventEnd>0?Math.round(n.loadEventEnd):0;}catch(e){return 0;}}
function flush(){tick();var s=Math.round(act/1000);if(s>=1){var d={t:"t",x:Math.min(s,1800),g:sc};if(!ls){ls=1;d.ld=lt();d.lc=lcp;var m=nv(),cn=(navigator.connection&&navigator.connection.effectiveType)||"";d.tt=m.tt;d.kb=m.kb;d.rq=m.rq;d.cl=Math.round(cls*1000);d.ip=inp;d.fc=fcp;d.je=jn;d.rf=rn;d.cn=cn==="3g"?2:cn==="4g"?3:/2g/.test(cn)?1:0;d.w=window.innerWidth||0;var mq=function(q){try{return matchMedia(q).matches?1:0}catch(e){return 0}};d.pf=mq("(prefers-color-scheme: dark)")+2*((window.devicePixelRatio||1)>=1.5?1:0)+4*mq("(orientation: landscape)")+8*mq("(prefers-reduced-motion: reduce)")+16*((navigator.connection&&navigator.connection.saveData)?1:0);}send(d);act=0;}}
addEventListener("scroll",scrolled,{passive:true});scrolled();
function back(){if(!pend)return;var d=Math.round((Date.now()-out)/1000);pend=0;if(d>=1&&d<=10800)send({t:"b",d:d});}
document.addEventListener("visibilitychange",function(){tick();vis=!document.hidden;last=Date.now();if(document.hidden)flush();else back();});
addEventListener("pageshow",function(e){if(e.persisted){last=Date.now();vis=!document.hidden;back();}});
addEventListener("pagehide",flush);
function item(a){var m,p=a.pathname||"";if(/amazon|amzn/i.test(a.hostname)){m=p.match(/\/(?:dp|gp\/product|gp\/aw\/d|exec\/obidos\/ASIN|ASIN)\/([A-Z0-9]{10})/i);return m?m[1].toUpperCase():"";}
if(/ebay\./i.test(a.hostname)){m=p.match(/\/itm\/(?:[^\/]*\/)?(\d{9,})/)||(a.search||"").match(/[?&]item=(\d{9,})/);return m?m[1]:"";}return "";}
function cl(s){return (s||"").replace(/\s+/g," ").trim();}
function gen(s){return s.length<4||/^(angebot|jetzt|zum |zur |bei |auf amazon|auf ebay|amazon$|ebay$|ansehen|kaufen|mehr|hier$|link|weiter|preis|produkt$)/i.test(s);}
function src(i){if(!i)return "";var c=[i.getAttribute("data-src"),i.getAttribute("data-lazy-src"),i.getAttribute("data-orig-file"),i.currentSrc,i.src,(i.getAttribute("data-srcset")||i.getAttribute("srcset")||"").split(/\s+/)[0]],k,s;for(k=0;k<c.length;k++){s=c[k]||"";if(s.indexOf("//")===0)s=location.protocol+s;if(/^https?:/i.test(s))return s.split("?")[0].slice(0,500);}return "";}
function ph(a){var e=a,k,s,h;for(k=0;k<8&&e;k++){s=e.previousElementSibling;while(s){if(/^H[1-6]$/.test(s.tagName))return cl(s.textContent);h=s.querySelectorAll?s.querySelectorAll("h2,h3,h4"):[];if(h.length)return cl(h[h.length-1].textContent);s=s.previousElementSibling;}e=e.parentElement;}return "";}
function bx(a){var e=a,n=0,h=(a.hostname.split(".").slice(-2,-1)[0]||"x");while(e.parentElement&&n<3){e=e.parentElement;n++;if(e.querySelectorAll('a[href*="'+h+'"]').length>4)return null;if(e.querySelector("img"))return e;}return null;}
function lc(td){var n=0,e=td.previousElementSibling;while(e){n+=e.colSpan||1;e=e.previousElementSibling;}return n;}
function shop(h){return /amazon|amzn/i.test(h)?"a":/ebay\./i.test(h)?"e":"";}
function tbl(a){var td=a.closest("td,th"),t=td&&td.closest("table"),r,c,k,x,j,w,l,e,z;if(!t)return null;c=lc(td);r=td.parentElement.rowIndex;
for(k=r-1;k>=0&&k>=r-6;k--){x=t.rows[k];if(!x)continue;for(j=0;j<x.cells.length;j++){w=lc(x.cells[j]);if(c>=w&&c<w+(x.cells[j].colSpan||1)){l=x.cells[j].querySelectorAll("a[href]");for(e=0;e<l.length;e++){z=item(l[e]);if(z&&shop(l[e].hostname)===shop(a.hostname))return{it:z,i:l[e].querySelector("img")};}}}}return null;}
function tnm(a){var td=a.closest("td,th"),t=td&&td.closest("table"),c,r,k,x,j,w,s,z,o=a.querySelector("img")?[1,-1]:[-1,1];if(!t)return "";c=lc(td);r=td.parentElement.rowIndex;for(z=0;z<2;z++)for(k=1;k<=4;k++){x=t.rows[r+o[z]*k];if(!x)break;for(j=0;j<x.cells.length;j++){w=lc(x.cells[j]);if(c>=w&&c<w+(x.cells[j].colSpan||1)){if(x.cells[j].querySelector("img"))continue;s=cl(x.cells[j].textContent);if(s.length>=8&&!gen(s)&&/[A-Za-z\u00c4\u00d6\u00dc\u00e4\u00f6\u00fc\u00df]{4,}/.test(s))return s;}}}return "";}
function box1(a){var e=a,k,l,j,z,seen,sh=shop(a.hostname);for(k=0;k<7&&e.parentElement;k++){e=e.parentElement;l=e.querySelectorAll("a[href]");seen={};var n=0,hit=null;for(j=0;j<l.length;j++){if(l[j]===a||shop(l[j].hostname)!==sh)continue;z=item(l[j]);if(z&&!seen[z]){seen[z]=1;n++;if(!hit||l[j].querySelector("img"))hit={it:z,i:l[j].querySelector("img")};}}if(n===1)return hit;if(n>1)return null;}return null;}
function nb(a){var l=[].slice.call(document.querySelectorAll("a[href]")).filter(function(x){return shop(x.hostname)===shop(a.hostname)}),k=l.indexOf(a),j,z,e,n;if(k<0)return null;for(j=k-1;j>=0&&j>=k-2;j--){z=item(l[j]);if(z){e=a;for(n=0;n<5&&e.parentElement;n++){e=e.parentElement;if(e.contains(l[j]))return{it:z,i:l[j].querySelector("img")};}return null;}}return null;}
function click(e){var a=e.target&&e.target.closest?e.target.closest("a[href]"):null;if(!a||!a.hostname||a.hostname===location.hostname)return;
var it=item(a),i=a.querySelector("img"),via=i?"img":"txt",b,pn="",l=cl(a.getAttribute("aria-label")||a.textContent||(i&&i.alt)||a.title);
if(it||/amazon|amzn|ebay/i.test(a.hostname)){if(!it){var tt=tbl(a)||box1(a)||nb(a);if(tt){it=tt.it;if(!i)i=tt.i;}}b=bx(a);if(!i&&it)i=document.querySelector('a[href*="'+it+'"] img');if(!i&&b)i=b.querySelector("img");
pn=cl(i&&i.alt);if(gen(pn))pn=cl(a.title);if(gen(pn))pn=tnm(a);if(gen(pn)&&b){var hd=b.querySelector("h1,h2,h3,h4,h5,h6,figcaption")||b.querySelector("strong,b");pn=hd?cl(hd.textContent):"";}if(gen(pn))pn=ph(a);if(gen(l)===false&&gen(pn))pn=l;}
var sc=(/^(amzn\.to|a\.co)$/i.test(a.hostname)&&!item(a))?(a.pathname||"").replace(/^\//,"").split("/")[0].slice(0,12):"";
flush();send({t:"c",to:a.hostname,hp:it?"":(a.pathname||"").slice(0,200),sc:sc,l:l.slice(0,80),i:it,m:src(i),v:via,n:pn.slice(0,100)});pend=1;out=Date.now();}
document.addEventListener("click",click,true);document.addEventListener("auxclick",click,true);})();</script>
        <?php
    }

    // ---------- Sammelstelle (Hub) ----------
    static function routes() {
        register_rest_route('mini-statistik/v1', '/hit', [
            'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'hit'],
        ]);
        register_rest_route('mini-statistik/v1', '/bericht', [
            'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => [__CLASS__, 'bericht'],
        ]);
    }

    static function allowed_sites() {
        $out = [];
        foreach (preg_split('/\R/', self::opts()['sites']) as $line) {
            $p = array_map('trim', explode('|', $line));
            if (count($p) === 2 && $p[0] !== '' && $p[1] !== '') $out[preg_replace('/^www\./', '', strtolower($p[0]))] = $p[1];
        }
        return $out;
    }

    // Kurzlinks (amzn.to/xxxx) enthalten keine Produktnummer: die Zentrale liest einmal die Weiterleitung und merkt sich die ASIN (Partner-ID und Query werden nie gespeichert)
    static function resolve_short($host, $code) {
        $k = 'ms_sc_' . md5($host . '/' . $code);
        $c = get_transient($k);
        if ($c !== false) return (string)$c;
        $asin = '';
        $r = wp_remote_head('https://' . $host . '/' . $code, ['redirection' => 0, 'timeout' => 4, 'user-agent' => 'Mozilla/5.0 (compatible; MiniStatistik)']);
        if (!is_wp_error($r)) {
            $loc = (string)wp_remote_retrieve_header($r, 'location');
            if (preg_match('~/(?:dp|gp/product|gp/aw/d|exec/obidos/ASIN|ASIN)/([A-Z0-9]{10})~i', $loc, $m)) $asin = strtoupper($m[1]);
        }
        set_transient($k, $asin, $asin !== '' ? 90 * DAY_IN_SECONDS : HOUR_IN_SECONDS);
        return $asin;
    }

    static function is_bot($ua) {
        return $ua === '' || preg_match('/bot|crawl|spider|slurp|facebookexternalhit|preview|headless|python|curl|wget|monitor|lighthouse|gtmetrix|pingdom/i', $ua);
    }

    // Roboter erkennen: [Muster im User-Agent, Name, Art, Merkmal]; nur der User-Agent wird ausgewertet, nie eine IP
    static function bot_info($ua) {
        static $L = [
            ['/googlebot|google-inspectiontool|googleother|adsbot-google|mediapartners-google|apis-google|storebot-google/i', 'Google', 'Suchmaschine', 'Googlebot ruft Seiten und robots.txt ab; die echte Herkunft lässt sich nur per Rückwärts-DNS beweisen'],
            ['/google-extended|gemini-deep-research|google-cloudvertexbot/i', 'Google KI', 'KI-Crawler', 'Trainings- und KI-Abruf von Google'],
            ['/bingbot|bingpreview|msnbot/i', 'Bing', 'Suchmaschine', 'Microsoft-Suche, auch Grundlage von Copilot'],
            ['/duckduckbot|duckassistbot/i', 'DuckDuckGo', 'Suchmaschine', ''],
            ['/yandex/i', 'Yandex', 'Suchmaschine', ''], ['/baiduspider/i', 'Baidu', 'Suchmaschine', ''],
            ['/applebot/i', 'Apple', 'Suchmaschine', 'Siri/Spotlight-Suche'],
            ['/gptbot|oai-searchbot|chatgpt-user|openai/i', 'OpenAI (ChatGPT)', 'KI-Crawler', 'GPTBot sammelt Trainingsdaten, ChatGPT-User ruft Seiten auf Nutzerwunsch ab'],
            ['/claudebot|claude-web|claude-user|claude-searchbot|anthropic/i', 'Anthropic (Claude)', 'KI-Crawler', ''],
            ['/perplexity/i', 'Perplexity', 'KI-Crawler', ''],
            ['/bytespider|bytedance|tiktokspider/i', 'ByteDance', 'KI-Crawler', 'Sehr häufig und oft ohne Rücksicht auf robots.txt'],
            ['/ccbot/i', 'Common Crawl', 'KI-Crawler', 'Offenes Webarchiv, Grundlage vieler KI-Modelle'],
            ['/amazonbot/i', 'Amazon', 'KI-Crawler', 'Alexa/Amazon-KI'], ['/meta-externalagent|meta-externalfetcher|facebookbot/i', 'Meta', 'KI-Crawler', ''],
            ['/mistralai|cohere|diffbot|youbot|ai2bot|timpibot|petalbot|omgili|imagesift/i', 'Weitere KI-/Daten-Crawler', 'KI-Crawler', ''],
            ['/ahrefsbot|semrushbot|mj12bot|dotbot|dataforseo|serpstat|screaming frog|blexbot|seokicks|sistrix|barkrowler|rogerbot|seranking/i', 'SEO-Werkzeug', 'SEO-Tool', 'Wertet Links und Rankings für Dritte aus; für dich ohne Nutzen'],
            ['/facebookexternalhit|twitterbot|linkedinbot|pinterest|slackbot|whatsapp|telegrambot|discordbot|skypeuri|embedly|redditbot/i', 'Link-Vorschau', 'Social-Vorschau', 'Wird ausgelöst, wenn jemand deinen Link teilt: ein Hinweis auf geteilte Links'],
            ['/uptimerobot|pingdom|statuscake|site24x7|betterstack|monitor|nagios|zabbix|checkly|hetrix/i', 'Überwachung', 'Überwachung', 'Dienst, der regelmäßig prüft, ob deine Seite erreichbar und schnell ist'],
            ['/lighthouse|gtmetrix|pagespeed|webpagetest/i', 'Geschwindigkeitstest', 'Überwachung', 'Misst die Ladezeit deiner Seite'],
            ['/python|curl|wget|go-http|java\/|okhttp|libwww|scrapy|httpclient|node-fetch|axios|php\/|headlesschrome|phantomjs|puppeteer|playwright/i', 'Skript / Programm', 'Skript', 'Kein Browser: Programmierbibliothek oder Headless-Browser'],
            ['/bot|crawl|spider|slurp|preview/i', 'Sonstiger Roboter', 'Unbekannt', 'Nennt sich Bot/Crawler, ist aber keinem bekannten Dienst zuzuordnen'],
        ];
        if (trim($ua) === '') return ['Ohne Kennung', 'Unbekannt', 'Leerer User-Agent: fast immer ein Skript'];
        foreach ($L as $r) {
            if (!preg_match($r[0], $ua)) continue;
            if ($r[2] === 'Unbekannt' && preg_match('/([A-Za-z0-9_.\-]*(?:bot|crawl[a-z]*|spider|slurp|preview)[A-Za-z0-9_.\-]*)/i', $ua, $m)) return [mb_substr($m[1], 0, 40) . ' (nicht in der Liste)', 'Unbekannt', 'Nennt sich selbst so, steht aber nicht in der Liste bekannter Dienste'];
            return [$r[1], $r[2], $r[3]];
        }
        return null;
    }

    // Roboter-Zugriff vermerken (nur Name, Art, Seite, gekürzter User-Agent; keine IP). $ua = User-Agent des Roboters
    static function note_robot($site, $path, $ua, $via) {
        global $wpdb;
        $i = self::bot_info($ua);
        if (!$i) return;
        $path = substr(wp_parse_url('http://x' . (string)$path, PHP_URL_PATH) ?: '/', 0, 255);
        $t = self::table();
        if ($via === 'js' && $wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE kind='robot' AND day=%s AND site=%s AND path=%s AND label=%s AND ts > %s LIMIT 1", gmdate('Y-m-d'), $site, $path, $i[0], gmdate('Y-m-d H:i:s', time() - 600)))) return; // schon serverseitig vermerkt
        $wpdb->insert($t, ['day' => gmdate('Y-m-d'), 'ts' => gmdate('Y-m-d H:i:s'), 'kind' => 'robot', 'site' => substr($site, 0, 100), 'path' => $path, 'visitor' => '', 'label' => $i[0], 'target' => $i[1], 'pn' => mb_substr(wp_strip_all_tags($ua), 0, 100), 'via' => $via === 'js' ? 'js' : 'srv']);
    }

    // Browser und Betriebssystem nur als Familie (Name ohne Version); der User-Agent selbst wird nicht gespeichert
    static function ua_info($ua) {
        $br = 'Andere';
        foreach (['/Edg(e|A|iOS)?\//' => 'Edge', '/OPR\/|Opera/' => 'Opera', '/SamsungBrowser/' => 'Samsung', '/Firefox|FxiOS/' => 'Firefox', '/Brave/' => 'Brave', '/DuckDuckGo/' => 'DuckDuckGo', '/Chrome|CriOS|Chromium/' => 'Chrome', '/Safari/' => 'Safari'] as $re => $n) if (preg_match($re, $ua)) { $br = $n; break; }
        $os = 'Andere';
        foreach (['/iPhone|iPad|iPod/' => 'iOS', '/Android/' => 'Android', '/CrOS/' => 'ChromeOS', '/Windows/' => 'Windows', '/Macintosh|Mac OS X/' => 'macOS', '/Linux|X11/' => 'Linux'] as $re => $n) if (preg_match($re, $ua)) { $os = $n; break; }
        return [$br, $os];
    }

    static function visitor_salt() {
        $days = max(1, min(30, (int)self::opts()['salt_days']));
        $s = get_option('mini_statistik_salt');
        $age = is_array($s) ? (time() - strtotime($s['day'] . ' 00:00:00 UTC')) / 86400 : 999;
        if (!is_array($s) || $age >= $days) { // alter Zufallswert wird überschrieben, alte Kennungen sind danach nicht mehr rückrechenbar
            $s = ['day' => gmdate('Y-m-d'), 'salt' => wp_generate_password(32, true, true)];
            update_option('mini_statistik_salt', $s, false);
        }
        return $s['salt'];
    }

    static function hit(WP_REST_Request $req) {
        $none = new WP_REST_Response(null, 204);
        $o = self::opts();
        if ($o['mode'] !== 'hub') return $none;
        $d = json_decode($req->get_body(), true);
        if (!is_array($d)) return $none;
        $site = preg_replace('/^www\./', '', strtolower((string)($d['s'] ?? '')));
        $sites = self::allowed_sites();
        if (!isset($sites[$site]) || !hash_equals($sites[$site], (string)($d['k'] ?? ''))) return $none;
        $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (($d['t'] ?? '') === 'r') { // Roboter-Meldung einer Sende-Seite (Server an Zentrale), User-Agent steckt in 'u'
            self::note_robot($site, (string)($d['p'] ?? '/'), substr((string)($d['u'] ?? ''), 0, 200), 'srv');
            return $none;
        }
        if (self::is_bot($ua)) {
            if (($d['t'] ?? '') === 'v') self::note_robot($site, (string)($d['p'] ?? '/'), $ua, 'js'); // Roboter mit JavaScript
            return $none;
        }
        $type = (string)($d['t'] ?? 'v');
        if (!in_array($type, ['v', 't', 'c', 'b', 'h', 'e'], true)) return $none;

        $ip = (string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '');
        $ip = trim(explode(',', $ip)[0]);
        // IP und UA nur als Hash mit regelmäßig wechselndem Zufallswert; die IP selbst wird nie gespeichert
        $visitor = substr(hash('sha256', self::visitor_salt() . '|' . $site . '|' . $ip . '|' . $ua), 0, 16);
        $path = substr(wp_parse_url('http://x' . (string)($d['p'] ?? '/'), PHP_URL_PATH) ?: '/', 0, 255); // ohne Query-String

        $row = ['day' => gmdate('Y-m-d'), 'ts' => gmdate('Y-m-d H:i:s'), 'site' => $site, 'path' => $path, 'visitor' => $visitor];
        if ($type === 'v') {
            $ref = '';
            $rh = wp_parse_url((string)($d['r'] ?? ''), PHP_URL_HOST);
            if ($rh) { $rh = strtolower(preg_replace('/^www\./', '', $rh)); if ($rh !== preg_replace('/^www\./', '', $site)) $ref = substr($rh, 0, 100); }
            $w = (int)($d['w'] ?? 0);
            [$ub, $uo] = self::ua_info($ua);
            $vw = (int)($d['vw'] ?? $w);
            $um = mb_substr(preg_replace('/[^A-Za-z0-9_.\-|+ ]/', '', wp_strip_all_tags((string)($d['u'] ?? ''))), 0, 60);
            $row += ['br' => $ub, 'os' => $uo, 'lg' => preg_match('/^([a-z]{2})/i', (string)($d['g'] ?? ''), $lm) ? strtolower($lm[1]) : '', 'wb' => $vw <= 0 ? 0 : ($vw < 400 ? 1 : ($vw < 600 ? 2 : ($vw < 768 ? 3 : ($vw < 1024 ? 4 : ($vw < 1280 ? 5 : ($vw < 1536 ? 6 : 7)))))), 'utm' => $um];
            $row += ['kind' => 'view', 'cc' => self::country(substr(preg_replace('/[^A-Za-z0-9_\/+\-]/', '', (string)($d['z'] ?? '')), 0, 60), substr((string)($d['g'] ?? ''), 0, 12)), 'via' => !empty($d['a']) ? 'bot' : '', 'ref' => $ref, 'device' => $w === 0 ? '' : ($w < 600 ? 'mobil' : ($w < 1024 ? 'tablet' : 'desktop'))];
        } elseif ($type === 'e') { // Fehlermeldung: nur Art, Datei ohne Query, Zeile; keine Texte, Adressen mit Query oder Zahlenreihen
            $txt = substr(preg_replace('/[^A-Za-z0-9_\-\.\/ @:]/', '', (string)($d['x'] ?? '')), 0, 120);
            $txt = preg_replace('/\d{6,}/', '#', $txt);
            if ($txt === '') return $none;
            $row += ['kind' => 'error', 'via' => (($d['ek'] ?? '') === 'r') ? 'res' : 'js', 'hr' => $txt];
        } elseif ($type === 'h') {
            $row += ['kind' => 'human'];
        } elseif ($type === 'b') {
            $row += ['kind' => 'back', 'secs' => max(0, min(10800, (int)($d['d'] ?? 0)))];
        } elseif ($type === 't') {
            $row += ['kind' => 'time', 'secs' => max(0, min(1800, (int)($d['x'] ?? 0))), 'scroll' => max(0, min(100, (int)($d['g'] ?? 0))), 'ld' => max(0, min(65000, (int)($d['ld'] ?? 0))), 'lc' => max(0, min(65000, (int)($d['lc'] ?? 0))), 'cl' => max(0, min(65000, (int)($d['cl'] ?? 0))), 'ip' => max(0, min(65000, (int)($d['ip'] ?? 0))), 'tt' => max(0, min(65000, (int)($d['tt'] ?? 0))), 'fc' => max(0, min(65000, (int)($d['fc'] ?? 0))), 'kb' => max(0, min(65000, (int)($d['kb'] ?? 0))), 'rq' => max(0, min(65000, (int)($d['rq'] ?? 0))), 'cn' => max(0, min(3, (int)($d['cn'] ?? 0))), 'je' => max(0, min(250, (int)($d['je'] ?? 0))), 'rf' => max(0, min(250, (int)($d['rf'] ?? 0))), 'pf' => max(0, min(31, (int)($d['pf'] ?? 0)))];
            $tw = (int)($d['w'] ?? 0); $row['device'] = $tw <= 0 ? '' : ($tw < 600 ? 'mobil' : ($tw < 1024 ? 'tablet' : 'desktop'));
        } else {
            $to = strtolower(preg_replace('/[^a-z0-9.\-]/i', '', (string)($d['to'] ?? '')));
            $to = preg_replace('/^www\./', '', $to);
            if ($to === '') return $none;
            $it = substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($d['i'] ?? '')), 0, 20);
            $sc = substr(preg_replace('/[^A-Za-z0-9]/', '', (string)($d['sc'] ?? '')), 0, 12);
            if ($sc !== '' && ($to === 'amzn.to' || $to === 'a.co')) { $res = self::resolve_short($to, $sc); if ($res !== '') $it = $res; }
            $img = esc_url_raw((string)($d['m'] ?? ''), ['http', 'https']);
            $img = $img ? substr(strtok($img, '?'), 0, 500) : '';
            $hp = (string)strtok((string)($d['hp'] ?? ''), '?#'); $hp = ($it === '' && $sc === '' && $hp !== '' && $hp[0] === '/') ? substr(preg_replace('#[^A-Za-z0-9._~:/%+\-]#', '', $hp), 0, 200) : '';
            $row += ['hr' => $hp, 'kind' => 'click', 'target' => substr($to, 0, 100), 'label' => mb_substr(wp_strip_all_tags((string)($d['l'] ?? '')), 0, 80),
                'item' => $it, 'img' => $img, 'pn' => mb_substr(wp_strip_all_tags((string)($d['n'] ?? '')), 0, 100), 'via' => (($d['v'] ?? '') === 'img') ? 'img' : 'txt'];
        }
        global $wpdb;
        $t = self::table();
        // „Mensch“-Markierung: Bewegungssignal (h) heute schon gesehen? Dann bekommen auch spätere Zeilen hum = 1; kommt das Signal erst jetzt, werden die früheren Zeilen von heute nachgetragen
        $bot_flag = !empty($row['via']) && $row['via'] === 'bot';
        if ($type === 'h') {
            $row['hum'] = 1;
            $wpdb->query($wpdb->prepare("UPDATE $t SET hum=1 WHERE visitor=%s AND day=%s AND site=%s AND hum=0", $visitor, $row['day'], $site));
        } elseif (!$bot_flag && $wpdb->get_var($wpdb->prepare("SELECT 1 FROM $t WHERE visitor=%s AND day=%s AND kind='human' AND site=%s LIMIT 1", $visitor, $row['day'], $site))) {
            $row['hum'] = 1;
        }
        $wpdb->insert($t, $row);
        if ($type === 'v') self::note_search_404($d, $row, $bot_flag);
        return $none;
    }

    // Interne Suche und 404-Seiten (nur aus dem Aufruf-Signal; ohne IP, ohne Cookie)
    static function note_search_404($d, $row, $bot) {
        global $wpdb;
        $t = self::table();
        $base = ['day' => $row['day'], 'ts' => $row['ts'], 'site' => $row['site'], 'path' => $row['path'], 'visitor' => $row['visitor'], 'via' => $bot ? 'bot' : '', 'cc' => $row['cc'], 'device' => $row['device']];
        $q = mb_strtolower(trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string)($d['q'] ?? '')))));
        if ($q !== '' && mb_strlen($q) >= 2 && strpos($q, '@') === false && !preg_match('/\d{6,}/', $q) && !preg_match('~https?:|www\.~', $q)) {
            $q = mb_substr($q, 0, 80);
            // Neuladen derselben Suche gilt nicht doppelt
            if (!$wpdb->get_var($wpdb->prepare("SELECT 1 FROM $t WHERE kind='srch' AND visitor=%s AND day=%s AND label=%s AND ts > %s LIMIT 1", $row['visitor'], $row['day'], $q, gmdate('Y-m-d H:i:s', time() - 120)))) {
                $f = isset($d['f']) && $d['f'] !== null && $d['f'] !== '' ? (string)max(0, min(99999, (int)$d['f'])) : '';
                $wpdb->insert($t, $base + ['kind' => 'srch', 'label' => $q, 'item' => $f, 'hum' => $row['hum'] ?? 0]);
            }
        }
        if (!empty($d['n4'])) {
            $rp = wp_parse_url((string)($d['r'] ?? ''));
            $from = !empty($rp['host']) ? strtolower(preg_replace('/^www\./', '', $rp['host'])) . ($rp['path'] ?? '') : '';
            $wpdb->insert($t, $base + ['kind' => 'e404', 'label' => mb_substr(preg_replace('#[^A-Za-z0-9._~:/%+\-]#', '', $from), 0, 80), 'hum' => $row['hum'] ?? 0]);
        }
    }


    // ---------- Herkunftsland (ohne IP-Abfrage: aus Zeitzone und Browsersprache des Besuchers geschätzt) ----------
    static function country($tz, $lang) {
        static $map = null;
        if ($map === null) $map = [
            'Europe/Berlin'=>'DE','Europe/Busingen'=>'DE','Europe/Vienna'=>'AT','Europe/Zurich'=>'CH','Europe/Vaduz'=>'LI','Europe/Luxembourg'=>'LU','Europe/Amsterdam'=>'NL','Europe/Brussels'=>'BE','Europe/Paris'=>'FR','Europe/Madrid'=>'ES','Atlantic/Canary'=>'ES','Europe/Lisbon'=>'PT','Atlantic/Madeira'=>'PT','Atlantic/Azores'=>'PT','Europe/Rome'=>'IT','Europe/London'=>'GB','Europe/Dublin'=>'IE','Europe/Copenhagen'=>'DK','Europe/Stockholm'=>'SE','Europe/Oslo'=>'NO','Europe/Helsinki'=>'FI','Europe/Warsaw'=>'PL','Europe/Prague'=>'CZ','Europe/Bratislava'=>'SK','Europe/Budapest'=>'HU','Europe/Bucharest'=>'RO','Europe/Sofia'=>'BG','Europe/Athens'=>'GR','Europe/Zagreb'=>'HR','Europe/Ljubljana'=>'SI','Europe/Belgrade'=>'RS','Europe/Sarajevo'=>'BA','Europe/Skopje'=>'MK','Europe/Tirane'=>'AL','Europe/Vilnius'=>'LT','Europe/Riga'=>'LV','Europe/Tallinn'=>'EE','Europe/Kiev'=>'UA','Europe/Kyiv'=>'UA','Europe/Minsk'=>'BY','Europe/Chisinau'=>'MD','Europe/Moscow'=>'RU','Europe/Istanbul'=>'TR','Asia/Istanbul'=>'TR','Atlantic/Reykjavik'=>'IS','Europe/Malta'=>'MT','Asia/Nicosia'=>'CY',
            'America/New_York'=>'US','America/Chicago'=>'US','America/Denver'=>'US','America/Los_Angeles'=>'US','America/Phoenix'=>'US','America/Anchorage'=>'US','Pacific/Honolulu'=>'US','America/Detroit'=>'US','America/Indiana/Indianapolis'=>'US','America/Toronto'=>'CA','America/Vancouver'=>'CA','America/Edmonton'=>'CA','America/Winnipeg'=>'CA','America/Halifax'=>'CA','America/Montreal'=>'CA','America/Mexico_City'=>'MX','America/Sao_Paulo'=>'BR','America/Argentina/Buenos_Aires'=>'AR','America/Buenos_Aires'=>'AR','America/Santiago'=>'CL','America/Bogota'=>'CO','America/Lima'=>'PE','America/Caracas'=>'VE','America/Montevideo'=>'UY',
            'Asia/Tokyo'=>'JP','Asia/Seoul'=>'KR','Asia/Shanghai'=>'CN','Asia/Hong_Kong'=>'HK','Asia/Taipei'=>'TW','Asia/Singapore'=>'SG','Asia/Bangkok'=>'TH','Asia/Jakarta'=>'ID','Asia/Manila'=>'PH','Asia/Kuala_Lumpur'=>'MY','Asia/Ho_Chi_Minh'=>'VN','Asia/Saigon'=>'VN','Asia/Kolkata'=>'IN','Asia/Calcutta'=>'IN','Asia/Karachi'=>'PK','Asia/Dhaka'=>'BD','Asia/Dubai'=>'AE','Asia/Riyadh'=>'SA','Asia/Tehran'=>'IR','Asia/Jerusalem'=>'IL','Asia/Tel_Aviv'=>'IL','Asia/Baghdad'=>'IQ','Asia/Almaty'=>'KZ','Australia/Sydney'=>'AU','Australia/Melbourne'=>'AU','Australia/Brisbane'=>'AU','Australia/Perth'=>'AU','Australia/Adelaide'=>'AU','Pacific/Auckland'=>'NZ','Africa/Johannesburg'=>'ZA','Africa/Cairo'=>'EG','Africa/Lagos'=>'NG','Africa/Nairobi'=>'KE','Africa/Casablanca'=>'MA','Africa/Algiers'=>'DZ','Africa/Tunis'=>'TN',
        ];
        if ($tz !== '' && isset($map[$tz])) return $map[$tz];
        if (preg_match('/^[a-z]{2,3}[-_]([A-Za-z]{2})\b/', $lang, $m)) return strtoupper($m[1]);
        return '';
    }

    static function country_name($cc) {
        static $n = ['DE'=>'Deutschland','AT'=>'Österreich','CH'=>'Schweiz','LI'=>'Liechtenstein','LU'=>'Luxemburg','NL'=>'Niederlande','BE'=>'Belgien','FR'=>'Frankreich','ES'=>'Spanien','PT'=>'Portugal','IT'=>'Italien','GB'=>'Großbritannien','IE'=>'Irland','DK'=>'Dänemark','SE'=>'Schweden','NO'=>'Norwegen','FI'=>'Finnland','PL'=>'Polen','CZ'=>'Tschechien','SK'=>'Slowakei','HU'=>'Ungarn','RO'=>'Rumänien','BG'=>'Bulgarien','GR'=>'Griechenland','HR'=>'Kroatien','SI'=>'Slowenien','RS'=>'Serbien','BA'=>'Bosnien-Herzegowina','MK'=>'Nordmazedonien','AL'=>'Albanien','LT'=>'Litauen','LV'=>'Lettland','EE'=>'Estland','UA'=>'Ukraine','BY'=>'Belarus','MD'=>'Moldau','RU'=>'Russland','TR'=>'Türkei','IS'=>'Island','MT'=>'Malta','CY'=>'Zypern','US'=>'USA','CA'=>'Kanada','MX'=>'Mexiko','BR'=>'Brasilien','AR'=>'Argentinien','CL'=>'Chile','CO'=>'Kolumbien','PE'=>'Peru','VE'=>'Venezuela','UY'=>'Uruguay','JP'=>'Japan','KR'=>'Südkorea','CN'=>'China','HK'=>'Hongkong','TW'=>'Taiwan','SG'=>'Singapur','TH'=>'Thailand','ID'=>'Indonesien','PH'=>'Philippinen','MY'=>'Malaysia','VN'=>'Vietnam','IN'=>'Indien','PK'=>'Pakistan','BD'=>'Bangladesch','AE'=>'Ver. Arab. Emirate','SA'=>'Saudi-Arabien','IR'=>'Iran','IL'=>'Israel','IQ'=>'Irak','KZ'=>'Kasachstan','AU'=>'Australien','NZ'=>'Neuseeland','ZA'=>'Südafrika','EG'=>'Ägypten','NG'=>'Nigeria','KE'=>'Kenia','MA'=>'Marokko','DZ'=>'Algerien','TN'=>'Tunesien'];
        return $n[$cc] ?? $cc;
    }

    static function flag($cc) {
        if (!preg_match('/^[A-Z]{2}$/', $cc)) return '';
        $f = '';
        foreach (str_split($cc) as $ch) $f .= mb_chr(0x1F1E6 + ord($ch) - 65, 'UTF-8');
        return $f;
    }

    // ---------- Einordnung der Klickziele ----------
    static function partner($host) {
        $h = strtolower(preg_replace('/^www\./', '', $host));
        if (isset(self::allowed_sites()[$h])) return 'Eigene Seiten';
        if (preg_match('/(^|\.)(amazon\.[a-z.]+|amzn\.[a-z]+|a\.co|link\.amazon)$/', $h)) return 'Amazon';
        if (preg_match('/(^|\.)ebay\.[a-z.]+$|(^|\.)ebay\.us$/', $h)) return 'eBay';
        return 'Sonstige';
    }

    // ---------- Echtzeit ----------
    static function live() {
        if (!current_user_can('manage_options')) wp_send_json_error(null, 403);
        global $wpdb;
        $t = self::table();
        $span = (isset($_GET['min']) && (int)$_GET['min'] >= 60) ? 60 : 30;
        $since = gmdate('Y-m-d H:i:s', time() - $span * 60);
        $now = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT visitor) FROM $t WHERE kind='view' AND ts >= %s", gmdate('Y-m-d H:i:s', time() - 1800)));
        $sites = $wpdb->get_results($wpdb->prepare("SELECT site, COUNT(DISTINCT visitor) n FROM $t WHERE kind='view' AND ts >= %s GROUP BY site ORDER BY n DESC", gmdate('Y-m-d H:i:s', time() - 1800)), ARRAY_A);
        $last = $wpdb->get_results($wpdb->prepare("SELECT ts, kind, site, path, ref, device, cc, target, secs, visitor, item, via, pn, label, hr FROM $t WHERE kind IN ('view','click','back','srch','e404') AND ts >= %s ORDER BY id DESC LIMIT 30", gmdate('Y-m-d H:i:s', time() - 1800)), ARRAY_A);
        $vclicks = [];
        foreach ($wpdb->get_results($wpdb->prepare("SELECT site, visitor, COUNT(*) n FROM $t WHERE kind='click' AND ts >= %s GROUP BY site, visitor", gmdate('Y-m-d H:i:s', time() - 1800))) as $x) $vclicks[$x->site . '|' . $x->visitor] = (int)$x->n;
        $multi = 0; foreach ($vclicks as $n_) if ($n_ > 1) $multi++;
        $lab = [];
        foreach (array_reverse($last) as &$r) {
            $vk = $r['site'] . '|' . $r['visitor'];
            if (!isset($lab[$vk])) { $q_ = count($lab); $lab[$vk] = $q_ < 26 ? chr(65 + $q_) : (string)($q_ + 1); }
        }
        unset($r);
        foreach ($last as &$r) {
            $vk = $r['site'] . '|' . $r['visitor'];
            $r['u'] = $lab[$vk]; $r['uc'] = $vclicks[$vk] ?? 0; unset($r['visitor']);
            $r['ago'] = max(0, time() - strtotime($r['ts'] . ' UTC'));
            $r['partner'] = $r['kind'] === 'click' ? self::partner($r['target']) : '';
            $r['href'] = '';
            if ($r['kind'] === 'click') {
                $hh = preg_match('/^[a-z0-9.\-]+$/', (string)$r['target']) ? $r['target'] : '';
                if ($r['partner'] === 'Amazon' && $r['item'] !== '') $r['href'] = 'https://www.amazon.de/dp/' . $r['item'];
                elseif ($r['partner'] === 'eBay' && $r['item'] !== '') $r['href'] = 'https://www.ebay.de/itm/' . $r['item'];
                elseif (($r['partner'] === 'Sonstige' || $r['partner'] === 'Eigene Seiten') && $hh !== '') $r['href'] = 'https://' . $hh . (preg_match('#^/[A-Za-z0-9._~:/%+\-]*$#', (string)$r['hr']) ? $r['hr'] : '');
                $r['how'] = $r['via'] === 'img' ? 'Bild' : 'Text';
            }
            unset($r['via']);
            $r['flag'] = self::flag($r['cc']);
        }
        unset($r);
        // Verlauf: je Minute Aufrufe, Besucher und Klicks zu Amazon/eBay (älteste links)
        $bk = array_fill(0, $span, ['v' => 0, 'c' => 0]);
        $mins = [];
        foreach ($wpdb->get_results($wpdb->prepare("SELECT ts, kind, target FROM $t WHERE kind IN ('view','click') AND ts >= %s", $since)) as $x) {
            $i = $span - 1 - (int)floor((time() - strtotime($x->ts . ' UTC')) / 60);
            if ($i < 0 || $i >= $span) continue;
            if ($x->kind === 'view') $bk[$i]['v']++;
            else { $p = self::partner($x->target); if ($p === 'Amazon' || $p === 'eBay') $bk[$i]['c']++; }
        }
        $cc = $wpdb->get_results($wpdb->prepare("SELECT cc, COUNT(DISTINCT visitor) n FROM $t WHERE kind='view' AND ts >= %s AND cc <> '' GROUP BY cc ORDER BY n DESC LIMIT 6", gmdate('Y-m-d H:i:s', time() - 1800)), ARRAY_A);
        foreach ($cc as &$c) { $c['name'] = self::country_name($c['cc']); $c['flag'] = self::flag($c['cc']); }
        unset($c);
        wp_send_json_success(['now' => $now, 'sites' => $sites, 'last' => $last, 'span' => $span, 'buckets' => $bk, 'countries' => $cc, 'cv' => count($vclicks), 'cm' => $multi]);
    }

    static function live_box() {
        $url = admin_url('admin-ajax.php?action=mini_statistik_live');
        echo '<div class="ms-card"><h2>Jetzt <small>(<a href="#" id="ms-s30" class="ms-on">30 Min.</a> · <a href="#" id="ms-s60">1 Std.</a>) &nbsp; <a href="#" id="ms-tg">ausblenden</a></small></h2><div id="ms-live"><p>Lade …</p></div></div>';
        ?>
<script>
(function(){var box=document.getElementById('ms-live'),u=<?php echo wp_json_encode($url); ?>,span=30,more=false,off=false,tg=document.getElementById('ms-tg');
try{off=localStorage.getItem('ms_live_off')==='1';}catch(e){}
function vis(){box.style.display=off?'none':'';tg.textContent=off?'einblenden':'ausblenden';}
tg.onclick=function(e){e.preventDefault();off=!off;try{localStorage.setItem('ms_live_off',off?'1':'0');}catch(x){}vis();if(!off)load();};vis();
function esc(s){var d=document.createElement('div');d.textContent=s==null?'':s;return d.innerHTML;}
function pg(r){var t=r.site+r.path;return '<a href="'+esc('https://'+t).replace(/"/g,'&quot;')+'" target="_blank" rel="noopener noreferrer">'+esc(t)+'</a>';}
function chart(b,sp){var n=b.length,mx=1,i,w=1000/n,h='';for(i=0;i<n;i++)mx=Math.max(mx,b[i].v,b[i].c);
h='<svg viewBox="0 0 1000 130" width="100%" role="img" aria-label="Aufrufe und Klicks pro Minute"><line x1="0" y1="100" x2="1000" y2="100" stroke="#dcdcde"/>';
for(i=0;i<n;i++){var vh=Math.round(90*b[i].v/mx),ch=Math.round(90*b[i].c/mx),x=i*w;
h+='<rect class="ms-bar-v" x="'+(x+w*0.12).toFixed(1)+'" y="'+(100-vh)+'" width="'+(w*0.76).toFixed(1)+'" height="'+vh+'" rx="3" fill="#2271b1" style="animation-delay:'+(i*12)+'ms"><title>vor '+(n-1-i)+' min: '+b[i].v+' Aufrufe, '+b[i].c+' Klicks</title></rect>';
if(b[i].c)h+='<circle cx="'+(x+w/2).toFixed(1)+'" cy="'+(100-ch-8)+'" r="'+Math.min(9,5+b[i].c)+'" fill="#d98200" stroke="#fff" stroke-width="2"><title>'+b[i].c+' Klick(s) zu Amazon/eBay</title></circle>';}
h+='<text x="0" y="122" font-size="13" fill="#646970">vor '+sp+' min</text><text x="1000" y="122" font-size="13" text-anchor="end" fill="#646970">jetzt</text></svg>';
h+='<p class="ms-note"><span style="color:#2271b1">▮</span> Aufrufe pro Minute &nbsp; <span style="color:#d98200">●</span> Klicks zu Amazon / eBay</p>';return h;}
function load(){if(off)return;fetch(u+'&min='+span,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(j){
if(!j.success){box.innerHTML='<p>Keine Berechtigung.</p>';return;}var d=j.data;
var h='<div class="ms-now"><span class="ms-big">'+d.now+'</span> Besucher in den letzten 30 Min.<span class="ms-dot"></span></div>';
h+='<p class="ms-sub">'+(d.sites.map(function(s){return esc(s.site)+': <b>'+s.n+'</b>';}).join(' &nbsp;·&nbsp; ')||'Gerade niemand.')+'</p>';
h+=chart(d.buckets,d.span);
h+='<p class="ms-sub">Besucher mit Klick (30 Min.): <b>'+d.cv+'</b>'+(d.cm?', davon <b>'+d.cm+'</b> mit mehreren Klicks':'')+'</p>';
if(d.countries.length)h+='<p class="ms-sub">'+d.countries.map(function(c){return '<span class="ms-pill">'+esc(c.flag)+' '+esc(c.name)+' <b>'+c.n+'</b></span>';}).join(' ')+'</p>';
var rs=d.last.map(function(r){var m=Math.floor(r.ago/60),w=m<1?r.ago+' s':m+' min',fl=r.flag?esc(r.flag)+' ':'';
var cc=['#2271b1','#d98200','#00a32a','#8c3fb5','#d63638','#0a9396','#a0a000','#e0457b'][(String(r.u).charCodeAt(0)||0)%8],uc=' <span class="ms-note"><span style="color:'+cc+'">●</span> Besucher <b style="color:'+cc+'">'+esc(r.u)+'</b></span>';
if(r.kind==='srch')return '<tr><td class="ms-w">vor '+w+'</td><td>'+pg(r)+uc+'</td><td colspan="2"><span class="ms-pill">suchte: „'+esc(r.label)+'“'+(r.item==='0'?' (keine Treffer)':'')+'</span></td></tr>';
if(r.kind==='e404')return '<tr><td class="ms-w">vor '+w+'</td><td>'+pg(r)+uc+'</td><td colspan="2"><span class="ms-pill ms-p-eBay">404: Seite gibt es nicht</span>'+(r.label?' <span class="ms-note">von '+esc(r.label)+'</span>':'')+'</td></tr>';
if(r.kind==='back')return '<tr><td class="ms-w">vor '+w+'</td><td>'+pg(r)+uc+'</td><td colspan="2"><span class="ms-pill">kam zurück nach '+(r.secs<60?r.secs+' s':Math.round(r.secs/60)+' min')+'</span></td></tr>';
var nm=(r.partner==='Sonstige'||r.partner==='Eigene Seiten')?esc(r.target)+(r.label?' · „'+esc(r.label)+'“':' (Bild)'):esc(r.partner)+(r.pn?': '+esc(r.pn.slice(0,50)):(r.item?' '+esc(r.item):''));
return r.kind==='click'?'<tr><td class="ms-w">vor '+w+'</td><td>'+pg(r)+uc+'</td><td colspan="2"><span class="ms-pill ms-p-'+esc(r.partner)+'">Klick ('+esc(r.how)+') → '+(r.href?'<a href="'+esc(r.href).replace(/"/g,'&quot;')+'" target="_blank" rel="noopener noreferrer">'+nm+'</a>':nm)+'</span>'+(r.uc>1?' <b style="color:'+cc+'">'+r.uc+' Klicks von Besucher '+esc(r.u)+'</b>':'')+'</td></tr>'
:'<tr><td class="ms-w">vor '+w+'</td><td>'+pg(r)+uc+'</td><td>'+fl+esc(r.ref||'direkt')+'</td><td>'+esc(r.device)+'</td></tr>';});h+='<table class="ms-tbl"><tbody>'+rs.slice(0,more?rs.length:3).join('')+'</tbody></table>';if(rs.length>3)h+='<p><a href="#" id="ms-more">'+(more?'weniger anzeigen':(rs.length-3)+' weitere anzeigen')+'</a></p>';
box.innerHTML=h;var mo=document.getElementById('ms-more');if(mo)mo.onclick=function(e){e.preventDefault();more=!more;load();};}).catch(function(){});}
function sw(n,e){e.preventDefault();span=n;document.getElementById('ms-s30').className=n===30?'ms-on':'';document.getElementById('ms-s60').className=n===60?'ms-on':'';load();}
document.getElementById('ms-s30').onclick=function(e){sw(30,e);};document.getElementById('ms-s60').onclick=function(e){sw(60,e);};
load();setInterval(load,10000);})();
</script>
        <?php
    }


    // ---------- Besucherfluss ----------
    static function flow_report($w, $multi) {
        global $wpdb;
        $t = self::table();
        $rows = $wpdb->get_results("SELECT site, visitor, path, ref, ts FROM $t WHERE kind='view' AND $w ORDER BY site, visitor, ts, id LIMIT 60000");
        $lab = function ($site, $path) use ($multi) { return ($multi ? $site : '') . $path; };
        $visits = []; $cur = null; $prev_ts = 0;
        foreach ($rows as $r) {
            $ts = strtotime($r->ts . ' UTC');
            if ($cur === null || $cur['k'] !== $r->site . '|' . $r->visitor || $ts - $prev_ts > 1800) {
                if ($cur) $visits[] = $cur;
                $cur = ['k' => $r->site . '|' . $r->visitor, 'ref' => $r->ref, 'p' => [], 'lp' => '', 'lt' => 0, 'ft' => $ts];
            }
            $l = $lab($r->site, $r->path);
            if (!$cur['p'] || end($cur['p']) !== $l) $cur['p'][] = $l; // Neuladen zählt nicht als neuer Schritt
            $cur['lp'] = $r->path; $cur['lt'] = $ts; // letzter Aufruf (roher Pfad) für die Ausstiegsanalyse
            $prev_ts = $ts;
        }
        if ($cur) $visits[] = $cur;
        $n = count($visits);
        if (!$n) { ob_start(); self::bars('Besucherfluss', []); return ['kpi' => ob_get_clean(), 'exit' => '', 'grid' => '', 'warn' => '', 'ee' => '']; }
        // Zeit/Scrolltiefe je Besucher und Seite sowie Klicks für die Ausstiegsanalyse
        $tmap = [];
        foreach ($wpdb->get_results("SELECT site, visitor, path, SUM(secs) s, MAX(scroll) g FROM $t WHERE kind='time' AND $w GROUP BY site, visitor, path LIMIT 60000") as $r) $tmap[$r->site . '|' . $r->visitor . '|' . $r->path] = [(int)$r->s, (int)$r->g];
        $cmap = [];
        foreach ($wpdb->get_results("SELECT site, visitor, path, target, ts FROM $t WHERE kind='click' AND $w ORDER BY ts LIMIT 60000") as $r) $cmap[$r->site . '|' . $r->visitor][] = [strtotime($r->ts . ' UTC'), $r->path, self::partner($r->target)];
        $pagecount = []; $ex = []; $en = [];
        $entry = []; $exit = []; $trans = []; $paths = []; $src = []; $single = 0; $steps = 0;
        foreach ($visits as $v) {
            $p = $v['p']; $c = count($p); $steps += $c;
            foreach ($p as $pl) $pagecount[$pl] = ($pagecount[$pl] ?? 0) + 1;
            $last = $p[$c - 1];
            if (!isset($en[$p[0]])) $en[$p[0]] = ['n' => 0, 'single' => 0, 'steps' => 0, 'ck' => 0];
            $en[$p[0]]['n']++; $en[$p[0]]['steps'] += $c; if ($c === 1) $en[$p[0]]['single']++;
            foreach ($cmap[$v['k']] ?? [] as $ck) { if ($ck[0] >= $v['ft'] - 5 && $ck[0] <= $v['lt'] + 1800 && ($ck[2] === 'Amazon' || $ck[2] === 'eBay')) { $en[$p[0]]['ck']++; break; } }
            if (!isset($ex[$last])) $ex[$last] = ['n' => 0, 'shop' => 0, 'ext' => 0, 'secs' => 0, 'ns' => 0, 'scr' => 0, 'nsc' => 0, 'single' => 0];
            $e =& $ex[$last]; $e['n']++;
            if ($c === 1) $e['single']++;
            $tk = $v['k'] . '|' . $v['lp'];
            if (isset($tmap[$tk])) { $e['secs'] += $tmap[$tk][0]; $e['ns']++; $e['scr'] += $tmap[$tk][1]; $e['nsc']++; }
            foreach ($cmap[$v['k']] ?? [] as $ck) {
                if ($ck[1] === $v['lp'] && $ck[0] >= $v['lt'] - 5 && $ck[0] <= $v['lt'] + 1800 && $ck[2] !== 'Eigene Seiten') { if ($ck[2] === 'Sonstige') $e['ext']++; else $e['shop']++; break; }
            }
            unset($e);
            if ($c === 1) $single++;
            $entry[$p[0]] = ($entry[$p[0]] ?? 0) + 1;
            $exit[$p[$c - 1]] = ($exit[$p[$c - 1]] ?? 0) + 1;
            $q = $v['ref'] !== '' ? $v['ref'] : 'direkt / unbekannt';
            $k = $q . '  →  ' . $p[0]; $src[$k] = ($src[$k] ?? 0) + 1;
            for ($i = 0; $i < $c - 1; $i++) { $k = $p[$i] . '  →  ' . $p[$i + 1]; $trans[$k] = ($trans[$k] ?? 0) + 1; }
            if ($c >= 3) { $k = $p[0] . '  →  ' . $p[1] . '  →  ' . $p[2]; $paths[$k] = ($paths[$k] ?? 0) + 1; }
        }
        $top = function ($a, $k = 10) { arsort($a); $o = []; foreach (array_slice($a, 0, $k, true) as $l => $v) $o[] = [$l, $v]; return $o; };
        ob_start();
        echo '<h2 style="margin-top:28px">Besucherfluss</h2><div class="ms-kpis">';
        foreach ([
            [number_format_i18n($n), 'Besuche (Pause über 30 Min = neuer Besuch)'],
            [number_format_i18n(round($steps / $n, 1), 1), 'Ø Seiten pro Besuch'],
            [round(100 * $single / $n) . ' %', 'Besuche mit nur einer Seite'],
            [round(100 * ($n - $single) / $n) . ' %', 'Besucher, die weiterklicken'],
        ] as $k) echo '<div class="ms-kpi"><b>' . esc_html($k[0]) . '</b><span>' . esc_html($k[1]) . '</span></div>';
        echo '</div>'; $kpi_html = ob_get_clean();
        ob_start(); echo '<div class="ms-grid2">';
        self::bars('Häufigste Übergänge (von → nach)', $top($trans, 15), '', true);
        self::bars('Typische Wege (3 Seiten)', $top($paths, 10), '', true);
        self::bars('Woher → auf welcher Seite gelandet', $top($src, 12), '', true);
        echo '</div>'; $grid_html = ob_get_clean();

        // Ein- und Ausstieg für den Anfang der Übersicht
        ob_start();
        uasort($en, fn($a, $b) => $b['n'] <=> $a['n']);
        echo '<div class="ms-grid2"><div class="ms-card ms-wide"><h2>Einstiegsseiten <small>(wo Besucher ankommen)</small></h2><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Einstiege</th><th class="num">Anteil</th><th class="num">nur diese Seite</th><th class="num">Ø Seiten</th><th class="num">Klick zu Amazon / eBay</th></tr></thead><tbody>';
        foreach (array_slice($en, 0, 10, true) as $pg => $e) echo '<tr><td>' . esc_html($pg) . '</td><td class="num"><b>' . (int)$e['n'] . '</b></td><td class="num">' . round(100 * $e['n'] / $n) . ' %</td><td class="num">' . round(100 * $e['single'] / $e['n']) . ' %</td><td class="num">' . number_format_i18n($e['steps'] / $e['n'], 1) . '</td><td class="num">' . round(100 * $e['ck'] / $e['n']) . ' %</td></tr>';
        echo '</tbody></table><p class="ms-note">Einstieg = erste Seite eines Besuchs (Pause über 30 Minuten = neuer Besuch). „Nur diese Seite“ = Besucher ging danach, ohne eine weitere Seite zu öffnen.</p></div>';
        $ex2 = $ex; uasort($ex2, fn($a, $b) => $b['n'] <=> $a['n']);
        echo '<div class="ms-card ms-wide"><h2>Ausstiegsseiten <small>(wo Besucher gehen)</small></h2><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Ausstiege</th><th class="num">Ausstiegsrate</th><th class="num">davon zu Amazon / eBay</th></tr></thead><tbody>';
        foreach (array_slice($ex2, 0, 10, true) as $pg => $e) { $vp = $pagecount[$pg] ?? 0; echo '<tr><td>' . esc_html($pg) . '</td><td class="num"><b>' . (int)$e['n'] . '</b></td><td class="num">' . ($vp ? round(100 * $e['n'] / $vp) . ' %' : '–') . '</td><td class="num">' . (int)$e['shop'] . '</td></tr>'; }
        echo '</tbody></table><p class="ms-note">Mehr dazu (Zeit, Scrolltiefe, auffällige Seiten) im Reiter „Verhalten auf den Seiten“.</p></div></div>';
        $ee_html = ob_get_clean();

        // Ausstiege
        ob_start();
        $exits_total = array_sum(array_column($ex, 'n'));
        $avg_rate = $steps ? $exits_total / $steps : 0;
        uasort($ex, fn($a, $b) => $b['n'] <=> $a['n']);
        echo '<div class="ms-card"><h2>Wo verlassen Besucher die Seite?</h2><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Aufrufe</th><th class="num">Ausstiege</th><th class="num">Ausstiegsrate</th><th class="num">davon zu Amazon / eBay</th><th class="num">davon zu anderen externen Seiten</th><th class="num">Ø Zeit auf der Seite</th><th class="num">Ø Scrolltiefe</th><th></th></tr></thead><tbody>';
        foreach (array_slice($ex, 0, 20, true) as $pg => $e) {
            $views_p = $pagecount[$pg] ?? 0; $rate = $views_p ? $e['n'] / $views_p : 0;
            $hint = ($views_p >= 20 && $rate > 1.25 * $avg_rate) ? '<span class="ms-pill ms-p-eBay">auffällig hoch</span>' : '';
            echo '<tr><td>' . esc_html($pg) . '</td><td class="num">' . (int)$views_p . '</td><td class="num"><b>' . (int)$e['n'] . '</b></td><td class="num">' . round(100 * $rate) . ' %</td><td class="num">' . (int)$e['shop'] . '</td><td class="num">' . (int)$e['ext'] . '</td><td class="num">' . ($e['ns'] ? self::fmt_time($e['secs'] / $e['ns']) : '–') . '</td><td class="num">' . ($e['nsc'] ? round($e['scr'] / $e['nsc']) . ' %' : '–') . '</td><td>' . $hint . '</td></tr>';
        }
        echo '</tbody></table><p class="ms-note">Ausstieg = letzte Seite eines Besuchs (30 Minuten ohne weiteren Aufruf, oder Klick auf einen externen Link). Die Ausstiegsrate ist der Anteil der Aufrufe einer Seite, nach denen der Besuch dort endet; im Durchschnitt aller Seiten ' . round(100 * $avg_rate) . ' %. „Auffällig hoch" = mehr als das 1,25-Fache des Durchschnitts bei mindestens 20 Aufrufen. Die Zeit und die Scrolltiefe beziehen sich auf die Besuche, die auf dieser Seite enden: Wer früh aufhört zu scrollen, springt eher inhaltlich ab, wer weit gescrollt hat und zu Amazon/eBay geht, hat die Seite erfolgreich genutzt.</p></div>';
        $exit_html = ob_get_clean();
        $warn = count($rows) >= 60000 ? '<p class="ms-note">Hinweis: Es wurden nur die ersten 60.000 Aufrufe ausgewertet. Wähle einen kürzeren Zeitraum.</p>' : '';
        return ['kpi' => $kpi_html, 'exit' => $exit_html, 'grid' => $grid_html, 'warn' => $warn, 'ee' => $ee_html];
    }


    // ---------- Import früherer Daten (Google-Analytics-CSV, nur Tageszahlen) ----------
    static function ga_num($v) { return (int)preg_replace('/\D/', '', (string)$v); }

    static function ga_date($v) {
        $v = trim((string)$v);
        if (preg_match('/^(\d{4})-?(\d{2})-?(\d{2})$/', $v, $m)) return "$m[1]-$m[2]-$m[3]";
        if (preg_match('/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/', $v, $m)) return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
        return '';
    }

    static function ga_secs($v) {
        $v = trim((string)$v);
        if (preg_match('/^(\d+):(\d{2}):(\d{2})$/', $v, $m)) return $m[1] * 3600 + $m[2] * 60 + $m[3];
        if (preg_match('/^(\d+):(\d{2})$/', $v, $m)) return $m[1] * 60 + $m[2];
        return (int)round((float)str_replace(',', '.', $v));
    }

    static function ga_import($file, $site) {
        global $wpdb;
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!$lines) return 'Die Datei ist leer oder nicht lesbar.';
        $rows = []; $start = ''; $end = '';
        foreach ($lines as $l) {
            $l = preg_replace('/^\xEF\xBB\xBF/', '', $l);
            if ($l === '') continue;
            if ($l[0] === '#') { // GA4-Kopfzeilen: „# Startdatum: 20231027“, „# Enddatum: 20231123“
                if (preg_match('/(?:startdatum|start date)\s*:\s*(\d{4}-?\d{2}-?\d{2})/iu', $l, $m)) $start = self::ga_date($m[1]);
                if (preg_match('/(?:enddatum|end date)\s*:\s*(\d{4}-?\d{2}-?\d{2})/iu', $l, $m)) $end = self::ga_date($m[1]);
                continue;
            }
            $rows[] = $l;
        }
        if (count($rows) < 2) return 'Keine Datenzeilen gefunden.';
        $delim = ','; $best = 0;
        foreach ([',', ';', "\t"] as $d) { $c = substr_count($rows[0], $d); if ($c > $best) { $best = $c; $delim = $d; } }
        $head = array_map(fn($h) => mb_strtolower(trim($h)), str_getcsv($rows[0], $delim));
        $col = ['date' => -1, 'month' => -1, 'path' => -1, 'views' => -1, 'users' => -1, 'secs' => -1, 'tot' => -1];
        foreach ($head as $i => $h) {
            if ($col['month'] < 0 && preg_match('/(jahr und monat|jahr-monat|year month|yearmonth|year-month)/u', $h)) $col['month'] = $i;
            elseif ($col['date'] < 0 && preg_match('/^(datum|date|tag|day)(\b|$)/u', $h)) $col['date'] = $i;
            elseif ($col['path'] < 0 && preg_match('/(seitenpfad|page path|pagepath|landingpage|zielseite|^seite$|^page$)/u', $h)) $col['path'] = $i;
            elseif ($col['views'] < 0 && preg_match('/^(aufrufe|views|seitenaufrufe|screen ?page ?views|pageviews|ansichten)/u', $h)) $col['views'] = $i;
            elseif ($col['tot'] < 0 && preg_match('/^(nutzerinteraktionsdauer|user engagement|gesamte interaktionsdauer)/u', $h)) $col['tot'] = $i;
            elseif ($col['secs'] < 0 && preg_match('/(durchschnittliche interaktionsdauer|average engagement time|durchschn\. besuchszeit|avg\. time on page|durchschnittliche verweildauer)/u', $h)) $col['secs'] = $i;
            elseif ($col['users'] < 0 && preg_match('/(aktive nutzer|active users|^nutzer$|^users$|gesamtzahl der nutzer|total users|besucher)/u', $h)) $col['users'] = $i;
        }
        if ($col['users'] < 0) foreach ($head as $i => $h) if ($col['users'] < 0 && preg_match('/(nutzer|users)/u', $h) && !preg_match('/(neue|new|pro|per|interaktion|engagement)/u', $h)) $col['users'] = $i;
        $found = implode(', ', $head);
        if ($col['views'] < 0) return 'Spalte „Aufrufe“ (englisch: Views) nicht gefunden. Gefundene Spalten: ' . $found;
        $agg = ($col['date'] < 0 && $col['month'] < 0);
        if ($agg && ($start === '' || $end === '')) return 'Der Export hat keine Spalte „Datum“ und in den Kopfzeilen keinen Zeitraum (Startdatum/Enddatum). Bitte den Export mit Datum oder direkt aus der GA-Oberfläche (CSV) erzeugen. Gefundene Spalten: ' . $found;
        $data = []; $min = '9999-99-99'; $max = '0000-00-00';
        foreach (array_slice($rows, 1) as $l) {
            $c = str_getcsv($l, $delim);
            $to = null;
            if ($agg) { $day = $start; $to = $end; }
            elseif ($col['month'] >= 0) {
                $mv = preg_replace('/\D/', '', (string)($c[$col['month']] ?? ''));
                if (strlen($mv) !== 6) continue;
                $day = substr($mv, 0, 4) . '-' . substr($mv, 4, 2) . '-01'; $to = gmdate('Y-m-t', strtotime($day));
            } else {
                $day = self::ga_date($c[$col['date']] ?? '');
                if ($day === '') continue; // Summenzeilen („Insgesamt“) und Leerzeilen
            }
            $path = $col['path'] >= 0 ? substr(wp_parse_url('http://x' . trim((string)($c[$col['path']] ?? '')), PHP_URL_PATH) ?: '/', 0, 255) : '';
            if ($col['path'] >= 0 && trim((string)($c[$col['path']] ?? '')) === '') continue;
            $us = $col['users'] >= 0 ? self::ga_num($c[$col['users']] ?? 0) : 0;
            $sc = $col['tot'] >= 0 ? self::ga_secs($c[$col['tot']] ?? 0) : ($col['secs'] >= 0 ? self::ga_secs($c[$col['secs']] ?? 0) * max(1, $us) : 0);
            $data[] = [$day, $path, self::ga_num($c[$col['views']] ?? 0), $us, $sc, $to];
            if ($day < $min) $min = $day; if (($to ?: $day) > $max) $max = $to ?: $day;
        }
        if (!$data) return 'Keine gültigen Zeilen (Datum nicht lesbar). Gefundene Spalten: ' . $found;
        $g = self::table_ga();
        // Ersetzt nur Gleiches: Tageswerte desselben Zeitraums, Zeiträume mit gleichem Start und Ende
        $periods = []; foreach ($data as $d) $periods[$d[0] . '|' . ($d[5] ?? '')] = [$d[0], $d[5]];
        if ($agg || $col['month'] >= 0) { foreach ($periods as $pp) $wpdb->query($wpdb->prepare("DELETE FROM $g WHERE site = %s AND day = %s AND to_day = %s", $site, $pp[0], $pp[1])); }
        else $wpdb->query($wpdb->prepare("DELETE FROM $g WHERE site = %s AND to_day IS NULL AND day BETWEEN %s AND %s", $site, $min, $max));
        foreach (array_chunk($data, 200) as $chunk) {
            $vals = []; $args = [];
            foreach ($chunk as $d) {
                if ($d[5] === null) { $vals[] = '(%s,%s,%s,%d,%d,%d,NULL)'; array_push($args, $d[0], $site, $d[1], $d[2], $d[3], $d[4]); }
                else { $vals[] = '(%s,%s,%s,%d,%d,%d,%s)'; array_push($args, $d[0], $site, $d[1], $d[2], $d[3], $d[4], $d[5]); }
            }
            $wpdb->query($wpdb->prepare("INSERT INTO $g (day, site, path, views, users, secs, to_day) VALUES " . implode(',', $vals), $args));
        }
        return count($data) . ' Zeilen importiert' . ($agg ? ' (Zeitraum ' . $start . ' bis ' . $end . ', Summe je Seite)' : ' (' . $min . ' bis ' . $max . ')') . '. Frühere Importe desselben Zeitraums für diese Seite wurden ersetzt.';
    }

    static function ga_report($sel) {
        global $wpdb;
        $g = self::table_ga();
        $where = $sel ? $wpdb->prepare('WHERE site = %s', $sel) : '';
        if (!(int)$wpdb->get_var("SELECT COUNT(*) FROM $g $where")) return;
        $mw = ($where ? $where . ' AND ' : 'WHERE ') . '(to_day IS NULL OR SUBSTRING(day, 1, 7) = SUBSTRING(to_day, 1, 7))'; // Tageswerte und Monatssummen
        $per = $wpdb->get_results("SELECT SUBSTRING(day, 1, 7) m, SUM(views) v, SUM(users) u FROM $g $mw GROUP BY SUBSTRING(day, 1, 7) ORDER BY m");
        $rng = $wpdb->get_row("SELECT MIN(day) a, MAX(day) b FROM $g $where");
        echo '<div class="ms-card"><h2>Früherer Zeitraum <small>(aus Google Analytics importiert, ' . esc_html($rng->a . ' bis ' . $rng->b) . ')</small></h2>';
        $mx = 1; foreach ($per as $p) $mx = max($mx, (int)$p->v);
        foreach ($per as $p) echo '<div class="ms-row"><span class="n">' . esc_html($p->m) . '</span><div class="ms-bar"><i style="width:' . round(100 * $p->v / $mx) . '%"></i></div><span class="v">' . number_format_i18n((int)$p->v) . '</span></div>';
        $w2 = $sel ? $wpdb->prepare("WHERE site = %s AND path <> '' AND to_day IS NULL", $sel) : "WHERE path <> '' AND to_day IS NULL";
        $top = $wpdb->get_results("SELECT path, SUM(views) v FROM $g $w2 GROUP BY path ORDER BY v DESC LIMIT 15");
        if ($top) {
            echo '<table class="ms-tbl" style="margin-top:12px"><thead><tr><th>Seite</th><th class="num">Aufrufe</th></tr></thead><tbody>';
            foreach ($top as $r) echo '<tr><td>' . esc_html($r->path) . '</td><td class="num">' . number_format_i18n((int)$r->v) . '</td></tr>';
            echo '</tbody></table>';
        }
        echo '<p class="ms-note">Balken = Seitenaufrufe pro Monat laut Google Analytics. Diese Zahlen sind nur Tagessummen aus dem Export und werden nicht mit den eigenen Daten vermischt; Google zählt anders (Cookies, Sitzungen, ohne Bot-Filter dieses Plugins), die Werte sind deshalb nur grob vergleichbar.</p></div>';
        // Zeiträume mit Summen je Seite (Exporte ohne Tageswerte)
        $aw = ($sel ? $wpdb->prepare('WHERE site = %s AND ', $sel) : 'WHERE ') . "to_day IS NOT NULL AND SUBSTRING(day, 1, 7) <> SUBSTRING(to_day, 1, 7)";
        $pers = $wpdb->get_results("SELECT site, day, to_day, SUM(views) v, SUM(users) u FROM $g $aw GROUP BY site, day, to_day ORDER BY to_day DESC LIMIT 6");
        foreach ($pers as $pr) {
            $tp = $wpdb->get_results($wpdb->prepare("SELECT path, views v, users u FROM $g WHERE site = %s AND day = %s AND to_day = %s AND path <> '' ORDER BY views DESC LIMIT 10", $pr->site, $pr->day, $pr->to_day));
            echo '<div class="ms-card"><h2>Seiten im Zeitraum <small>(Google-Export ' . esc_html($pr->day . ' bis ' . $pr->to_day . ($sel ? '' : ', ' . $pr->site)) . ': ' . number_format_i18n((int)$pr->v) . ' Aufrufe)</small></h2><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Aufrufe</th><th class="num">Nutzer</th></tr></thead><tbody>';
            foreach ($tp as $r) echo '<tr><td>' . esc_html($r->path) . '</td><td class="num">' . number_format_i18n((int)$r->v) . '</td><td class="num">' . number_format_i18n((int)$r->u) . '</td></tr>';
            echo '</tbody></table></div>';
        }
    }

    // ---------- Einstellungen + Übersicht ----------
    static function menu() {
        add_menu_page('1AB-Test-Statistik', '1AB-Test-Statistik', 'manage_options', 'mini-statistik', [__CLASS__, 'page'], 'dashicons-chart-bar', '58.5'); // direkt unter 1AB Affiliate Help (Position 58)
        add_submenu_page('mini-statistik', 'Auswertung', 'Auswertung', 'manage_options', 'mini-statistik', [__CLASS__, 'page']);
        add_submenu_page('mini-statistik', 'Weiterlesen & Popup', 'Weiterlesen & Popup', 'manage_options', 'mini-statistik-weiterlesen', [__CLASS__, 'weiterlesen_seite']);
        add_submenu_page('mini-statistik', 'Einstellungen', 'Einstellungen', 'manage_options', 'mini-statistik-einstellungen', function () { $_GET['ms_einst'] = '1'; self::page(); });
    }

    static function weiterlesen_seite() {
        if (!current_user_can('manage_options')) return;
        echo '<div class="wrap">';
        AB1_Weiterlesen::tab();
        echo '</div>';
    }

    static function page() {
        if (!current_user_can('manage_options')) return;
        $um = '';
        if (!empty($_GET['ms_update_jetzt']) && wp_verify_nonce((string)($_GET['_wpnonce'] ?? ''), 'ms_update_jetzt')) {
            $nv = self::update_nachsehen(true);
            if ($nv !== '') {
                $pk = plugin_basename(__FILE__);
                $um = '<div class="notice notice-success inline"><p>Neue Version <b>' . esc_html($nv) . '</b> gefunden (installiert: ' . esc_html(self::VERSION) . '). <a class="button button-primary" href="' . esc_url(wp_nonce_url(self_admin_url('update.php?action=upgrade-plugin&plugin=' . rawurlencode($pk)), 'upgrade-plugin_' . $pk)) . '">Jetzt updaten</a></p></div>';
            } else {
                $us = (array)get_option('ms_update_status', []);
                $um = '<div class="notice ' . (($us['code'] ?? '') === '200' ? 'notice-info' : 'notice-warning') . ' inline"><p>' . (($us['code'] ?? '') === '200' ? 'Kein Update gefunden: Installiert ist die neueste Version (' . esc_html(self::VERSION) . ').' : 'Die Update-Quelle war nicht erreichbar (Antwort ' . esc_html((string)($us['code'] ?? '?')) . '). Später noch einmal versuchen.') . '</p></div>';
            }
        }
        if (isset($_POST['ms_save']) && check_admin_referer('ms_save')) {
            update_option(self::OPT, [
                'mode' => in_array($_POST['mode'] ?? '', ['off', 'hub', 'client'], true) ? $_POST['mode'] : 'off',
                'hub_url' => esc_url_raw(wp_unslash($_POST['hub_url'] ?? '')),
                'site_key' => sanitize_text_field(wp_unslash($_POST['site_key'] ?? '')),
                'sites' => sanitize_textarea_field(wp_unslash($_POST['sites'] ?? '')),
                'keep_days' => max(0, min(3650, (int)($_POST['keep_days'] ?? 0))),
                'salt_days' => max(1, min(30, (int)($_POST['salt_days'] ?? 7))),
                'mail_status' => empty($_POST['mail_status']) ? 0 : 1,
                'mail_alarm' => empty($_POST['mail_alarm']) ? 0 : 1,
                'mail_to' => is_email(sanitize_text_field(wp_unslash($_POST['mail_to'] ?? ''))) ? sanitize_text_field(wp_unslash($_POST['mail_to'])) : '',
            ]);
            echo '<div class="updated"><p>Gespeichert.</p></div>';
        }
        if (isset($_POST['ms_testmail'])) { $st_ = self::status_calc(); $ok_ = self::status_send($st_, true); echo '<div class="' . ($ok_ ? 'updated' : 'error') . '"><p>' . ($ok_ ? 'Testmail gesendet an ' . esc_html(self::mail_empf()) . '.' : 'Die Testmail konnte nicht gesendet werden (Mailversand der Seite prüfen).') . '</p></div>'; }
        if (isset($_POST['ms_import']) && check_admin_referer('ms_import')) {
            $isite = sanitize_text_field(wp_unslash($_POST['import_site'] ?? ''));
            if (!isset(self::allowed_sites()[$isite])) echo '<div class="error"><p>Bitte eine erlaubte Seite wählen.</p></div>';
            elseif (empty($_FILES['import_file']['tmp_name'][0])) echo '<div class="error"><p>Keine Datei gewählt.</p></div>';
            else foreach ((array)$_FILES['import_file']['tmp_name'] as $fi => $tmp) {
                if ($tmp === '' || !is_uploaded_file($tmp)) continue;
                $fname = sanitize_file_name((string)($_FILES['import_file']['name'][$fi] ?? ''));
                echo '<div class="updated"><p><b>' . esc_html($fname) . ':</b> ' . esc_html(self::ga_import($tmp, $isite)) . '</p></div>';
            }
        }
        if (isset($_POST['ms_hide']) && check_admin_referer('ms_hide')) {
            $hid = (array)get_option('mini_statistik_hidden', []);
            $hk = sanitize_text_field(wp_unslash($_POST['pk'] ?? ''));
            if ($_POST['ms_hide'] === 'show') $hid = [];
            elseif ($hk !== '') $hid[] = $hk;
            update_option('mini_statistik_hidden', array_values(array_unique($hid)), false);
        }
        $o = self::opts();
        self::styles();
        echo '<div class="wrap ms"><h1>1AB-Test-Statistik <a class="page-title-action" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=mini-statistik&ms_update_jetzt=1'), 'ms_update_jetzt')) . '">Nach Updates suchen</a></h1>' . $um;
        if ($o['mode'] === 'hub') { self::live_box(); self::report(); }
        elseif ($o['mode'] === 'client') echo self::remote_report();
        echo '<details class="ms-card"' . ($o['mode'] === 'hub' && empty($_GET['ms_einst']) ? '' : ' open') . '><summary><b>Einstellungen</b></summary><form method="post">';
        wp_nonce_field('ms_save');
        echo '<table class="form-table">';
        echo '<tr><th>Modus</th><td><select name="mode">';
        foreach (['off' => 'Aus', 'hub' => 'Zentrale (sammelt und zeigt alle Seiten)', 'client' => 'Sendet an die Zentrale'] as $k => $l)
            echo '<option value="' . esc_attr($k) . '"' . selected($o['mode'], $k, false) . '>' . esc_html($l) . '</option>';
        echo '</select></td></tr>';
        echo '<tr><th>Zentrale-Adresse (nur Sender)</th><td><input class="regular-text" name="hub_url" value="' . esc_attr($o['hub_url']) . '" placeholder="https://zentrale.de"></td></tr>';
        echo '<tr><th>Kennwort dieser Seite (nur Sender; die Zentrale nimmt es aus der Liste)</th><td><input class="regular-text" name="site_key" value="' . esc_attr($o['site_key']) . '"></td></tr>';
        echo '<tr><th>Erlaubte Seiten (nur Zentrale)</th><td><textarea name="sites" rows="9" cols="60" placeholder="domain.de|kennwort">' . esc_textarea($o['sites']) . '</textarea><p class="description">Eine Zeile je Seite: <code>domain.de|kennwort</code>. Auch die Zentrale selbst eintragen.</p></td></tr>';
        echo '<tr><th>Eigene Besuche</th><td>Angemeldete Benutzer werden nie gezählt. Wenn du auf einer Seite angemeldet die Startseite ansiehst, merkt sich dieser Browser das (kleiner Eintrag nur auf deinem Gerät) und zählt dich auch ohne Anmeldung nicht mehr. Einmal pro Seite und Browser nötig; im privaten Fenster zählst du weiter.</td></tr>';
        $us = (array)get_option('ms_update_status', []);
        echo '<tr><th>Updates</th><td>Installiert: ' . esc_html(self::VERSION) . '. ' . ($us ? 'Zuletzt geprüft: ' . esc_html(wp_date('d.m.y H:i', (int)$us['ts'])) . ' (Antwort ' . esc_html((string)$us['code']) . ', neueste Version ' . esc_html((string)($us['version'] ?: '–')) . '). ' : 'Noch nicht geprüft. ') . 'Prüfabstand jetzt: ' . (int)round(self::update_intervall() / 60) . ' Minuten. Kommt längere Zeit nichts Neues, wird seltener geprüft (bis einmal am Tag); bei vielen neuen Versionen im Minutentakt. Automatische Updates schaltest du in der Pluginliste ein.</td></tr>';
        echo '<tr><th>Aufbewahrung (nur Zentrale)</th><td><input type="number" min="0" max="3650" name="keep_days" value="' . (int)$o['keep_days'] . '"> Tage<p class="description">0 = unbegrenzt aufbewahren. Sonst werden Einzeldaten nach so vielen Tagen gelöscht.</p></td></tr>';
        echo '<tr><th>Wiedererkennung (nur Zentrale)</th><td><input type="number" min="1" max="30" name="salt_days" value="' . (int)$o['salt_days'] . '"> Tage<p class="description">So lange wird derselbe Besucher über mehrere Tage erkannt (Wiederkehrer). Danach wird der Zufallswert überschrieben, alte Kennungen lassen sich nicht mehr zuordnen. 1 = nur innerhalb eines Tages.</p></td></tr>';
        echo '<tr><th>Status-Mail (nur Zentrale)</th><td><label><input type="checkbox" name="mail_status" value="1"' . checked(!empty($o['mail_status']), true, false) . '> Mail senden, wenn der Status schlechter wird</label><br><input type="email" class="regular-text" name="mail_to" value="' . esc_attr($o['mail_to']) . '" placeholder="' . esc_attr((string)get_option('admin_email')) . '"><p class="description">Höchstens eine Mail am Tag, nur bei Verschlechterung (grün zu orange oder rot, orange zu rot). Inhalt: Status, Zahlen und Dateinamen von Fehlern, nichts über einzelne Besucher. Leer lassen = Admin-Adresse der Seite. <button class="button" name="ms_testmail" value="1">Testmail senden</button></p></td></tr>';
        echo '<tr><th>Sofortwarnung (nur Zentrale)</th><td><label><input type="checkbox" name="mail_alarm" value="1"' . checked(!empty($o['mail_alarm']), true, false) . '> Sofort mailen bei roten Werten, vielen Fehlern oder wenn eine Seite keine Daten mehr sendet</label><p class="description">Geprüft stündlich, je Grund höchstens eine Mail in 24 Stunden, mit Tipp „Was jetzt tun?“. Gleicher Empfänger wie oben.</p></td></tr>';
        echo '</table><p><button class="button button-primary" name="ms_save" value="1">Speichern</button></p></form>';
        echo '<details class="ms-card"><summary><b>Datenschutz-Textbaustein zum Kopieren</b></summary><p class="description">Vorschlag für die Datenschutzerklärung dieser Seite, passend zu den Einstellungen. Das ist keine Rechtsberatung: bitte rechtlich prüfen lassen, besonders die Frage, ob für das Auslesen von Browser-Werten eine Einwilligung nötig ist (§ 25 TDDDG).</p><textarea id="ms-ds" readonly rows="14" style="width:100%;max-width:100%;box-sizing:border-box">' . esc_textarea(self::datenschutz_text()) . '</textarea><p><button type="button" class="button" onclick="var t=document.getElementById(\'ms-ds\');t.select();try{navigator.clipboard.writeText(t.value)}catch(e){document.execCommand(\'copy\')}this.textContent=\'Kopiert\'">In die Zwischenablage kopieren</button></p></details>';
        if ($o['mode'] === 'hub') {
            echo '<hr><h3>Früheren Zeitraum aus Google Analytics importieren</h3><form method="post" enctype="multipart/form-data">';
            wp_nonce_field('ms_import');
            echo '<p>Seite: <select name="import_site">';
            foreach (array_keys(self::allowed_sites()) as $d) echo '<option>' . esc_html($d) . '</option>';
            echo '</select> &nbsp; CSV-Datei: <input type="file" name="import_file[]" multiple accept=".csv,text/csv,text/plain"></p><p class="description">GA4: Berichte, Seiten und Bildschirme (oder Erkunden mit Datum und Seitenpfad), Zeitraum wählen, Export als CSV. Gebraucht werden Datum und Aufrufe, optional Seitenpfad, Nutzer und durchschnittliche Interaktionsdauer. Ein Import desselben Zeitraums ersetzt den früheren.</p><p><button class="button" name="ms_import" value="1">Importieren</button></p></form>';
        }
        echo '</details></div>';
    }

    static function styles() {
        echo '<style>
.ms{max-width:1100px}.ms-card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:16px 20px;margin:16px 0}
.ms-card h2{margin:0 0 10px;font-size:16px}.ms-card h2 small{font-weight:400;color:#646970}
.ms-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,150px),1fr));gap:12px;margin:16px 0}
.ms-kpi{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:14px 16px}.ms-kpi b{display:block;font-size:26px;line-height:1.2}.ms-kpi span{color:#646970;font-size:12px}
.ms-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:16px}
.ms-row{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,2fr) 48px;gap:8px;align-items:center;margin:5px 0;font-size:13px}
.ms-grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,480px),1fr));gap:16px}.ms-wide .ms-row .n{white-space:normal;overflow:visible;line-height:1.3}.ms-wide .ms-row{grid-template-columns:minmax(0,3fr) minmax(0,1.2fr) 48px}.ms-row .n{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ms-row .v{text-align:right;font-variant-numeric:tabular-nums}
.ms-bar{height:10px;background:#f0f0f1;border-radius:5px;overflow:hidden}.ms-bar i{display:block;height:100%;background:#2271b1;border-radius:5px}
.ms-bar.amz i{background:#d98200}.ms-bar.ebay i{background:#c0392b}.ms-bar.oth i{background:#787c82}.ms-bar.own i{background:#00a32a}
.ms-tbl{width:100%;border-collapse:collapse;font-size:13px}.ms-tbl td,.ms-tbl th{padding:6px 8px;border-bottom:1px solid #f0f0f1;text-align:left}.ms-tbl th{color:#646970;font-weight:600}
.ms-tbl td.num,.ms-tbl th.num{text-align:right;font-variant-numeric:tabular-nums}.ms-w{width:80px;color:#646970}
.ms-big{font-size:34px;font-weight:600}.ms-now{display:flex;align-items:baseline;gap:8px}.ms-sub{color:#50575e;margin:4px 0 10px}
.ms-dot{width:9px;height:9px;border-radius:50%;background:#00a32a;display:inline-block;animation:msp 1.6s infinite}@keyframes msp{50%{opacity:.25}}
.ms-pill{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px;background:#e5e5e5}.ms-p-Amazon{background:#fcefd6;color:#8a5600}.ms-p-eBay{background:#fbe1de;color:#a02a1e}.ms-p-Eigene\ Seiten{background:#d7f0dd;color:#14631f}
.ms-card h2 small a{text-decoration:none;color:#646970}.ms-card h2 small a.ms-on{color:#2271b1;font-weight:600}.ms-d{display:block;font-style:normal;font-size:12px;font-weight:600;margin-top:2px}.ms-bar-v{transform-box:fill-box;transform-origin:bottom;animation:msg .5s ease-out both}@keyframes msg{from{transform:scaleY(0)}}
.ms-nav a{margin-right:12px}.ms-note{color:#646970;font-size:12px}
.ms-card{overflow-x:auto;box-sizing:border-box;max-width:100%}.ms-tbl td{word-break:break-word}.ms .regular-text,.ms input[type=text],.ms input[type=url],.ms textarea{max-width:100%;box-sizing:border-box}
@media(max-width:700px){.ms-card{padding:12px}.ms-kpis{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.ms-kpi{padding:10px 12px}.ms-kpi b{font-size:21px}.ms-tbl{min-width:560px;font-size:12px}.ms-tbl td,.ms-tbl th{padding:5px 6px}.ms-row{grid-template-columns:minmax(0,1.2fr) minmax(0,1.4fr) 40px}.ms-wide .ms-row{grid-template-columns:minmax(0,2fr) minmax(0,1fr) 40px}.ms-big{font-size:28px}.ms .form-table,.ms .form-table tbody,.ms .form-table tr,.ms .form-table th,.ms .form-table td{display:block;width:auto;padding:6px 0}}
</style>';
    }

    static function bars($title, $rows, $class = '', $wide = false) {
        // $rows: [[label, value], ...]
        $max = 1; foreach ($rows as $r) $max = max($max, (int)$r[1]);
        echo '<div class="ms-card' . ($wide ? ' ms-wide' : '') . '"><h2>' . esc_html($title) . '</h2>';
        if (!$rows) echo '<p class="ms-note">Noch keine Daten.</p>';
        foreach ($rows as $r) {
            $cls = $class;
            if (is_array($class)) $cls = $class[$r[0]] ?? '';
            echo '<div class="ms-row"><span class="n" title="' . esc_attr($r[0]) . '">' . esc_html($r[0]) . '</span><div class="ms-bar ' . esc_attr($cls) . '"><i style="width:' . round(100 * (int)$r[1] / $max) . '%"></i></div><span class="v">' . (int)$r[1] . '</span></div>';
        }
        echo '</div>';
    }

    // Klicks nach Seite (Artikel) und nach Website
    static function clicks_by_page($w, $multi) {
        global $wpdb;
        $t = self::table();
        $rows = $wpdb->get_results("SELECT site, path, target, item, pn, label, COUNT(*) n FROM $t WHERE kind='click' AND $w GROUP BY site, path, target, item, pn, label LIMIT 8000");
        $views = []; foreach ($wpdb->get_results("SELECT site, path, COUNT(*) v FROM $t WHERE kind='view' AND $w GROUP BY site, path") as $r) $views[$r->site . $r->path] = (int)$r->v;
        $pg = []; $si = [];
        foreach ($rows as $r) {
            $k = $r->site . $r->path; $pp = self::partner($r->target); $n = (int)$r->n;
            $pg[$k] ??= ['n' => 0, 'Amazon' => 0, 'eBay' => 0, 'Sonstige' => 0, 'Eigene Seiten' => 0, 'prod' => [], 'site' => $r->site];
            $pg[$k]['n'] += $n; $pg[$k][$pp] += $n;
            $nm = $r->pn !== '' ? $r->pn : ($r->label !== '' ? $r->label : ($r->item !== '' ? $r->item : $r->target));
            $pg[$k]['prod'][$nm] = ($pg[$k]['prod'][$nm] ?? 0) + $n;
            $si[$r->site] ??= ['n' => 0, 'Amazon' => 0, 'eBay' => 0, 'Sonstige' => 0, 'Eigene Seiten' => 0]; $si[$r->site]['n'] += $n; $si[$r->site][$pp] += $n;
        }
        uasort($pg, fn($a, $b) => $b['n'] <=> $a['n']); uasort($si, fn($a, $b) => $b['n'] <=> $a['n']);
        $sv = []; foreach ($views as $k => $v) { $site = strstr($k, '/', true); if ($site !== false) $sv[$site] = ($sv[$site] ?? 0) + $v; }
        $out = '';
        if ($multi) {
            $out .= '<div class="ms-card"><h2>Klicks nach Website</h2><table class="ms-tbl"><thead><tr><th>Website</th><th class="num">Klicks</th><th class="num">Amazon</th><th class="num">eBay</th><th class="num">Sonstige</th><th class="num">Aufrufe</th><th class="num">Klickrate</th></tr></thead><tbody>';
            foreach ($si as $site => $x) { $v = $sv[$site] ?? 0; $out .= '<tr><td>' . esc_html($site) . '</td><td class="num"><b>' . $x['n'] . '</b></td><td class="num">' . $x['Amazon'] . '</td><td class="num">' . $x['eBay'] . '</td><td class="num">' . ($x['Sonstige'] + $x['Eigene Seiten']) . '</td><td class="num">' . $v . '</td><td class="num">' . ($v ? round(100 * $x['n'] / $v) . ' %' : '–') . '</td></tr>'; }
            if (!$si) $out .= '<tr><td colspan="7">Noch keine Klicks.</td></tr>';
            $out .= '</tbody></table></div>';
        }
        $out .= '<div class="ms-card"><h2>Klicks nach Seite (Artikel)</h2><div class="ms-scroll"><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Klicks</th><th class="num">Amazon</th><th class="num">eBay</th><th class="num">Sonstige</th><th class="num">Aufrufe</th><th class="num">Klickrate</th><th>Meistgeklickt auf dieser Seite</th></tr></thead><tbody>';
        foreach (array_slice($pg, 0, 100, true) as $k => $x) {
            $v = $views[$k] ?? 0; arsort($x['prod']);
            $top = []; foreach (array_slice($x['prod'], 0, 3, true) as $nm => $c) $top[] = esc_html(mb_substr((string)$nm, 0, 50)) . ' (' . (int)$c . ')';
            $out .= '<tr><td><a href="' . esc_url('https://' . $k) . '" target="_blank" rel="noopener noreferrer">' . esc_html($k) . '</a></td><td class="num"><b>' . $x['n'] . '</b></td><td class="num">' . $x['Amazon'] . '</td><td class="num">' . $x['eBay'] . '</td><td class="num">' . ($x['Sonstige'] + $x['Eigene Seiten']) . '</td><td class="num">' . $v . '</td><td class="num">' . ($v ? round(100 * $x['n'] / $v) . ' %' : '–') . '</td><td class="ms-note">' . implode('<br>', $top) . '</td></tr>';
        }
        if (!$pg) $out .= '<tr><td colspan="8">Noch keine Klicks.</td></tr>';
        return $out . '</tbody></table></div><p class="ms-note">Die 100 Seiten mit den meisten Klicks im gewählten Zeitraum. Spaltenköpfe anklicken zum Sortieren.</p></div>';
    }

    // Roboter in der Übersicht: wer sich zu erkennen gibt, wie viele sich verstecken, Geräte
    static function robot_overview($w, $meas, $bots, $quiet, $rdev) {
        global $wpdb;
        $t = self::table();
        $named = []; $tot = 0;
        foreach ($wpdb->get_results("SELECT label, COUNT(*) n FROM $t WHERE kind='robot' AND $w GROUP BY label ORDER BY n DESC LIMIT 30") as $r) { $named[$r->label] = (int)$r->n; $tot += (int)$r->n; }
        if (!$named && $meas < 20) return '';
        ob_start();
        echo '<div class="ms-grid">';
        $rows = []; foreach ($named as $nm => $n) $rows[] = [$nm . ' (' . round(100 * $n / max(1, $tot)) . ' %)', $n];
        self::bars('Roboter, die sich zu erkennen geben', $rows);
        if ($meas >= 20) {
            $hid = $bots + $quiet;
            self::bars('Roboter, die sich verstecken (Schätzung)', [
                ['als automatisiert gemeldet (' . round(100 * $bots / max(1, $hid)) . ' %)', $bots],
                ['ganz ohne Maus, Touch oder Scrollen (' . round(100 * $quiet / max(1, $hid)) . ' %)', $quiet],
            ]);
            $dr = []; foreach (['desktop' => 'Desktop', 'mobil' => 'Mobil', 'tablet' => 'Tablet', 'unbekannt' => 'Unbekannt'] as $k => $l) if (!empty($rdev[$k])) $dr[] = [$l . ' (' . round(100 * $rdev[$k] / max(1, $hid)) . ' %)', $rdev[$k]];
            self::bars('Gerät der versteckten Roboter', $dr);
        }
        echo '</div><p class="ms-note">Zahlen links: Zugriffe von Robotern, die sich selbst benennen (Prozent = Anteil an allen benannten Robotern). Rechts: Besucher, die wie Roboter wirken. „Ohne Maus, Touch oder Scrollen" fasst die Signale zusammen, einzeln lassen sie sich nicht trennen. Alles sind Schätzungen und stehen nicht in den Besucherzahlen.';
        return ob_get_clean();
    }

    // Roboter-Statistik (aus User-Agent und Server-Zugriffen; keine IP). Wege und Abstände werden aus der Reihenfolge der Zugriffe geschätzt.
    static function robot_report($w) {
        global $wpdb;
        $t = self::table();
        $rows = $wpdb->get_results("SELECT ts, label, target, site, path, pn, via FROM $t WHERE kind='robot' AND $w ORDER BY label, site, ts, id LIMIT 20000");
        $typ = []; $bot = []; $total = 0;
        foreach ($rows as $r) {
            $total++; $typ[$r->target] = ($typ[$r->target] ?? 0) + 1;
            $b = &$bot[$r->label];
            if (!isset($b)) $b = ['n' => 0, 'typ' => $r->target, 'pages' => [], 'ua' => $r->pn, 'js' => 0, 'trans' => [], 'gaps' => [], 'days' => [], 'first' => $r->ts, 'last' => $r->ts, 'prev' => null];
            $b['n']++; $b['last'] = $r->ts; $k = $r->site . $r->path;
            $b['pages'][$k] = ($b['pages'][$k] ?? 0) + 1;
            if ($r->via === 'js') $b['js']++;
            $day = substr($r->ts, 0, 10); $b['days'][$day] = ($b['days'][$day] ?? 0) + 1;
            if ($b['prev'] && $b['prev'][0] === $r->site) { // Folgezugriff derselben Roboterart auf derselben Website innerhalb von 10 Minuten = gleicher Lauf
                $gap = strtotime($r->ts . ' UTC') - strtotime($b['prev'][2] . ' UTC');
                if ($gap >= 0 && $gap <= 600) { $tk = $b['prev'][1] . ' → ' . $r->path; if ($b['prev'][1] !== $r->path) $b['trans'][$tk] = ($b['trans'][$tk] ?? 0) + 1; $b['gaps'][] = $gap; }
            }
            $b['prev'] = [$r->site, $r->path, $r->ts];
            unset($b);
        }
        arsort($typ); uasort($bot, fn($a, $b) => $b['n'] <=> $a['n']);
        ob_start();
        echo '<div class="ms-card"><h2>Roboter auf deinen Seiten</h2><p><span class="ms-big">' . number_format_i18n($total) . '</span> Roboter-Zugriffe im gewählten Zeitraum (nicht in den Besucherzahlen oben enthalten).</p>';
        echo '<p class="ms-note">Erkannt wird nur am Namen, den sich der Roboter selbst gibt (User-Agent). Wer sich als normaler Browser tarnt, fällt hier nicht auf; dafür dient die Roboter-Schätzung in der Übersicht. Gezählt wird, wenn die Seite vom Server neu gebaut wird (nicht bei Seiten aus dem Zwischenspeicher) und wenn der Roboter JavaScript ausführt. Die echte Zahl ist daher eher höher. Gespeichert werden nur Name, Seite, Zeit und gekürzte Kennung, nie IP-Adressen.</p></div>';
        self::bars('Roboter nach Art', array_map(fn($k, $v) => [$k, $v], array_keys($typ), array_values($typ)));
        echo '<div class="ms-card"><h2>Was bedeuten die Arten?</h2><ul style="margin:0 0 0 18px;list-style:disc">'
            . '<li><b>Suchmaschine</b>: Google, Bing & Co. lesen deine Seiten, damit sie in den Suchergebnissen erscheinen.</li>'
            . '<li><b>KI-Crawler</b>: Dienste wie ChatGPT, Claude, Perplexity lesen Seiten, um Antworten zu geben oder Modelle zu trainieren.</li>'
            . '<li><b>SEO-Tool</b>: Auswertungsdienste (Ahrefs, Semrush …), die Links und Rankings für ihre Kunden sammeln.</li>'
            . '<li><b>Social-Vorschau</b>: Wenn jemand deinen Link teilt, holt Facebook, Pinterest, WhatsApp usw. Titel und Bild für die Vorschau.</li>'
            . '<li><b>Überwachung</b>: Dienste, die regelmäßig nachsehen, ob eine Seite erreichbar und schnell ist (z. B. UptimeRobot, Pingdom). Meist vom Seitenbetreiber oder Hoster beauftragt.</li>'
            . '<li><b>Skript</b>: Selbstgeschriebene Programme oder Headless-Browser, kein Mensch am Bildschirm.</li>'
            . '<li><b>Unbekannt</b>: Nennt sich Roboter, steht aber nicht in der Liste. Wenn möglich steht der Name aus der Kennung dahinter.</li></ul></div>';
        echo '<div class="ms-card"><h2>Welche Roboter und was sie tun <small>(Zeile anklicken für Details)</small></h2>';
        $i = 0;
        foreach (array_slice($bot, 0, 40, true) as $nm => $x) {
            arsort($x['pages']); arsort($x['trans']); ksort($x['days']);
            $info = self::bot_info($x['ua']);
            $med = null; if ($x['gaps']) { sort($x['gaps']); $med = $x['gaps'][(int)floor(count($x['gaps']) / 2)]; }
            echo '<details class="ms-bot"' . ($i++ === 0 ? ' open' : '') . '><summary><b>' . esc_html($nm) . '</b> &nbsp;<span class="ms-pill">' . esc_html($x['typ']) . '</span> &nbsp;' . (int)$x['n'] . ' Zugriffe, ' . count($x['pages']) . ' Seiten</summary><div style="padding:6px 0 14px 14px">';
            echo '<p class="ms-note">' . esc_html($info[2] ?? '') . ' &nbsp;·&nbsp; Kennung: <code>' . esc_html(mb_substr($x['ua'], 0, 100)) . '</code></p>';
            echo '<p>Zuerst gesehen ' . esc_html(wp_date('d.m.y H:i', strtotime($x['first'] . ' UTC'))) . ', zuletzt ' . esc_html(wp_date('d.m.y H:i', strtotime($x['last'] . ' UTC'))) . '. '
                . ($med !== null ? 'Läufe mit mehreren Seiten: typischer Abstand zwischen zwei Abrufen ' . ($med < 60 ? (int)$med . ' Sekunden' : round($med / 60, 1) . ' Minuten') . '. ' : 'Meist ein einzelner Abruf pro Lauf, keine Seite-zu-Seite-Wege erkennbar. ')
                . ($x['js'] ? (int)$x['js'] . ' Zugriffe führten JavaScript aus (kann Seiten wie ein Browser darstellen).' : 'Führt kein JavaScript aus: sieht nur den Text im Quellcode deiner Seite.') . '</p>';
            echo '<div class="ms-grid2"><div><b>Ruft am häufigsten auf</b><table class="ms-tbl"><tbody>';
            foreach (array_slice($x['pages'], 0, 12, true) as $pg => $c) echo '<tr><td>' . esc_html($pg) . '</td><td class="num">' . (int)$c . '</td></tr>';
            echo '</tbody></table></div><div><b>Wege von Seite zu Seite</b>';
            if ($x['trans']) { echo '<table class="ms-tbl"><tbody>'; foreach (array_slice($x['trans'], 0, 12, true) as $tr => $c) echo '<tr><td>' . esc_html($tr) . '</td><td class="num">' . (int)$c . '</td></tr>'; echo '</tbody></table>'; }
            else echo '<p class="ms-note">Keine aufeinanderfolgenden Abrufe innerhalb von 10 Minuten gesehen.</p>';
            echo '</div></div>';
            if (count($x['days']) > 1) { $dd = []; foreach ($x['days'] as $d => $c) $dd[] = esc_html(wp_date('d.m.', strtotime($d))) . ': ' . (int)$c; echo '<p class="ms-note">Zugriffe pro Tag: ' . implode(' · ', array_slice($dd, -14)) . '</p>'; }
            echo '</div></details>';
        }
        if (!$bot) echo '<p>Noch keine Roboter-Zugriffe erfasst.</p>';
        echo '<p class="ms-note">Zeiten auf der Seite und Scrolltiefe lassen sich bei Robotern nicht messen: Sie bleiben nicht „auf" der Seite, sondern holen sie nur ab. Gemessen wird der Abstand zwischen zwei Abrufen. Wege entstehen aus der Reihenfolge der Abrufe derselben Roboterart auf derselben Website (innerhalb von 10 Minuten); bei mehreren gleichzeitigen Robotern derselben Art können Wege vermischt sein.</p></div>';
        echo '<style>.ms-bot{border-top:1px solid #dcdcde;padding:8px 0}.ms-bot summary{cursor:pointer}</style>';
        return ob_get_clean();
    }

    /** Zusatzbedingung „nur Menschen“: Bewegungssignal vorhanden (hum=1) und nicht als automatisiert gemeldet. Zeilen aus der Zeit vor dem Signal (je Seite) zählen mit, weil dort nichts unterschieden werden kann. */
    static function human_where() {
        static $c = null;
        if ($c !== null) return $c;
        global $wpdb; $t = self::table();
        $since = $wpdb->get_results("SELECT site, MIN(ts) m FROM $t WHERE kind='human' GROUP BY site");
        if (!$since) return $c = " AND via<>'bot'";
        $or = ['hum=1']; $in = [];
        foreach ($since as $r) { $in[] = $wpdb->prepare('%s', $r->site); $or[] = $wpdb->prepare('(site=%s AND ts < %s)', $r->site, $r->m); }
        $or[] = 'site NOT IN (' . implode(',', $in) . ')';
        return $c = " AND via<>'bot' AND (" . implode(' OR ', $or) . ')';
    }

    // Reiter „Suche & 404“: was Besucher auf der Seite suchen und welche Adressen ins Leere führen
    static function search_report($w_all, $multi, $visitors) {
        global $wpdb; $t = self::table();
        $wn = $w_all . " AND via<>'bot'";
        $rows = $wpdb->get_results("SELECT site, label, COUNT(*) n, COUNT(DISTINCT visitor) vis, MAX(ts) lt, SUM(item='0') zero, SUM(item<>'') known FROM $t WHERE kind='srch' AND $wn GROUP BY site, label ORDER BY n DESC LIMIT 300");
        $tot = $zero = $known = 0; foreach ($rows as $r) { $tot += (int)$r->n; $zero += (int)$r->zero; $known += (int)$r->known; }
        ob_start();
        echo '<div class="ms-kpis">';
        foreach ([[number_format_i18n($tot), 'Suchanfragen'], [number_format_i18n(count($rows)), 'verschiedene Begriffe'], [$known ? round(100 * $zero / $known) . ' %' : '–', 'Suchen ohne Treffer'], [$visitors ? number_format_i18n(round(100 * $tot / $visitors, 1), 1) : '–', 'Suchen je 100 Besucher']] as $k) echo '<div class="ms-kpi"><b>' . esc_html($k[0]) . '</b><span>' . esc_html($k[1]) . '</span></div>';
        echo '</div>';
        echo '<div class="ms-card"><h2>Was Besucher auf der Seite suchen</h2><table class="ms-tbl"><thead><tr><th>Suchbegriff</th>' . ($multi ? '<th>Website</th>' : '') . '<th class="num">Suchen</th><th class="num">Besucher</th><th class="num">ohne Treffer</th><th>zuletzt</th></tr></thead><tbody>';
        foreach (array_slice($rows, 0, 100) as $r) echo '<tr><td><b>' . esc_html($r->label) . '</b></td>' . ($multi ? '<td>' . esc_html($r->site) . '</td>' : '') . '<td class="num">' . (int)$r->n . '</td><td class="num">' . (int)$r->vis . '</td><td class="num">' . ((int)$r->known ? (int)$r->zero . ' von ' . (int)$r->known : '–') . '</td><td>' . esc_html(wp_date('d.m.y H:i', strtotime($r->lt . ' UTC'))) . '</td></tr>';
        if (!$rows) echo '<tr><td colspan="' . ($multi ? 6 : 5) . '">Noch keine Suchen erfasst. Erfasst wird, was Besucher in das Suchfeld der Seite eingeben (nicht Google). Begriffe mit @, Links oder langen Zahlen werden nie gespeichert.</td></tr>';
        echo '</tbody></table></div>';
        $none = array_filter($rows, fn($r) => (int)$r->zero > 0);
        if ($none) {
            echo '<div class="ms-card"><h2>Gesucht, aber nichts gefunden <small>(Ideen für neue Artikel)</small></h2><table class="ms-tbl"><thead><tr><th>Suchbegriff</th>' . ($multi ? '<th>Website</th>' : '') . '<th class="num">ohne Treffer</th></tr></thead><tbody>';
            usort($none, fn($a, $b) => (int)$b->zero <=> (int)$a->zero);
            foreach (array_slice($none, 0, 30) as $r) echo '<tr><td><b>' . esc_html($r->label) . '</b></td>' . ($multi ? '<td>' . esc_html($r->site) . '</td>' : '') . '<td class="num">' . (int)$r->zero . '</td></tr>';
            echo '</tbody></table></div>';
        }
        // 404
        $e = $wpdb->get_results("SELECT site, path, label, COUNT(*) n, MAX(ts) lt FROM $t WHERE kind='e404' AND $wn GROUP BY site, path, label ORDER BY n DESC LIMIT 1000");
        $pg = [];
        foreach ($e as $r) { $k = $r->site . $r->path; $pg[$k] ??= ['n' => 0, 'from' => [], 'lt' => '']; $pg[$k]['n'] += (int)$r->n; $pg[$k]['from'][$r->label !== '' ? $r->label : 'direkt / unbekannt'] = (int)$r->n; if ($r->lt > $pg[$k]['lt']) $pg[$k]['lt'] = $r->lt; }
        uasort($pg, fn($a, $b) => $b['n'] <=> $a['n']);
        echo '<div class="ms-card"><h2>404: Seiten, die es nicht gibt <small>(' . array_sum(array_column($pg, 'n')) . ' Aufrufe)</small></h2><table class="ms-tbl"><thead><tr><th>Adresse</th><th class="num">Aufrufe</th><th>meist verlinkt von</th><th>zuletzt</th></tr></thead><tbody>';
        foreach (array_slice($pg, 0, 50, true) as $k => $x) { arsort($x['from']); echo '<tr><td>' . esc_html($k) . '</td><td class="num"><b>' . (int)$x['n'] . '</b></td><td>' . esc_html(array_key_first($x['from'])) . '</td><td>' . esc_html(wp_date('d.m.y H:i', strtotime($x['lt'] . ' UTC'))) . '</td></tr>'; }
        if (!$pg) echo '<tr><td colspan="4">Keine 404-Aufrufe erfasst.</td></tr>';
        echo '</tbody></table><p class="ms-note">Erfasst werden Besucher mit JavaScript; Roboter sind herausgenommen. Steht bei „verlinkt von“ eine fremde Adresse, lohnt sich meist eine Weiterleitung auf die richtige Seite.</p></div>';
        return ob_get_clean();
    }

    static function ref_kind($h) {
        if ($h === '') return 'Direkt / unbekannt';
        if (isset(self::allowed_sites()[preg_replace('/^www\./', '', $h)])) return 'Eigene Seiten (intern)';
        if (preg_match('/chatgpt|openai\.com|perplexity|gemini\.google|bard\.google|(^|\.)claude\.ai$|copilot\.microsoft|copilot\.cloud|(^|\.)you\.com$|(^|\.)poe\.com$|mistral\.ai|deepseek|(^|\.)grok\.com$|(^|\.)x\.ai$|(^|\.)meta\.ai$|kagi\.com|phind\.com/', $h)) return 'KI-Assistenten';
        if (preg_match('/google\.|bing\.|duckduckgo|ecosia|yahoo\.|startpage|qwant|brave\.com|yandex|baidu/', $h)) return 'Suchmaschinen';
        if (preg_match('/facebook|instagram|pinterest|(^|\.)t\.co$|twitter|(^|\.)x\.com$|youtube|reddit|tiktok|whatsapp|linkedin|lnkd|mastodon|telegram/', $h)) return 'Soziale Netze';
        return 'Andere Seiten';
    }

    static function ref_name($h) {
        static $m = ['google' => 'Google', 'bing' => 'Bing', 'duckduckgo' => 'DuckDuckGo', 'ecosia' => 'Ecosia', 'yahoo' => 'Yahoo', 'startpage' => 'Startpage', 'qwant' => 'Qwant', 'brave' => 'Brave Search', 'yandex' => 'Yandex', 'baidu' => 'Baidu', 'facebook' => 'Facebook', 'instagram' => 'Instagram', 'pinterest' => 'Pinterest', 'youtube' => 'YouTube', 'reddit' => 'Reddit', 'tiktok' => 'TikTok', 'whatsapp' => 'WhatsApp', 'linkedin' => 'LinkedIn', 'lnkd' => 'LinkedIn', 'telegram' => 'Telegram', 'chatgpt' => 'ChatGPT', 'openai' => 'ChatGPT', 'perplexity' => 'Perplexity', 'gemini' => 'Gemini', 'claude.ai' => 'Claude', 'copilot' => 'Copilot', 'mistral' => 'Mistral', 'deepseek' => 'DeepSeek', 'kagi' => 'Kagi', 'phind' => 'Phind', 'mastodon' => 'Mastodon', 't.co' => 'X / Twitter', 'twitter' => 'X / Twitter', 'x.com' => 'X / Twitter'];
        if ($h === '') return 'Direkt / unbekannt';
        foreach ($m as $k => $n) if (strpos($h, $k) !== false) return $n;
        return $h;
    }

    // Reiter „Besucher“: Herkunft genau, Browser, System, Bildschirm, Sprache, Zeit, Ladezeit
    // ---------- Qualität: Core Web Vitals, Gewicht, Fehler (alles im Browser des Besuchers gemessen, ohne Cookie) ----------
    static function p75($a) { if (!$a) return null; sort($a); return $a[(int)floor(0.75 * (count($a) - 1))]; }

    static function qual_cell($v, $good, $bad, $fmt) {
        if ($v === null) return '<span class="ms-note">–</span>';
        $c = $v <= $good ? '#00a32a' : ($v <= $bad ? '#d98200' : '#d63638');
        return '<b style="color:' . $c . '">' . esc_html($fmt($v)) . '</b>';
    }

    static function quality_report($w, $multi) {
        global $wpdb;
        $t = self::table();
        $rows = $wpdb->get_results("SELECT day, device, site, path, lc, cl, ip, tt, fc, kb, rq, cn, je, rf FROM $t WHERE kind='time' AND tt > 0 AND $w LIMIT 60000");
        $s_ = fn($v) => number_format_i18n($v / 1000, 1) . ' s'; $ms = fn($v) => number_format_i18n($v) . ' ms';
        $cls_f = fn($v) => number_format_i18n($v / 1000, 2); $kb_f = fn($v) => $v >= 1024 ? number_format_i18n($v / 1024, 1) . ' MB' : number_format_i18n($v) . ' KB';
        ob_start();
        echo '<div class="ms-card"><h2>Qualität der Seiten <small>(im Browser der Besucher gemessen)</small></h2>';
        if (!$rows) { echo '<p class="ms-note">Noch keine Messwerte. Sie kommen mit Besuchern, die mindestens eine Sekunde auf der Seite bleiben (ab Version 0.45).</p></div>'; return ob_get_clean(); }
        $m = ['lc' => [], 'cl' => [], 'ip' => [], 'tt' => [], 'fc' => [], 'kb' => [], 'rq' => []]; $pages = []; $slow = 0; $je = $rf = 0;
        $dm = ['lc' => [], 'cl' => [], 'ip' => [], 'tt' => []]; $dv = [];
        foreach ($rows as $r) {
            $k = $r->site . $r->path; $pages[$k] ??= ['lc' => [], 'cl' => [], 'ip' => [], 'tt' => [], 'kb' => []];
            if ($r->lc > 0) { $m['lc'][] = (int)$r->lc; $pages[$k]['lc'][] = (int)$r->lc; }
            $m['cl'][] = (int)$r->cl; $pages[$k]['cl'][] = (int)$r->cl;
            if ($r->ip > 0) { $m['ip'][] = (int)$r->ip; $pages[$k]['ip'][] = (int)$r->ip; }
            $m['tt'][] = (int)$r->tt; $pages[$k]['tt'][] = (int)$r->tt;
            if ($r->fc > 0) $m['fc'][] = (int)$r->fc;
            if ($r->kb > 0) { $m['kb'][] = (int)$r->kb; $pages[$k]['kb'][] = (int)$r->kb; $m['rq'][] = (int)$r->rq; }
            $dk_ = $r->device ?: '?';
            if ($r->lc > 0) { $dm['lc'][$r->day][] = (int)$r->lc; $dv[$dk_]['lc'][] = (int)$r->lc; }
            $dm['cl'][$r->day][] = (int)$r->cl; $dv[$dk_]['cl'][] = (int)$r->cl;
            if ($r->ip > 0) { $dm['ip'][$r->day][] = (int)$r->ip; $dv[$dk_]['ip'][] = (int)$r->ip; }
            $dm['tt'][$r->day][] = (int)$r->tt; $dv[$dk_]['tt'][] = (int)$r->tt;
            if ($r->cn > 0 && $r->cn < 3) $slow++;
            $je += (int)$r->je; $rf += (int)$r->rf;
        }
        $n = count($rows);
        echo '<div class="ms-kpis">';
        foreach ([
            ['Größtes Element sichtbar (LCP)', self::qual_cell(self::p75($m['lc']), 2500, 4000, $s_), 'gut bis 2,5 s'],
            ['Springende Seite (CLS)', self::qual_cell(self::p75($m['cl']), 100, 250, $cls_f), 'gut bis 0,10'],
            ['Reaktion auf Klick/Tippen (INP)', self::qual_cell(self::p75($m['ip']), 200, 500, $ms), 'gut bis 200 ms'],
            ['Serverantwort (TTFB)', self::qual_cell(self::p75($m['tt']), 800, 1800, $ms), 'gut bis 0,8 s'],
            ['Erstes Zeichen sichtbar (FCP)', self::qual_cell(self::p75($m['fc']), 1800, 3000, $s_), 'gut bis 1,8 s'],
            ['Seitengewicht (übertragen)', self::qual_cell(self::p75($m['kb']), 1500, 4000, $kb_f), 'Ø ' . ($m['rq'] ? number_format_i18n(array_sum($m['rq']) / count($m['rq']), 0) : '–') . ' Anfragen'],
            ['Fehler (JavaScript / Ressourcen)', '<b>' . number_format_i18n($je) . ' / ' . number_format_i18n($rf) . '</b>', 'in ' . number_format_i18n($n) . ' Messungen'],
            ['Langsame Verbindung (2G/3G)', '<b>' . round(100 * $slow / $n) . ' %</b>', 'nur Chrome/Android meldet das'],
        ] as $k) echo '<div class="ms-kpi"><b>' . $k[1] . '</b><span>' . esc_html($k[0]) . '<br>' . esc_html($k[2]) . '</span></div>';
        echo '</div><p class="ms-note">Alle Werte: 75. Prozentwert, also der Wert, den 3 von 4 Besuchern mindestens so gut hatten (so bewertet Google). Grün = gut, orange = verbesserungswürdig, rot = schlecht. Gemessen werden Besucher, die mindestens eine Sekunde bleiben. Nicht jeder Browser liefert alles (INP: Chrome, Edge; LCP/CLS: nicht Safari/Firefox). Es wird nichts im Browser gespeichert und kein Cookie gesetzt, nur Zahlen ohne Personenbezug.</p></div>';
        echo '<div class="ms-card"><h2>Wie viele Besucher erleben die Seite gut? <small>(Anteil je Messwert)</small></h2>'
            . self::ampel('Hauptinhalt sichtbar (LCP)', $m['lc'], 2500, 4000) . self::ampel('Springende Seite (CLS)', $m['cl'], 100, 250) . self::ampel('Reaktion auf Klick (INP)', $m['ip'], 200, 500) . self::ampel('Serverantwort (TTFB)', $m['tt'], 800, 1800) . self::ampel('Erstes Zeichen (FCP)', $m['fc'], 1800, 3000)
            . '<p class="ms-note">Grün = gut, orange = verbesserungswürdig, rot = schlecht, nach Googles Grenzwerten.</p></div>';
        $dn_ = ['mobil' => 'Handy', 'tablet' => 'Tablet', 'desktop' => 'Computer', '?' => 'unbekannt'];
        if (count($dv) > 1 || !isset($dv['?'])) {
            echo '<div class="ms-card"><h2>Handy gegen Computer</h2><table class="ms-tbl"><thead><tr><th>Gerät</th><th class="num">Messungen</th><th class="num">LCP</th><th class="num">CLS</th><th class="num">INP</th><th class="num">TTFB</th></tr></thead><tbody>';
            foreach ($dn_ as $dk => $dl) { if (!isset($dv[$dk])) continue; $x = $dv[$dk]; echo '<tr><td>' . esc_html($dl) . '</td><td class="num">' . count($x['tt']) . '</td><td class="num">' . self::qual_cell(self::p75($x['lc'] ?? []), 2500, 4000, $s_) . '</td><td class="num">' . self::qual_cell(self::p75($x['cl']), 100, 250, $cls_f) . '</td><td class="num">' . self::qual_cell(self::p75($x['ip'] ?? []), 200, 500, $ms) . '</td><td class="num">' . self::qual_cell(self::p75($x['tt']), 800, 1800, $ms) . '</td></tr>'; }
            echo '</tbody></table></div>';
        }
        echo '<div class="ms-grid">';
        self::trend('Verlauf: Hauptinhalt sichtbar (LCP)', $dm['lc'], 2500, 4000, $s_);
        self::trend('Verlauf: Reaktion auf Klick (INP)', $dm['ip'], 200, 500, $ms);
        self::trend('Verlauf: Serverantwort (TTFB)', $dm['tt'], 800, 1800, $ms);
        self::trend('Verlauf: springende Seite (CLS)', $dm['cl'], 100, 250, $cls_f);
        echo '</div>';
        $list = [];
        foreach ($pages as $k => $x) { if (count($x['tt']) < 3) continue; $list[$k] = $x + ['n' => count($x['tt']), 'lcp' => self::p75($x['lc'])]; }
        uasort($list, fn($a, $b) => ($b['lcp'] ?? 0) <=> ($a['lcp'] ?? 0));
        echo '<div class="ms-card"><h2>Seiten nach Ladegeschwindigkeit <small>(mindestens 3 Messungen, schlechteste zuerst)</small></h2><div class="ms-scroll"><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Messungen</th><th class="num">LCP</th><th class="num">CLS</th><th class="num">INP</th><th class="num">TTFB</th><th class="num">Gewicht</th></tr></thead><tbody>';
        foreach (array_slice($list, 0, 30, true) as $k => $x) echo '<tr><td>' . esc_html($k) . '</td><td class="num">' . (int)$x['n'] . '</td><td class="num">' . self::qual_cell($x['lcp'], 2500, 4000, $s_) . '</td><td class="num">' . self::qual_cell(self::p75($x['cl']), 100, 250, $cls_f) . '</td><td class="num">' . self::qual_cell(self::p75($x['ip']), 200, 500, $ms) . '</td><td class="num">' . self::qual_cell(self::p75($x['tt']), 800, 1800, $ms) . '</td><td class="num">' . self::qual_cell(self::p75($x['kb']), 1500, 4000, $kb_f) . '</td></tr>';
        if (!$list) echo '<tr><td colspan="7">Noch zu wenige Messungen je Seite.</td></tr>';
        echo '</tbody></table></div></div>';
        $er = $wpdb->get_results("SELECT via, hr, COUNT(*) n, COUNT(DISTINCT CONCAT(site, path)) p FROM $t WHERE kind='error' AND $w GROUP BY via, hr ORDER BY n DESC LIMIT 25");
        echo '<div class="ms-card"><h2>Fehler auf den Seiten <small>(JavaScript und nicht ladende Dateien)</small></h2><table class="ms-tbl"><thead><tr><th>Art</th><th>Was</th><th class="num">Mal</th><th class="num">Seiten</th></tr></thead><tbody>';
        foreach ($er as $e) echo '<tr><td>' . ($e->via === 'res' ? 'Datei lädt nicht' : 'JavaScript-Fehler') . '</td><td><code>' . esc_html($e->hr) . '</code></td><td class="num"><b>' . (int)$e->n . '</b></td><td class="num">' . (int)$e->p . '</td></tr>';
        if (!$er) echo '<tr><td colspan="4">Keine Fehler gemeldet.</td></tr>';
        echo '</tbody></table><p class="ms-note">Je Besuch werden höchstens 3 Fehler gemeldet, nur die Art, die Datei (ohne Adressanhang) und die Zeile, nie Fehlertexte oder Eingaben.</p></div>';
        return ob_get_clean();
    }

    /** Reiter „Speed“: je Seite/Artikel gemessene Werte mit Hinweisen, dazu Zustand der Seite (PHP, Cache, Cloudflare) */
    static function speed_report($w) {
        global $wpdb;
        $t = self::table();
        $rows = $wpdb->get_results("SELECT site, path, device, lc, tt, fc, kb, rq FROM $t WHERE kind='time' AND tt > 0 AND $w LIMIT 60000");
        $s_ = fn($v) => number_format_i18n($v / 1000, 1) . ' s'; $ms = fn($v) => number_format_i18n($v) . ' ms';
        $kb_f = fn($v) => $v >= 1024 ? number_format_i18n($v / 1024, 1) . ' MB' : number_format_i18n($v) . ' KB';
        ob_start();
        echo '<div class="ms-card"><h2>Speed <small>(wie schnell laden die Seiten bei echten Besuchern)</small></h2>';
        if (!$rows) { echo '<p class="ms-note">Noch keine Messwerte.</p></div>' . (self::$remote === null ? self::system_panel() : '<!--MS_SYS-->'); return ob_get_clean(); }
        $pg = array(); $all = array('lc' => array(), 'tt' => array(), 'kb' => array(), 'rq' => array());
        foreach ($rows as $r) {
            $k = $r->site . $r->path; $pg[$k] ??= array('lc' => array(), 'tt' => array(), 'kb' => array(), 'rq' => array(), 'm' => 0, 'n' => 0);
            $pg[$k]['n']++; if ($r->device === 'mobil') $pg[$k]['m']++;
            $pg[$k]['tt'][] = (int) $r->tt; $all['tt'][] = (int) $r->tt;
            if ($r->lc > 0) { $pg[$k]['lc'][] = (int) $r->lc; $all['lc'][] = (int) $r->lc; }
            if ($r->kb > 0) { $pg[$k]['kb'][] = (int) $r->kb; $pg[$k]['rq'][] = (int) $r->rq; $all['kb'][] = (int) $r->kb; $all['rq'][] = (int) $r->rq; }
        }
        echo '<div class="ms-kpis">';
        foreach (array(
            array('Hauptinhalt sichtbar (LCP)', self::qual_cell(self::p75($all['lc']), 2500, 4000, $s_), 'gut bis 2,5 s'),
            array('Serverantwort (TTFB)', self::qual_cell(self::p75($all['tt']), 800, 1800, $ms), 'gut bis 0,8 s'),
            array('Seitengewicht', self::qual_cell(self::p75($all['kb']), 1500, 4000, $kb_f), 'übertragen'),
            array('Anfragen je Seite', '<b>' . ($all['rq'] ? number_format_i18n(self::p75($all['rq'])) : '–') . '</b>', 'Dateien, die geladen werden'),
        ) as $k) echo '<div class="ms-kpi"><b>' . $k[1] . '</b><span>' . esc_html($k[0]) . '<br>' . esc_html($k[2]) . '</span></div>';
        echo '</div></div>';
        $list = array();
        foreach ($pg as $k => $x) { if ($x['n'] < 3) continue; $list[$k] = $x + array('lcp' => self::p75($x['lc']), 'ttp' => self::p75($x['tt']), 'kbp' => self::p75($x['kb']), 'rqp' => self::p75($x['rq'])); }
        uasort($list, fn($a, $b) => ($b['lcp'] ?? 0) <=> ($a['lcp'] ?? 0));
        echo '<div class="ms-card"><h2>Je Seite und Artikel <small>(mindestens 3 Messungen, langsamste zuerst)</small></h2><div class="ms-scroll"><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Messungen</th><th class="num">LCP</th><th class="num">TTFB</th><th class="num">Gewicht</th><th class="num">Anfragen</th><th>Was hilft</th></tr></thead><tbody>';
        foreach (array_slice($list, 0, 100, true) as $k => $x) {
            $tip = array();
            if ($x['ttp'] !== null && $x['ttp'] > 800) $tip[] = 'Server antwortet langsam: Seiten-Cache prüfen';
            if ($x['kbp'] !== null && $x['kbp'] > 2500) $tip[] = 'Seite ist schwer: Bilder verkleinern (WebP)';
            if ($x['rqp'] !== null && $x['rqp'] > 90) $tip[] = 'Viele Dateien: Skripte, Schriften und Plugins prüfen';
            if ($x['lcp'] !== null && $x['lcp'] > 2500 && !$tip) $tip[] = 'Hauptbild früh laden, nicht verzögern (kein Lazy Load beim ersten Bild)';
            echo '<tr><td>' . esc_html($k) . '</td><td class="num">' . (int) $x['n'] . '</td><td class="num">' . self::qual_cell($x['lcp'], 2500, 4000, $s_) . '</td><td class="num">' . self::qual_cell($x['ttp'], 800, 1800, $ms) . '</td><td class="num">' . self::qual_cell($x['kbp'], 1500, 4000, $kb_f) . '</td><td class="num">' . ($x['rqp'] !== null ? (int) $x['rqp'] : '–') . '</td><td>' . esc_html(implode('; ', $tip) ?: 'gut') . '</td></tr>';
        }
        if (!$list) echo '<tr><td colspan="7">Noch zu wenige Messungen je Seite.</td></tr>';
        echo '</tbody></table></div><p class="ms-note">Alle Werte: 75. Prozentwert (so bewertet Google). Die Hinweise sind Faustregeln, keine Garantie.</p></div>';
        echo self::$remote === null ? self::system_panel() : '<!--MS_SYS-->';
        return ob_get_clean();
    }

    /** Zustand dieser Seite, der die Geschwindigkeit beeinflusst (nur diese Seite wird einmal je 6 Stunden angefragt, nichts wird gesendet) */
    static function system_panel() {
        $hd = get_transient('ms_sys_head');
        if ($hd === false) {
            $r = wp_remote_get(home_url('/'), array('timeout' => 8, 'redirection' => 3, 'headers' => array('Accept-Encoding' => 'gzip, br'), 'user-agent' => 'mini-statistik-check'));
            $hd = array('ok' => 0);
            if (!is_wp_error($r)) {
                $h = wp_remote_retrieve_headers($r); $g = function ($k) use ($h) { return isset($h[$k]) ? (string) (is_array($h[$k]) ? $h[$k][0] : $h[$k]) : ''; };
                $hd = array('ok' => 1, 'cf' => $g('cf-ray') !== '' || stripos($g('server'), 'cloudflare') !== false, 'cfc' => $g('cf-cache-status'), 'enc' => $g('content-encoding'), 'cc' => $g('cache-control'), 'srv' => $g('server'), 'len' => strlen((string) wp_remote_retrieve_body($r)));
            }
            set_transient('ms_sys_head', $hd, 6 * HOUR_IN_SECONDS);
        }
        $php = PHP_VERSION; $pv = version_compare($php, '8.2', '>=');
        $act = (array) get_option('active_plugins', array()); $np = count($act);
        $oc = function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache();
        $pc = (defined('WP_CACHE') && WP_CACHE) || file_exists(WP_CONTENT_DIR . '/advanced-cache.php');
        $mem = (string) ini_get('memory_limit');
        $ok = '<b style="color:#00a32a">gut</b>'; $mid = '<b style="color:#d98200">prüfen</b>'; $bad = '<b style="color:#c0392b">verbessern</b>';
        $z = array();
        $z[] = array('PHP-Version', esc_html($php), $pv ? $ok : $mid, $pv ? '' : 'Neuere PHP-Version (8.2 oder höher) im Hosting einstellen, das macht den Server spürbar schneller.');
        $z[] = array('Seiten-Cache', $pc ? 'aktiv (Cache-Plugin erkannt)' : 'nicht erkannt', $pc ? $ok : $bad, $pc ? '' : 'Ohne Seiten-Cache baut der Server jede Seite neu. Ein Cache-Plugin oder der Cache des Hosters bringt oft den größten Gewinn.');
        $z[] = array('Objekt-Cache', $oc ? 'aktiv' : 'nein', $oc ? $ok : $mid, $oc ? '' : 'Nur bei großem Datenbankaufwand nötig, bei kleinen Seiten meist nicht.');
        $z[] = array('Aktive Plugins', (string) $np, $np <= 20 ? $ok : $mid, $np <= 20 ? '' : 'Viele Plugins bremsen. Nicht benötigte deaktivieren und löschen.');
        $z[] = array('Speicher-Limit', esc_html($mem), '', '');
        if (!empty($hd['ok'])) {
            $z[] = array('Cloudflare', $hd['cf'] ? 'ja' . ($hd['cfc'] ? ' (Cache-Status: ' . esc_html($hd['cfc']) . ')' : '') : 'nein / nicht erkennbar', $hd['cf'] ? ($hd['cfc'] === 'HIT' ? $ok : $mid) : $mid, $hd['cf'] ? ($hd['cfc'] === 'HIT' ? '' : 'Cloudflare liefert die HTML-Seite nicht aus dem eigenen Cache (Status ' . ($hd['cfc'] ?: 'unbekannt') . '). Mit einer Cache-Regel für Seiten ohne Anmeldung wird das schneller.') : 'Ein CDN wie Cloudflare liefert Dateien näher beim Besucher aus.');
            $z[] = array('Komprimierung', $hd['enc'] ? esc_html($hd['enc']) : 'keine erkannt', $hd['enc'] ? $ok : $bad, $hd['enc'] ? '' : 'Gzip oder Brotli einschalten, die Übertragung wird deutlich kleiner.');
            $z[] = array('Cache-Hinweis der Startseite', esc_html($hd['cc'] ?: 'keiner'), '', '');
        } else $z[] = array('Abruf der Startseite', 'nicht möglich', $mid, 'Cloudflare und Komprimierung konnten nicht geprüft werden.');
        $h = '<div class="ms-card"><h2>Zustand dieser Seite <small>(Einflüsse auf die Geschwindigkeit)</small></h2><table class="ms-tbl"><thead><tr><th>Punkt</th><th>Stand</th><th>Urteil</th><th>Tipp</th></tr></thead><tbody>';
        foreach ($z as $r) $h .= '<tr><td>' . esc_html($r[0]) . '</td><td>' . $r[1] . '</td><td>' . $r[2] . '</td><td>' . esc_html($r[3]) . '</td></tr>';
        return $h . '</tbody></table><p class="ms-note">Geprüft wird nur die eigene Startseite, höchstens alle 6 Stunden. Es wird nichts an Dritte gesendet.</p></div>';
    }

    // ---------- Grafik-Bausteine (reines SVG/CSS, ohne Bibliothek) ----------
    static function donut($title, $rows, $note = '') {
        $pal = ['#2271b1', '#d98200', '#00a32a', '#8c5bd6', '#c0392b', '#1d9aa6', '#787c82', '#e05d9a'];
        $tot = 0; foreach ($rows as $r) $tot += (int)$r[1];
        echo '<div class="ms-card"><h2>' . esc_html($title) . '</h2>';
        if ($tot < 1) { echo '<p class="ms-note">Noch keine Daten.</p></div>'; return; }
        $c = 2 * M_PI * 40; $off = 0;
        echo '<div class="ms-dn"><svg viewBox="0 0 100 100" width="130" height="130" role="img" aria-label="' . esc_attr($title) . '"><g transform="rotate(-90 50 50)">';
        foreach ($rows as $i => $r) { $len = $c * $r[1] / $tot; echo '<circle cx="50" cy="50" r="40" fill="none" stroke="' . $pal[$i % 8] . '" stroke-width="16" stroke-dasharray="' . round($len, 2) . ' ' . round($c - $len, 2) . '" stroke-dashoffset="' . round(-$off, 2) . '"><title>' . esc_attr($r[0]) . ': ' . round(100 * $r[1] / $tot) . ' %</title></circle>'; $off += $len; }
        echo '</g></svg><ul class="ms-lg">';
        foreach ($rows as $i => $r) echo '<li><i style="background:' . $pal[$i % 8] . '"></i><span>' . esc_html($r[0]) . '</span><b>' . round(100 * $r[1] / $tot) . ' %</b></li>';
        echo '</ul></div>' . ($note ? '<p class="ms-note">' . esc_html($note) . '</p>' : '') . '</div>';
    }

    // Ampelbalken: Anteil gut / verbesserungswürdig / schlecht
    static function ampel($label, $vals, $good, $bad) {
        $n = count($vals); if (!$n) return '';
        $g = $m = $b = 0; foreach ($vals as $v) { if ($v <= $good) $g++; elseif ($v <= $bad) $m++; else $b++; }
        $pg = round(100 * $g / $n); $pb = round(100 * $b / $n); $pm = max(0, 100 - $pg - $pb);
        return '<div class="ms-amp"><span class="n">' . esc_html($label) . '</span><div class="ms-st" title="gut ' . $pg . ' %, verbesserungswürdig ' . $pm . ' %, schlecht ' . $pb . ' %"><i style="width:' . $pg . '%;background:#00a32a"></i><i style="width:' . $pm . '%;background:#d98200"></i><i style="width:' . $pb . '%;background:#c0392b"></i></div><span class="v">' . $pg . ' % gut</span></div>';
    }

    // Verlauf je Tag (75. Prozentwert), Säulen in Ampelfarbe
    static function trend($title, $byday, $good, $bad, $fmt) {
        ksort($byday); $byday = array_slice($byday, -30, 30, true);
        echo '<div class="ms-card"><h2>' . esc_html($title) . '</h2>';
        if (count($byday) < 2) { echo '<p class="ms-note">Für einen Verlauf braucht es Messwerte von mindestens zwei Tagen.</p></div>'; return; }
        $pv = []; foreach ($byday as $d => $a) $pv[$d] = self::p75($a);
        $mx = max(max($pv), $bad * 1.1, 1); $n = count($pv); $bw = 440 / $n; $i = 0;
        $yg = 100 - round(90 * $good / $mx); $yb = 100 - round(90 * $bad / $mx);
        echo '<svg viewBox="0 0 480 130" width="100%" role="img" aria-label="' . esc_attr($title) . '"><line x1="0" x2="470" y1="' . $yg . '" y2="' . $yg . '" stroke="#00a32a" stroke-dasharray="3 3" opacity=".6"/><line x1="0" x2="470" y1="' . $yb . '" y2="' . $yb . '" stroke="#c0392b" stroke-dasharray="3 3" opacity=".6"/>';
        foreach ($pv as $d => $v) {
            $h = max(1, round(90 * $v / $mx)); $col = $v <= $good ? '#00a32a' : ($v <= $bad ? '#d98200' : '#c0392b');
            echo '<rect x="' . round($i * $bw + 1, 1) . '" y="' . (100 - $h) . '" width="' . max(2, round($bw - 2, 1)) . '" height="' . $h . '" rx="2" fill="' . $col . '"><title>' . esc_attr($d . ': ' . $fmt($v)) . '</title></rect>';
            if ($i === 0 || $i === $n - 1 || $i === (int)($n / 2)) echo '<text x="' . round($i * $bw + $bw / 2, 1) . '" y="118" font-size="10" text-anchor="' . ($i === 0 ? 'start' : ($i === $n - 1 ? 'end' : 'middle')) . '" fill="#646970">' . esc_html(substr($d, 5)) . '</text>';
            $i++;
        }
        echo '</svg><p class="ms-note">Gestrichelt: grün = gut, rot = schlecht. Jeder Balken ist ein Tag.</p></div>';
    }

    // Reiter „Browser & Verhalten“: grobe Besucherdaten und Verhalten als Grafiken
    static function browser_report($w) {
        global $wpdb; $t = self::table();
        $grp = function ($col, $nm = null, $lim = 7) use ($wpdb, $t, $w) {
            $o = [];
            foreach ($wpdb->get_results("SELECT $col a, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY $col ORDER BY n DESC LIMIT 60") as $r) { $k = $nm ? $nm($r->a) : ($r->a !== '' ? $r->a : 'unbekannt'); $o[$k] = ($o[$k] ?? 0) + (int)$r->n; }
            arsort($o); $rest = array_slice($o, $lim, null, true); $o = array_slice($o, 0, $lim, true);
            if ($rest) $o['sonstige'] = array_sum($rest);
            $r2 = []; foreach ($o as $k => $v) $r2[] = [$k, $v]; return $r2;
        };
        ob_start();
        echo '<style>.ms-dn{display:flex;gap:18px;align-items:center;flex-wrap:wrap}.ms-lg{list-style:none;margin:0;padding:0;flex:1;min-width:150px}.ms-lg li{display:flex;gap:8px;align-items:center;font-size:13px;margin:3px 0}.ms-lg i{width:10px;height:10px;border-radius:3px;flex:none}.ms-lg span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ms-amp{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,3fr) 80px;gap:8px;align-items:center;margin:7px 0;font-size:13px}.ms-st{display:flex;height:14px;border-radius:7px;overflow:hidden;background:#f0f0f1}.ms-st i{display:block;height:100%}.ms-amp .v{text-align:right;font-variant-numeric:tabular-nums}</style>';
        echo '<h2 style="margin:16px 0 0">Wer kommt? <small style="font-weight:400;color:#646970">(grobe Klassen, nie die volle Kennung)</small></h2><div class="ms-grid">';
        self::donut('Gerät', $grp('device', fn($a) => ['mobil' => 'Handy', 'tablet' => 'Tablet', 'desktop' => 'Computer'][$a] ?? 'unbekannt'));
        self::donut('Browser', $grp('br'));
        self::donut('Betriebssystem', $grp('os'));
        $wbn = [0 => 'unbekannt', 1 => 'unter 400 px', 2 => '400–599 px', 3 => '600–767 px', 4 => '768–1023 px', 5 => '1024–1279 px', 6 => '1280–1535 px', 7 => '1536 px +'];
        self::donut('Bildschirmklasse', $grp('wb', fn($a) => $wbn[(int)$a] ?? 'unbekannt'));
        self::donut('Sprache des Browsers', $grp('lg', fn($a) => $a === '' ? 'unbekannt' : (['de' => 'Deutsch', 'en' => 'Englisch', 'fr' => 'Französisch', 'es' => 'Spanisch', 'it' => 'Italienisch', 'nl' => 'Niederländisch', 'pt' => 'Portugiesisch', 'pl' => 'Polnisch', 'ru' => 'Russisch', 'tr' => 'Türkisch'][$a] ?? $a)));
        $cn = $wpdb->get_results("SELECT cn a, COUNT(*) n FROM $t WHERE kind='time' AND cn>0 AND $w GROUP BY cn");
        $cm = [1 => 'sehr langsam (2G)', 2 => 'langsam (3G)', 3 => 'schnell (4G und mehr)']; $cr = []; foreach ($cn as $r) $cr[(int)$r->a] = (int)$r->n; krsort($cr); $rows = []; foreach ($cr as $k => $v) $rows[] = [$cm[$k] ?? '?', $v];
        self::donut('Verbindung', $rows, 'Nur Chrome und Android melden die Verbindungsart.');
        echo '</div>';
        // Darstellung (Bitfeld pf)
        $pf = $wpdb->get_results("SELECT pf, device, COUNT(*) n FROM $t WHERE kind='time' AND tt>0 AND $w GROUP BY pf, device");
        $tot = 0; $bit = [1 => 0, 2 => 0, 4 => 0, 8 => 0, 16 => 0]; $mob = 0; $mland = 0;
        foreach ($pf as $r) { $n = (int)$r->n; $tot += $n; foreach ($bit as $b => $_) if (((int)$r->pf) & $b) $bit[$b] += $n; if ($r->device !== 'desktop') { $mob += $n; if (((int)$r->pf) & 4) $mland += $n; } }
        echo '<div class="ms-card"><h2>Darstellung <small>(Anteil der Besucher mit …)</small></h2>';
        if ($tot < 1) echo '<p class="ms-note">Noch keine Daten (ab Version 0.46).</p>';
        else {
            $lab = [1 => 'Dunkelmodus', 2 => 'Retina-/Hochauflösungs-Bildschirm', 4 => 'Querformat (Fenster breiter als hoch)', 8 => 'Wunsch „weniger Bewegung“', 16 => 'Datensparmodus'];
            foreach ($lab as $b => $l) { $pc = round(100 * $bit[$b] / $tot); echo '<div class="ms-row"><span class="n">' . esc_html($l) . '</span><div class="ms-bar"><i style="width:' . $pc . '%"></i></div><span class="v">' . $pc . '%</span></div>'; }
            if ($mob) echo '<p class="ms-note">Auf Handy und Tablet im Querformat: ' . round(100 * $mland / $mob) . ' %.</p>';
        }
        echo '</div>';
        // Verhalten
        $tm = $wpdb->get_results("SELECT secs, scroll FROM $t WHERE kind='time' AND $w LIMIT 60000");
        echo '<h2 style="margin:24px 0 0">Was machen sie? <small style="font-weight:400;color:#646970">(Verhalten auf den Seiten)</small></h2><div class="ms-grid">';
        $sb = ['unter 25 %' => 0, '25–49 %' => 0, '50–74 %' => 0, '75–100 %' => 0]; $tb = ['unter 10 s' => 0, '10–29 s' => 0, '30–59 s' => 0, '1–3 Minuten' => 0, 'über 3 Minuten' => 0];
        foreach ($tm as $r) { $g = (int)$r->scroll; $sb[$g < 25 ? 'unter 25 %' : ($g < 50 ? '25–49 %' : ($g < 75 ? '50–74 %' : '75–100 %'))]++; $x = (int)$r->secs; $tb[$x < 10 ? 'unter 10 s' : ($x < 30 ? '10–29 s' : ($x < 60 ? '30–59 s' : ($x <= 180 ? '1–3 Minuten' : 'über 3 Minuten')))]++; }
        $mk = function ($a) { $r = []; foreach ($a as $k => $v) $r[] = [$k, $v]; return $r; };
        self::donut('Wie weit wird gescrollt?', $mk($sb), 'Anteil der Seitenaufrufe nach größter Scrolltiefe.');
        self::donut('Aktive Lesezeit je Aufruf', $mk($tb), 'Nur Zeit, in der die Seite sichtbar und bedient wird.');
        $vw = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE kind='view' AND $w");
        $ck = $wpdb->get_results("SELECT target, COUNT(*) n FROM $t WHERE kind='click' AND $w GROUP BY target"); $aff = 0; $ext = 0;
        foreach ($ck as $r) { $pp = self::partner($r->target); if ($pp === 'Amazon' || $pp === 'eBay') $aff += (int)$r->n; else $ext += (int)$r->n; }
        $one = (int)$wpdb->get_var("SELECT COUNT(*) FROM (SELECT 1 FROM $t WHERE kind='view' AND $w GROUP BY site, visitor, day HAVING COUNT(*)=1) x"); $all = (int)$wpdb->get_var("SELECT COUNT(*) FROM (SELECT 1 FROM $t WHERE kind='view' AND $w GROUP BY site, visitor, day) x");
        $sr = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE kind='srch' AND $w");
        echo '<div class="ms-card"><h2>Kennzahlen</h2><div class="ms-kpis">';
        foreach ([
            [$vw ? number_format_i18n(100 * $aff / $vw, 1) . ' %' : '–', 'Aufrufe mit Klick auf Amazon/eBay', number_format_i18n($aff) . ' Klicks'],
            [$vw ? number_format_i18n(100 * $ext / $vw, 1) . ' %' : '–', 'Aufrufe mit Klick auf andere externe Links', number_format_i18n($ext) . ' Klicks'],
            [$all ? round(100 * $one / $all) . ' %' : '–', 'Besuche mit nur einer Seite', 'pro Besucher und Tag'],
            [number_format_i18n($sr), 'Suchen auf der Seite', $vw ? number_format_i18n(100 * $sr / $vw, 1) . ' % der Aufrufe' : ''],
        ] as $k) echo '<div class="ms-kpi"><b>' . $k[0] . '</b><span>' . esc_html($k[1]) . '<br>' . esc_html($k[2]) . '</span></div>';
        echo '</div></div></div>';
        echo '<p class="ms-note">Alle Angaben sind grobe Klassen ohne Personenbezug: kein Cookie, keine Speicherung im Browser, keine IP, keine genaue Browserversion, keine Schriftarten- oder Hardware-Liste (kein „Fingerprinting“).</p>';
        return ob_get_clean();
    }

    // ---------- Gesamtstatus (Ampel) und Status-Mail ----------
    const ST_NAME = [0 => 'grau', 1 => 'grün', 2 => 'orange', 3 => 'rot'];

    /** Status der letzten 7 Tage über alle Seiten: [Stufe 0 grau/1 grün/2 orange/3 rot, Gründe[], Messungen] */
    const TIP = [
        'lc' => 'Größtes Bild oder Element verkleinern, Seiten-Cache prüfen, bei Bildern oben auf der Seite kein „Lazy Loading“.',
        'cl' => 'Bildern feste Breite und Höhe geben, nachladenden Boxen und Anzeigen vorab Platz reservieren.',
        'ip' => 'Schwere Skripte oder Plugins suchen: zuletzt aktualisierte Plugins nacheinander testweise abschalten.',
        'tt' => 'Server und Zwischenspeicher prüfen: Seiten-Cache einschalten, Hosting oder Plugins prüfen, die jede Seite langsam aufbauen.',
        'js' => 'Der Dateiname in der Meldung zeigt, welches Plugin oder Theme betroffen ist: dort auf ein Update prüfen oder testweise abschalten.',
        'rf' => 'Bild oder Datei fehlt: Link korrigieren oder ersetzen (zum Beispiel alte Produktbilder), danach Seiten-Cache leeren.',
        'stille' => 'Seite erreichbar? Zählskript noch eingebunden (Theme gewechselt, Cache geleert, Zählung ausgeschaltet)? Zugangsdaten der Seite in den Einstellungen prüfen.',
    ];

    static function status_calc($site = null, $days = 7) {
        global $wpdb; $t = self::table();
        $days = max(1, min(30, (int)$days));
        $from = gmdate('Y-m-d', time() - ($days - 1) * 86400);
        $sq = $site ? $wpdb->prepare(' AND site = %s', $site) : '';
        $rows = $wpdb->get_results($wpdb->prepare("SELECT lc, cl, ip, tt FROM $t WHERE kind='time' AND tt > 0 AND day >= %s", $from) . $sq . ' LIMIT 60000');
        $n = count($rows); $lvl = 1; $why = [];
        $up = function ($l, $txt, $tip = '') use (&$lvl, &$why) { $lvl = max($lvl, $l); $why[] = [$l, $txt, $tip]; };
        if ($n >= 10) {
            $m = ['lc' => [], 'cl' => [], 'ip' => [], 'tt' => []];
            foreach ($rows as $r) { if ($r->lc > 0) $m['lc'][] = (int)$r->lc; $m['cl'][] = (int)$r->cl; if ($r->ip > 0) $m['ip'][] = (int)$r->ip; $m['tt'][] = (int)$r->tt; }
            foreach ([['lc', 'Hauptinhalt sichtbar (LCP)', 2500, 4000, fn($v) => number_format_i18n($v / 1000, 1) . ' s'], ['cl', 'Springende Seite (CLS)', 100, 250, fn($v) => number_format_i18n($v / 1000, 2)], ['ip', 'Reaktion auf Klick (INP)', 200, 500, fn($v) => number_format_i18n($v) . ' ms'], ['tt', 'Serverantwort (TTFB)', 800, 1800, fn($v) => number_format_i18n($v) . ' ms']] as $d) {
                if (count($m[$d[0]]) < 10) continue; $v = self::p75($m[$d[0]]);
                if ($v > $d[3]) $up(3, $d[1] . ' schlecht: ' . $d[4]($v) . ' (75. Prozentwert)', self::TIP[$d[0]]); elseif ($v > $d[2]) $up(2, $d[1] . ' verbesserungswürdig: ' . $d[4]($v), self::TIP[$d[0]]);
            }
        }
        $er = $wpdb->get_results($wpdb->prepare("SELECT site, via, hr, COUNT(*) n FROM $t WHERE kind='error' AND day >= %s", $from) . $sq . ' GROUP BY site, via, hr ORDER BY n DESC LIMIT 200');
        $js = $rf = 0; $topjs = null; $toprf = null;
        foreach ($er as $e) { if ($e->via === 'res') { $rf += (int)$e->n; $toprf = $toprf ?: $e; } else { $js += (int)$e->n; $topjs = $topjs ?: $e; } }
        if ($js) { $share = $n ? 100 * $js / $n : 100; $up($js >= 5 && $share >= 5 ? 3 : 2, number_format_i18n($js) . ' JavaScript-Fehler in ' . $days . ' Tagen, häufigster auf ' . $topjs->site . ': ' . $topjs->hr . ' (' . (int)$topjs->n . ' mal)', self::TIP['js']); }
        if ($rf) $up($rf >= 20 ? 3 : 2, number_format_i18n($rf) . ' Dateien laden nicht (Bilder, Skripte), häufigste auf ' . $toprf->site . ': ' . $toprf->hr . ' (' . (int)$toprf->n . ' mal)', self::TIP['rf']);
        if ($n < 10 && !$er) return [0, [[0, 'Noch zu wenige Messwerte (' . $n . ' in ' . $days . ' Tagen).']], $n];
        if ($lvl === 1) $why[] = [1, 'Keine Fehler gemeldet, Ladewerte im grünen Bereich (' . number_format_i18n($n) . ' Messungen in ' . $days . ' Tagen).'];
        usort($why, fn($a, $b) => $b[0] <=> $a[0]);
        return [$lvl, $why, $n];
    }

    static function status_banner($site = null) {
        if (self::opts()['mode'] !== 'hub') return '';
        [$l, $why, $n] = self::status_calc($site);
        $col = [0 => '#787c82', 1 => '#00a32a', 2 => '#d98200', 3 => '#c0392b'][$l];
        $head = [0 => 'Status: noch keine Aussage', 1 => 'Status: alles in Ordnung', 2 => 'Status: Achtung, es gibt Hinweise', 3 => 'Status: Problem'][$l];
        $o = '<div class="ms-card" style="border-left:6px solid ' . $col . '"><h2 style="margin:0 0 6px"><span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:' . $col . ';margin-right:8px"></span>' . esc_html($head) . ' <small>(letzte 7 Tage, ' . ($site ? esc_html($site) : 'alle Seiten') . ')</small></h2><ul style="margin:6px 0 0 18px;list-style:disc">';
        foreach (array_slice($why, 0, 4) as $w) $o .= '<li>' . esc_html($w[1]) . '</li>';
        $o .= '</ul>';
        $tips = []; foreach ($why as $w) if ($w[0] >= 2 && !empty($w[2])) $tips[$w[2]] = 1;
        if ($tips) { $o .= '<p style="margin:10px 0 0"><b>Was jetzt tun?</b></p><ul style="margin:4px 0 0 18px;list-style:disc">'; foreach (array_slice(array_keys($tips), 0, 4) as $tp) $o .= '<li>' . esc_html($tp) . '</li>'; $o .= '</ul>'; }
        $o .= '' . ($l >= 2 ? '<p style="margin:8px 0 0"><a href="#ms-t-q" onclick="var b=document.querySelector(\'.ms-tabs a[data-t=q]\');if(b){b.click();return false}">Details im Reiter „Qualität“</a></p>' : '') . '</div>';
        return $o;
    }

    static function mail_empf() { $o = self::opts(); return $o['mail_to'] !== '' ? $o['mail_to'] : (string)get_option('admin_email'); }

    static function status_send($st, $test = false) {
        [$l, $why] = $st;
        $site = wp_parse_url(home_url(), PHP_URL_HOST);
        $b = ($test ? "Das ist eine Testmail der 1AB-Test-Statistik.\n\n" : '') . 'Status: ' . strtoupper(self::ST_NAME[$l]) . " (letzte 7 Tage, alle Seiten)\n\n";
        foreach ($why as $w) $b .= '- ' . $w[1] . "\n";
        $tips = []; foreach ($why as $w) if ($w[0] >= 2 && !empty($w[2])) $tips[$w[2]] = 1;
        if ($tips) { $b .= "\nWas jetzt tun?\n"; foreach (array_slice(array_keys($tips), 0, 4) as $tp) $b .= '- ' . $tp . "\n"; }
        $b .= "\nDetails: " . admin_url('admin.php?page=mini-statistik') . "  (Reiter Qualität)\n\nDiese Mail kommt höchstens einmal am Tag und nur, wenn der Status schlechter wird. Abschalten: Einstellungen der 1AB-Test-Statistik.\n";
        return (bool)wp_mail(self::mail_empf(), '[' . $site . '] Statistik-Status: ' . self::ST_NAME[$l], $b);
    }

    static function status_mail() {
        $o = self::opts();
        if ($o['mode'] !== 'hub' || empty($o['mail_status'])) return;
        $st = self::status_calc(); $l = $st[0]; if ($l === 0) return;
        $last = (array)get_option('ms_status_last', ['l' => 1, 'ts' => 0]);
        update_option('ms_status_last', ['l' => $l, 'ts' => (int)($l > (int)$last['l'] ? time() : $last['ts'])], false);
        if ($l >= 2 && $l > (int)$last['l'] && time() - (int)$last['ts'] > 20 * 3600) self::status_send($st);
    }

    // ---------- Eigene Auswertung auf jeder Seite: Bericht kommt fertig von der Zentrale ----------
    const REMOTE_BASE = 'https://ms.invalid/admin.php?page=mini-statistik';
    static $remote = null; // gesetzt (Seitenname), während die Zentrale einen Bericht für eine Sende-Seite erzeugt

    /** Zentrale: liefert den fertigen Bericht nur für die anfragende Seite (Seitenschlüssel nötig, 60 Sekunden zwischengespeichert) */
    static function bericht(WP_REST_Request $req) {
        $none = new WP_REST_Response(null, 204);
        if (self::opts()['mode'] !== 'hub') return $none;
        $d = json_decode($req->get_body(), true);
        if (!is_array($d)) return $none;
        $site = preg_replace('/^www\./', '', strtolower((string)($d['s'] ?? '')));
        $sites = self::allowed_sites();
        if (!isset($sites[$site]) || !hash_equals($sites[$site], (string)($d['k'] ?? ''))) return new WP_REST_Response(null, 403);
        $q = [];
        foreach (['tage', 'von', 'bis', 'bots', 'f_src', 'f_dev', 'f_br', 'f_os', 'f_lg', 'f_cc'] as $k) if (isset($d['q'][$k]) && is_scalar($d['q'][$k])) $q[$k] = substr((string)$d['q'][$k], 0, 60);
        $q['seite'] = $site;
        $ck = 'ms_rb_' . md5($site . '|' . self::VERSION . '|' . json_encode($q));
        $html = get_transient($ck);
        if ($html === false) {
            $bak = $_GET; $_GET = $q; self::$remote = $site;
            ob_start();
            try { self::report(); $html = ob_get_clean(); } catch (\Throwable $e) { ob_end_clean(); $html = ''; }
            self::$remote = null; $_GET = $bak;
            $html = preg_replace('~<form method="get" style="display:inline">.*?</form>~s', '', $html); // Seitenauswahl entfällt: die Seite sieht nur sich selbst
            $html = preg_replace('~<form method="post".*?</form>~s', '', $html); // keine Schreib-Formulare (z. B. Produkte ausblenden) in der Fernansicht
            if ($html !== '') set_transient($ck, $html, 60);
        }
        return new WP_REST_Response(['v' => self::VERSION, 'html' => $html], 200);
    }

    /** Sende-Seite: holt und zeigt den eigenen Bericht */
    static function remote_report() {
        $o = self::opts();
        if ($o['hub_url'] === '' || $o['site_key'] === '') return '<div class="notice notice-warning inline"><p>Bitte in den Einstellungen die Adresse der Zentrale und das Kennwort dieser Seite eintragen.</p></div>';
        $q = [];
        foreach (['tage', 'von', 'bis', 'bots', 'f_src', 'f_dev', 'f_br', 'f_os', 'f_lg', 'f_cc'] as $k) if (isset($_GET[$k]) && is_scalar($_GET[$k])) $q[$k] = sanitize_text_field(wp_unslash((string)$_GET[$k]));
        $site = preg_replace('/^www\./', '', strtolower((string)wp_parse_url(home_url(), PHP_URL_HOST)));
        $r = wp_remote_post(trailingslashit($o['hub_url']) . '?rest_route=/mini-statistik/v1/bericht', ['timeout' => 20, 'headers' => ['Content-Type' => 'application/json'], 'body' => wp_json_encode(['s' => $site, 'k' => $o['site_key'], 'q' => $q])]);
        if (is_wp_error($r) || (int)wp_remote_retrieve_response_code($r) !== 200) return '<div class="notice notice-error inline"><p>Die Zentrale ist gerade nicht erreichbar oder das Kennwort stimmt nicht (Antwort ' . esc_html(is_wp_error($r) ? 'keine' : (string)wp_remote_retrieve_response_code($r)) . '). Die Daten liegen sicher bei der Zentrale, später noch einmal versuchen.</p></div>';
        $j = json_decode(wp_remote_retrieve_body($r), true);
        $html = is_array($j) ? (string)($j['html'] ?? '') : '';
        if ($html === '') return '<div class="notice notice-info inline"><p>Noch keine Daten für diese Seite.</p></div>';
        return str_replace(array(self::REMOTE_BASE, '<!--MS_SYS-->'), array(admin_url('admin.php?page=mini-statistik'), self::system_panel()), $html) . '<p class="ms-note">Diese Auswertung kommt live von der Zentrale (höchstens 1 Minute alt), hier wird nichts gespeichert.</p>';
    }

    static function admin_leiste($bar) {
        if (!current_user_can('manage_options') || self::opts()['mode'] === 'off') return;
        $bar->add_node(['id' => 'ms-statistik', 'title' => '<span class="ab-icon dashicons dashicons-chart-bar" style="font:normal 20px/1 dashicons;margin-top:2px"></span> <span class="ab-label">Statistik</span>', 'href' => admin_url('admin.php?page=mini-statistik'), 'meta' => ['title' => '1AB-Test-Statistik']]);
    }

    /** Seiten ohne Messwerte seit längerem (Erreichbarkeit/Zählskript): nur Seiten, die in den letzten 7 Tagen Daten hatten */
    static function status_stille() {
        global $wpdb; $t = self::table(); $out = [];
        foreach ($wpdb->get_results("SELECT site, MAX(ts) lt, COUNT(*) n FROM $t WHERE kind='view' AND ts >= '" . gmdate('Y-m-d H:i:s', time() - 7 * 86400) . "' GROUP BY site") as $r) {
            $h = (time() - strtotime($r->lt . ' UTC')) / 3600;
            if ((int)$r->n >= 30 && $h >= 8) $out[] = [3, 'Keine Aufrufe von ' . $r->site . ' seit ' . (int)round($h) . ' Stunden (sonst regelmäßig Daten).', self::TIP['stille']];
        }
        return $out;
    }

    /** Stündlich: Sofortwarnung bei rot (letzte 24 Stunden, mindestens 20 Messungen für Messwerte) oder fehlenden Daten; je gleichem Grund höchstens alle 24 Stunden */
    static function alarm() {
        $o = self::opts();
        if ($o['mode'] !== 'hub' || empty($o['mail_alarm'])) return;
        $st = self::status_calc(null, 1);
        $why = array_values(array_filter($st[1], fn($w) => $w[0] === 3));
        if ($st[2] < 20) $why = array_values(array_filter($why, fn($w) => !preg_match('/\((LCP|CLS|INP|TTFB)\)/', $w[1])));
        $why = array_merge($why, self::status_stille());
        if (!$why) return;
        $sent = (array)get_option('ms_alarm_sent', []); $neu = [];
        foreach ($why as $w) { $h = md5(preg_replace('/\d+/', '#', $w[1])); if (empty($sent[$h]) || time() - (int)$sent[$h] > 86400) $neu[$h] = $w; }
        if (!$neu) return;
        foreach ($neu as $h => $w) $sent[$h] = time();
        foreach ($sent as $h => $ts) if (time() - (int)$ts > 7 * 86400) unset($sent[$h]);
        update_option('ms_alarm_sent', $sent, false);
        $site = wp_parse_url(home_url(), PHP_URL_HOST);
        $b = "Sofortwarnung der 1AB-Test-Statistik:\n\n";
        foreach ($neu as $w) $b .= '- ' . $w[1] . "\n";
        $tips = []; foreach ($neu as $w) if (!empty($w[2])) $tips[$w[2]] = 1;
        if ($tips) { $b .= "\nWas jetzt tun?\n"; foreach (array_slice(array_keys($tips), 0, 4) as $tp) $b .= '- ' . $tp . "\n"; }
        $b .= "\nDetails: " . admin_url('admin.php?page=mini-statistik') . "\n\nDiese Warnung kommt je Grund höchstens einmal in 24 Stunden. Abschalten: Einstellungen der 1AB-Test-Statistik.\n";
        wp_mail(self::mail_empf(), '[' . $site . '] Statistik-Warnung', $b);
    }

    /** Datenschutz-Textbaustein zum Kopieren (Vorschlag, keine Rechtsberatung) */
    static function datenschutz_text() {
        $o = self::opts();
        $keep = (int)$o['keep_days'] > 0 ? 'Die Einzeldaten werden nach ' . (int)$o['keep_days'] . ' Tagen gelöscht.' : 'Die Einzeldaten werden zur langfristigen Auswertung gespeichert, solange sie dafür gebraucht werden.';
        $z = (int)$o['salt_days'];
        return "Reichweitenmessung und Seitenqualität (1AB-Test-Statistik)\n\n"
            . "Wir messen auf dieser Website anonym, wie sie genutzt wird und wie schnell sie lädt, um Inhalte und Technik zu verbessern. Dafür verwenden wir keine Cookies und speichern nichts auf Ihrem Gerät. Ihre IP-Adresse wird nicht gespeichert.\n\n"
            . "Was gemessen wird: aufgerufene Seite, Herkunftsseite (nur die Domain), grobe Geräteklasse (Handy, Tablet, Computer), Browser und Betriebssystem als grobe Klasse, Sprache, Land (geschätzt aus Zeitzone und Sprache, nicht aus der IP-Adresse), Verweildauer, Scrolltiefe, Klicks auf Links zu anderen Websites, Ladezeiten und Messwerte zur Seitenqualität (zum Beispiel Core Web Vitals), Anzahl und Art von Fehlern beim Laden der Seite sowie, ob Dunkelmodus, Querformat oder Datensparmodus eingestellt sind.\n\n"
            . "Zur Erkennung wiederkehrender Besucher wird aus Ihren technischen Angaben ein Kurzwert gebildet, der sich nach " . ($z > 1 ? $z . ' Tagen' : 'einem Tag') . " ändert und sich danach nicht mehr einer Person zuordnen lässt. " . $keep . "\n\n"
            . "Rechtsgrundlage ist unser berechtigtes Interesse an einer sicheren, schnellen und nutzerfreundlichen Website (Art. 6 Abs. 1 lit. f DSGVO). Sie können der Messung widersprechen, indem Sie in Ihrem Browser „Do Not Track“ aktivieren; dann wird nicht gemessen.\n\n"
            . "Die Daten bleiben auf unseren eigenen Servern und werden nicht an Dritte weitergegeben.";
    }

    static function visitors_report($w) {
        global $wpdb; $t = self::table();
        $group = function ($col, $nm = null, $lim = 12) use ($wpdb, $t, $w) {
            $o = [];
            foreach ($wpdb->get_results("SELECT $col a, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY $col ORDER BY n DESC LIMIT 60") as $r) { $k = $nm ? $nm($r->a) : ($r->a !== '' ? $r->a : 'unbekannt'); $o[$k] = ($o[$k] ?? 0) + (int)$r->n; }
            arsort($o); $r2 = []; foreach (array_slice($o, 0, $lim, true) as $k => $v) $r2[] = [$k, $v]; return $r2;
        };
        ob_start();
        echo '<div class="ms-grid">';
        self::bars('Herkunft genau', $group('ref', fn($a) => self::ref_name($a), 15));
        $utm = []; foreach ($wpdb->get_results("SELECT utm a, COUNT(*) n FROM $t WHERE kind='view' AND utm<>'' AND $w GROUP BY utm ORDER BY n DESC LIMIT 15") as $r) $utm[] = [str_replace('|', ' / ', rtrim($r->a, '|')), (int)$r->n];
        self::bars('Kampagnen (UTM: Quelle / Medium / Name)', $utm);
        self::bars('Browser', $group('br'));
        self::bars('Betriebssystem', $group('os'));
        $wbn = [0 => 'unbekannt', 1 => 'unter 400 px (kleines Handy)', 2 => '400 bis 599 px (Handy)', 3 => '600 bis 767 px (großes Handy, kleines Tablet)', 4 => '768 bis 1023 px (Tablet)', 5 => '1024 bis 1279 px (Laptop klein)', 6 => '1280 bis 1535 px (Laptop/Desktop)', 7 => '1536 px und mehr (großer Bildschirm)'];
        self::bars('Bildschirmklasse (Fensterbreite)', $group('wb', fn($a) => $wbn[(int)$a] ?? 'unbekannt'));
        self::bars('Sprache des Browsers', $group('lg', fn($a) => $a === '' ? 'unbekannt' : (['de' => 'Deutsch', 'en' => 'Englisch', 'fr' => 'Französisch', 'es' => 'Spanisch', 'it' => 'Italienisch', 'nl' => 'Niederländisch', 'pt' => 'Portugiesisch', 'pl' => 'Polnisch', 'ru' => 'Russisch', 'tr' => 'Türkisch'][$a] ?? $a)));
        echo '</div>';
        // Wochentag und Uhrzeit (Ortszeit der Seite)
        $off = function_exists('wp_timezone') ? (int)round(wp_timezone()->getOffset(new DateTime('now')) / 3600) : 0;
        $dow = array_fill(1, 7, 0); $hr = array_fill(0, 24, 0);
        foreach ($wpdb->get_results("SELECT DAYOFWEEK(DATE_ADD(ts, INTERVAL $off HOUR)) d, HOUR(DATE_ADD(ts, INTERVAL $off HOUR)) h, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY d, h") as $r) { $dow[(int)$r->d] += (int)$r->n; $hr[(int)$r->h] += (int)$r->n; }
        $dn = [2 => 'Montag', 3 => 'Dienstag', 4 => 'Mittwoch', 5 => 'Donnerstag', 6 => 'Freitag', 7 => 'Samstag', 1 => 'Sonntag'];
        $rows = []; foreach ($dn as $k => $n) $rows[] = [$n, $dow[$k]];
        echo '<div class="ms-grid">';
        self::bars('Wochentag', $rows);
        $mx = max(1, max($hr));
        echo '<div class="ms-card"><h2>Uhrzeit <small>(Ortszeit der Seite)</small></h2><svg viewBox="0 0 480 120" width="100%" role="img" aria-label="Aufrufe nach Uhrzeit">';
        foreach ($hr as $h => $n) { $bh = round(90 * $n / $mx); echo '<rect x="' . ($h * 20 + 2) . '" y="' . (100 - $bh) . '" width="16" height="' . max($bh, 1) . '" rx="2" fill="#2271b1"><title>' . $h . ' Uhr: ' . $n . ' Aufrufe</title></rect>'; if ($h % 3 === 0) echo '<text x="' . ($h * 20 + 10) . '" y="116" font-size="10" text-anchor="middle" fill="#646970">' . $h . '</text>'; }
        echo '</svg></div></div>';
        // Ladezeit
        $lz = $wpdb->get_row("SELECT COUNT(*) n, AVG(NULLIF(ld,0)) ld, AVG(NULLIF(lc,0)) lc, SUM(lc BETWEEN 1 AND 2500) g, SUM(lc BETWEEN 2501 AND 4000) m, SUM(lc > 4000) b, SUM(lc>0) k FROM $t WHERE kind='time' AND (ld>0 OR lc>0) AND $w");
        echo '<div class="ms-card"><h2>Ladezeit <small>(vom Browser des Besuchers gemessen)</small></h2>';
        if (!$lz || !(int)$lz->n) echo '<p class="ms-note">Noch keine Messwerte. Sie kommen mit Besuchern, die mindestens eine Sekunde auf der Seite bleiben.</p>';
        else {
            echo '<div class="ms-kpis"><div class="ms-kpi"><b>' . ($lz->ld ? number_format_i18n($lz->ld / 1000, 1) . ' s' : '–') . '</b><span>Ø Seite fertig geladen</span></div><div class="ms-kpi"><b>' . ($lz->lc ? number_format_i18n($lz->lc / 1000, 1) . ' s' : '–') . '</b><span>Ø bis der Hauptinhalt sichtbar ist (LCP)</span></div>';
            if ((int)$lz->k) echo '<div class="ms-kpi"><b>' . round(100 * $lz->g / $lz->k) . ' %</b><span>LCP gut (bis 2,5 s)</span></div><div class="ms-kpi"><b>' . round(100 * $lz->b / $lz->k) . ' %</b><span>LCP schlecht (über 4 s)</span></div>';
            echo '</div>';
            $sl = $wpdb->get_results("SELECT site, path, COUNT(*) n, AVG(lc) lc, AVG(NULLIF(ld,0)) ld FROM $t WHERE kind='time' AND lc>0 AND $w GROUP BY site, path HAVING n >= 3 ORDER BY lc DESC LIMIT 10");
            if ($sl) { echo '<table class="ms-tbl"><thead><tr><th>Langsamste Seiten (mind. 3 Messungen)</th><th class="num">Messungen</th><th class="num">Ø LCP</th><th class="num">Ø fertig geladen</th></tr></thead><tbody>'; foreach ($sl as $r) echo '<tr><td>' . esc_html($r->site . $r->path) . '</td><td class="num">' . (int)$r->n . '</td><td class="num">' . number_format_i18n($r->lc / 1000, 1) . ' s</td><td class="num">' . ($r->ld ? number_format_i18n($r->ld / 1000, 1) . ' s' : '–') . '</td></tr>'; echo '</tbody></table>'; }
            echo '<p class="ms-note">Gemessen im Browser (Navigation Timing und Largest Contentful Paint). Nicht jeder Browser liefert den LCP (Safari und Firefox teils nicht), die Werte gelten daher für die Browser, die ihn melden.</p>';
        }
        echo '</div>';
        return ob_get_clean();
    }

    static function fmt_time($s) {
        $s = (int)round($s);
        return $s < 60 ? $s . ' s' : floor($s / 60) . ' min ' . ($s % 60) . ' s';
    }

    static function report() {
        global $wpdb;
        $t = self::table();
        $sel = isset($_GET['seite']) ? sanitize_text_field(wp_unslash($_GET['seite'])) : '';
        $von = preg_match('/^\d{4}-\d\d-\d\d$/', (string)($_GET['von'] ?? '')) ? $_GET['von'] : '';
        $bis = preg_match('/^\d{4}-\d\d-\d\d$/', (string)($_GET['bis'] ?? '')) ? $_GET['bis'] : '';
        $to = gmdate('Y-m-d'); $custom = false; $yday = (($_GET['tage'] ?? '') === 'gestern');
        if ($von && $bis && $von <= $bis && strtotime($von) && strtotime($bis)) { $from = $von; $to = $bis; $days = (int)round((strtotime($to) - strtotime($from)) / 86400) + 1; $custom = true; }
        elseif ($yday) { $from = $to = gmdate('Y-m-d', time() - 86400); $days = 1; }
        else { $days = isset($_GET['tage']) ? max(1, min(3650, (int)$_GET['tage'])) : 30; $from = gmdate('Y-m-d', time() - ($days - 1) * 86400); }
        $w = $sel ? $wpdb->prepare('day >= %s AND day <= %s AND site = %s', $from, $to, $sel) : $wpdb->prepare('day >= %s AND day <= %s', $from, $to);
        $w_all = $w; // alle Zeilen (auch Roboter): nur der Reiter Roboter nutzt das
        $incl = !empty($_GET['bots']); // Schalter „Roboter einbeziehen“
        $hw = $incl ? '' : self::human_where();
        // Filter (nur Übersicht, Klicks, Verhalten, Pfade, Suche, Besucher): Aufrufe mit diesen Merkmalen und alles, was dieselben Besucher an diesem Tag getan haben
        $fq = []; $fcond = '';
        foreach (['f_src', 'f_dev', 'f_br', 'f_os', 'f_lg', 'f_cc'] as $fk) { $v = sanitize_text_field(wp_unslash($_GET[$fk] ?? '')); if ($v !== '') $fq[$fk] = $v; }
        if ($fq) {
            $fc = [];
            if (isset($fq['f_src'])) {
                $hs = []; foreach ($wpdb->get_col("SELECT DISTINCT ref FROM $t WHERE kind='view' AND $w_all") as $h) if (self::ref_kind(strtolower($h)) === $fq['f_src']) $hs[] = $wpdb->prepare('%s', $h);
                $fc[] = $hs ? 'ref IN (' . implode(',', $hs) . ')' : '1=0';
            }
            foreach (['f_dev' => 'device', 'f_br' => 'br', 'f_os' => 'os', 'f_lg' => 'lg', 'f_cc' => 'cc'] as $fk => $col) if (isset($fq[$fk])) $fc[] = $wpdb->prepare("$col = %s", $fq[$fk] === 'unbekannt' ? '' : $fq[$fk]);
            $fcond = " AND (site, day, visitor) IN (SELECT site, day, visitor FROM $t WHERE kind='view' AND $w_all" . $hw . ' AND ' . implode(' AND ', $fc) . ')';
        }
        $hw .= $fcond;
        $w = $w_all . $hw;

        $sites = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT site FROM $t WHERE day >= %s AND day <= %s ORDER BY site", $from, $to));
        $base = self::$remote !== null ? self::REMOTE_BASE : admin_url('admin.php?page=mini-statistik');
        echo '<div class="ms-card ms-nav"><b>Auswertung</b> &nbsp; ';
        foreach (['1' => 'Heute', 'gestern' => 'Gestern', '7' => '7 Tage', '30' => '30 Tage', '90' => '90 Tage', '365' => '1 Jahr', '3650' => 'Alles'] as $n => $nl) {
            $on = !$custom && (($n === 'gestern') ? $yday : (!$yday && (int)$n === $days));
            echo '<a href="' . esc_url(add_query_arg(['tage' => $n, 'seite' => $sel, 'bots' => $incl ? 1 : null], $base)) . '">' . ($on ? '<b>' . $nl . '</b>' : $nl) . '</a>';
        }
        echo '<form method="get" style="display:inline-block;margin-right:10px"><input type="hidden" name="page" value="mini-statistik"><input type="hidden" name="seite" value="' . esc_attr($sel) . '">' . ($incl ? '<input type="hidden" name="bots" value="1">' : '') . '<input type="date" name="von" value="' . esc_attr($custom ? $from : '') . '" style="width:140px"> – <input type="date" name="bis" value="' . esc_attr($custom ? $to : '') . '" style="width:140px"> <button class="button button-small">Zeitraum</button></form>';
        echo '<form method="get" style="display:inline"><input type="hidden" name="page" value="mini-statistik"><input type="hidden" name="tage" value="' . ($yday ? 'gestern' : (int)$days) . '">' . ($incl ? '<input type="hidden" name="bots" value="1">' : '') . '' . ($custom ? '<input type="hidden" name="von" value="' . esc_attr($from) . '"><input type="hidden" name="bis" value="' . esc_attr($to) . '">' : '') . '<select name="seite" onchange="this.form.submit()"><option value="">Alle Seiten</option>';
        foreach ($sites as $s) echo '<option' . selected($sel, $s, false) . '>' . esc_html($s) . '</option>';
        echo '</select></form> &nbsp; <a class="button button-small" href="' . esc_url(add_query_arg(['tage' => $yday ? 'gestern' : $days, 'seite' => $sel, 'von' => $custom ? $from : null, 'bis' => $custom ? $to : null, 'bots' => $incl ? null : 1], $base)) . '">' . ($incl ? 'Nur Menschen zeigen' : 'Roboter einbeziehen') . '</a><span class="ms-note"> &nbsp; Übersicht: ' . ($incl ? 'Menschen und vermutete Roboter zusammen.' : 'nur Menschen (Bewegung von Maus, Touch oder Scrollen erkannt).') . '</span></div>';

        $fr = self::flow_report($w, !$sel);

        $fopt = function ($col, $name) use ($wpdb, $t, $w_all) { return $wpdb->get_col("SELECT DISTINCT $col FROM $t WHERE kind='view' AND $col<>'' AND $w_all ORDER BY $col LIMIT 60"); };
        echo '<form method="get" class="ms-card ms-nav"><input type="hidden" name="page" value="mini-statistik"><input type="hidden" name="seite" value="' . esc_attr($sel) . '"><input type="hidden" name="tage" value="' . ($yday ? 'gestern' : (int)$days) . '">' . ($custom ? '<input type="hidden" name="von" value="' . esc_attr($from) . '"><input type="hidden" name="bis" value="' . esc_attr($to) . '">' : '') . ($incl ? '<input type="hidden" name="bots" value="1">' : '') . '<b>Nur Besucher mit:</b> ';
        foreach (['f_src' => ['Herkunft', ['Suchmaschinen', 'Soziale Netze', 'KI-Assistenten', 'Andere Seiten', 'Direkt / unbekannt']], 'f_dev' => ['Gerät', ['mobil', 'tablet', 'desktop']], 'f_br' => ['Browser', $fopt('br', 'br')], 'f_os' => ['System', $fopt('os', 'os')], 'f_lg' => ['Sprache', $fopt('lg', 'lg')], 'f_cc' => ['Land', $fopt('cc', 'cc')]] as $fk => $fd) {
            echo '<select name="' . $fk . '"><option value="">' . esc_html($fd[0]) . ': alle</option>';
            foreach ($fd[1] as $ov) echo '<option value="' . esc_attr($ov) . '"' . selected($fq[$fk] ?? '', $ov, false) . '>' . esc_html($fk === 'f_cc' ? self::country_name($ov) : $ov) . '</option>';
            echo '</select> ';
        }
        echo '<button class="button button-small">Filtern</button>' . ($fq ? ' <a class="button button-small" href="' . esc_url(add_query_arg(['tage' => $yday ? 'gestern' : $days, 'seite' => $sel, 'bots' => $incl ? 1 : null], $base)) . '">Filter aufheben</a> <span class="ms-note">Filter aktiv: ' . esc_html(implode(', ', $fq)) . '</span>' : '') . '</form>';

        // Aufrufe pro Tag, je Seite farbig gestapelt
        $pal = ['#2271b1', '#d98200', '#00a32a', '#8c3fb5', '#d63638', '#0a9396', '#a0a000', '#e0457b'];
        $rows_d = $wpdb->get_results("SELECT day, site, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY day, site");
        $series = []; $site_tot = [];
        foreach ($rows_d as $r) {
            $key = $days > 120 ? substr($r->day, 0, 7) : $r->day;
            $series[$key][$r->site] = ($series[$key][$r->site] ?? 0) + (int)$r->n;
            $site_tot[$r->site] = ($site_tot[$r->site] ?? 0) + (int)$r->n;
        }
        arsort($site_tot); $col = []; $ci = 0;
        foreach ($site_tot as $sn => $x_) $col[$sn] = $pal[$ci++ % count($pal)];
        if ($days <= 120) { $full = []; for ($i = $days - 1; $i >= 0; $i--) { $d = gmdate('Y-m-d', strtotime($to) - $i * 86400); $full[$d] = $series[$d] ?? []; } $series = $full; $unit = 'Tag'; }
        else { ksort($series); $unit = 'Monat'; }
        if (!$series) $series = [gmdate('Y-m-d') => []];
        $tot = array_map('array_sum', $series);
        $max = max(1, max($tot)); $n = count($series); $bw = 1000 / $n; $lab_on = $n <= 45;
        $sec = []; $cut = function ($t) use (&$sec) { $sec[$t] = ($sec[$t] ?? '') . ob_get_clean(); ob_start(); }; ob_start();
        echo '<div class="ms-card"><h2>Aufrufe pro ' . $unit . '</h2><svg viewBox="0 0 1000 190" width="100%" role="img" aria-label="Aufrufe pro ' . $unit . ', nach Seite gestapelt">';
        echo '<line x1="0" y1="150" x2="1000" y2="150" stroke="#dcdcde"/>';
        $i = 0;
        foreach ($series as $d => $parts) {
            $x = $i * $bw; $y = 150; $tip = $d . ': ' . $tot[$d] . ' Aufrufe';
            arsort($parts);
            foreach ($parts as $sn => $v) $tip .= "\n" . $sn . ': ' . $v;
            foreach ($parts as $sn => $v) {
                $h = 125 * $v / $max; $y -= $h;
                echo '<rect x="' . round($x + $bw * 0.12, 1) . '" y="' . round($y, 1) . '" width="' . round($bw * 0.76, 1) . '" height="' . round(max($h, 1), 1) . '" fill="' . $col[$sn] . '"><title>' . esc_html($tip) . '</title></rect>';
            }
            if ($lab_on) {
                if ($tot[$d] > 0) echo '<text x="' . round($x + $bw / 2, 1) . '" y="' . round($y - 4, 1) . '" font-size="' . ($n > 25 ? 10 : 12) . '" text-anchor="middle" fill="#1d2327">' . (int)$tot[$d] . '</text>';
                echo '<text x="' . round($x + $bw / 2, 1) . '" y="168" font-size="10" text-anchor="middle" fill="#646970">' . esc_html($days > 120 ? substr($d, 2) : substr($d, 8) . '.' . substr($d, 5, 2)) . '</text>';
            }
            $i++;
        }
        echo '<text x="0" y="186" font-size="12" fill="#646970">' . esc_html(array_key_first($series)) . '</text><text x="1000" y="186" font-size="12" text-anchor="end" fill="#646970">' . esc_html(array_key_last($series)) . '  (Spitze: ' . $max . ')</text></svg><p class="ms-note">';
        foreach ($col as $sn => $c_) echo '<span style="color:' . $c_ . '">▮</span> ' . esc_html($sn) . ' (' . (int)$site_tot[$sn] . ') &nbsp; ';
        echo '</p></div>';

        // Kennzahlen
        $views = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE kind='view' AND $w");
        $visitors = (int)$wpdb->get_var("SELECT COUNT(*) FROM (SELECT DISTINCT day, visitor FROM $t WHERE kind='view' AND $w) x"); // Besucher je Tag (ein Besucher an zwei Tagen zählt zweimal)
        $uniq = (int)$wpdb->get_var("SELECT COUNT(DISTINCT visitor) FROM $t WHERE kind='view' AND $w");
        $returners = (int)$wpdb->get_var("SELECT COUNT(*) FROM (SELECT visitor FROM $t WHERE kind='view' AND $w GROUP BY visitor HAVING COUNT(DISTINCT day) > 1) x");
        $tm = $wpdb->get_row("SELECT SUM(secs) s, AVG(scroll) g FROM $t WHERE kind='time' AND $w");
        $avg_time = $views ? ((int)$tm->s) / $views : 0;
        $clicks = $wpdb->get_results("SELECT site, path, target, label, item, img, pn, via, COUNT(*) n, MAX(ts) lt FROM $t WHERE kind='click' AND $w GROUP BY site, path, target, label, item, img, pn, via ORDER BY n DESC LIMIT 5000");
        // Klicks ohne Produktnummer (Kurzlinks, Suchlinks) einem Produkt mit Nummer zuordnen, wenn Bild oder Produktname auf derselben Seite übereinstimmt
        $by_img = []; $by_pn = [];
        foreach ($clicks as $c) if ($c->item !== '') {
            if ($c->img !== '') $by_img[$c->site . $c->path . '|' . $c->img] = [$c->item, $c->target];
            if ($c->pn !== '') $by_pn[$c->site . $c->path . '|' . strtolower($c->pn)] = [$c->item, $c->target];
        }
        $prod_key = function ($c, $p) use ($by_img, $by_pn) {
            $k = $c->site . $c->path; $item = $c->item; $host = $c->target;
            if ($item === '' && $c->img !== '' && isset($by_img[$k . '|' . $c->img])) [$item, $host] = $by_img[$k . '|' . $c->img];
            if ($item === '' && $c->pn !== '' && isset($by_pn[$k . '|' . strtolower($c->pn)])) [$item, $host] = $by_pn[$k . '|' . strtolower($c->pn)];
            $key = $item !== '' ? $item : ($c->img !== '' ? 'I:' . $c->img : ($c->pn !== '' ? 'N:' . strtolower($c->pn) : 'T:' . strtolower($c->label)));
            return [$p . '|' . $key . ($item === '' && $c->img === '' && $c->pn === '' ? '|' . $c->target : ''), $item, $host];
        };
        $by_partner = []; $products = []; $click_total = 0; $partner_clicks = 0; $click_by_page = []; $top_links = [];
        foreach ($clicks as $c) {
            $p = self::partner($c->target);
            $by_partner[$p] = ($by_partner[$p] ?? 0) + $c->n;
            if ($p === 'Eigene Seiten') continue;
            $click_total += $c->n;
            if ($p === 'Amazon' || $p === 'eBay') $partner_clicks += $c->n;
            $k = $c->site . $c->path; $click_by_page[$k] = ($click_by_page[$k] ?? 0) + $c->n;
            if ($p === 'Amazon' || $p === 'eBay') {
                [$pk, $item, $host] = $prod_key($c, $p);
                if (!isset($products[$pk])) $products[$pk] = ['p' => $p, 'item' => $item, 'host' => $host, 'img' => '', 'n' => 0, 'ni' => 0, 'nt' => 0, 'names' => [], 'labels' => [], 'pages' => [], 'lt' => ''];
                $q =& $products[$pk];
                if ($c->lt > $q['lt']) $q['lt'] = $c->lt;
                $q['n'] += $c->n; if ($c->via === 'img') $q['ni'] += $c->n; else $q['nt'] += $c->n;
                if ($q['img'] === '' && $c->img !== '') $q['img'] = $c->img;
                if ($c->pn !== '') $q['names'][$c->pn] = ($q['names'][$c->pn] ?? 0) + $c->n;
                if ($c->label !== '') $q['labels'][$c->label] = ($q['labels'][$c->label] ?? 0) + $c->n;
                $q['pages'][$k] = ($q['pages'][$k] ?? 0) + $c->n;
                unset($q);
            }
            $top_links[] = [$c->label !== '' ? $c->label : '(Bild/ohne Text)', $p, $c->site . $c->path, (int)$c->n, ($p === 'Amazon' || $p === 'eBay') ? $prod_key($c, $p)[0] : '', '', $c->target];
        }
        arsort($by_partner);
        foreach ($top_links as &$tl) {
            $tl[5] = ''; $tl[7] = '';
            if ($tl[4] !== '' && isset($products[$tl[4]])) {
                $pq = $products[$tl[4]]; arsort($pq['names']); $tl[5] = $pq['names'] ? array_key_first($pq['names']) : '';
                if ($pq['item'] !== '') $tl[7] = $pq['p'] === 'Amazon' ? 'https://www.amazon.de/dp/' . $pq['item'] : 'https://www.ebay.de/itm/' . $pq['item'];
            }
            if ($tl[7] === '' && $tl[1] === 'Sonstige' && preg_match('/^[a-z0-9.\-]+$/i', (string)$tl[6])) $tl[7] = 'https://' . $tl[6];
        }
        unset($tl);

        // Anteil der Besucher mit Klick (je Besucher nur einmal pro Ziel gezählt)
        $vis_click = ['Amazon' => [], 'eBay' => [], 'Sonstige' => [], 'any' => []];
        foreach ($wpdb->get_results("SELECT DISTINCT day, visitor, target FROM $t WHERE kind='click' AND $w LIMIT 50000") as $r) {
            $pp = self::partner($r->target);
            if ($pp === 'Eigene Seiten') continue;
            $vk = $r->day . '|' . $r->visitor; $vis_click[$pp][$vk] = 1;
            if ($pp !== 'Sonstige') $vis_click['any'][$vk] = 1;
        }
        $pct = function ($k) use ($vis_click, $visitors) { return $visitors ? round(100 * count($vis_click[$k]) / $visitors, 1) : 0; };

        // Rückkehr nach Klick auf externe Links
        $ret = ['Amazon' => [], 'eBay' => [], 'Sonstige' => []]; $pret = [];
        $vis_list = []; $back_list = [];
        foreach ($wpdb->get_results("SELECT site, visitor, ts FROM $t WHERE kind='view' AND $w ORDER BY ts LIMIT 60000") as $r) $vis_list[$r->site . '|' . $r->visitor][] = strtotime($r->ts . ' UTC');
        foreach ($wpdb->get_results("SELECT site, visitor, ts, secs FROM $t WHERE kind='back' AND $w ORDER BY ts LIMIT 60000") as $r) $back_list[$r->site . '|' . $r->visitor][] = [strtotime($r->ts . ' UTC'), (int)$r->secs];
        foreach ($wpdb->get_results("SELECT site, path, visitor, target, label, item, img, pn, ts FROM $t WHERE kind='click' AND $w ORDER BY ts LIMIT 30000") as $r) {
            $pp = self::partner($r->target);
            if (!isset($ret[$pp])) continue;
            $ct = strtotime($r->ts . ' UTC'); $kk = $r->site . '|' . $r->visitor; $res = ['n' => 1, 'type' => 'none', 'd' => 0];
            foreach ($back_list[$kk] ?? [] as $b) if ($b[0] >= $ct && $b[0] - $ct <= 10800) { $res['type'] = 'back'; $res['d'] = $b[1] > 0 ? $b[1] : $b[0] - $ct; break; }
            if ($res['type'] === 'none') foreach ($vis_list[$kk] ?? [] as $vt) if ($vt > $ct + 1 && $vt - $ct <= 10800) { $res['type'] = 'view'; $res['d'] = $vt - $ct; break; }
            if ($res['type'] === 'none') foreach ($vis_list[$kk] ?? [] as $vt) if ($vt - $ct > 10800) { $res['type'] = 'later'; $res['d'] = $vt - $ct; break; }
            $ret[$pp][] = $res;
            if ($pp === 'Amazon' || $pp === 'eBay') $pret[$prod_key($r, $pp)[0]][] = $res;
        }
        // Vergleich mit dem Zeitraum davor (gleich lang)
        $dl = function ($cur, $prev) { if ($prev === null || $prev <= 0) return ''; $p = round(100 * ($cur - $prev) / $prev); return $p == 0 ? '<i class="ms-d">± 0 %</i>' : '<i class="ms-d" style="color:' . ($p > 0 ? '#00a32a' : '#d63638') . '">' . ($p > 0 ? '▲ +' : '▼ ') . $p . ' %</i>'; };
        $dv = $dvis = $dclk = $dtime = null;
        if ($days < 3650) {
            $pto = gmdate('Y-m-d', strtotime($from) - 86400); $pfrom = gmdate('Y-m-d', strtotime($pto) - ($days - 1) * 86400);
            $wp = ($sel ? $wpdb->prepare('day >= %s AND day <= %s AND site = %s', $pfrom, $pto, $sel) : $wpdb->prepare('day >= %s AND day <= %s', $pfrom, $pto)) . $hw;
            $dv = (int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE kind='view' AND $wp");
            $dvis = (int)$wpdb->get_var("SELECT COUNT(*) FROM (SELECT DISTINCT day, visitor FROM $t WHERE kind='view' AND $wp) x");
            $psecs = (int)$wpdb->get_var("SELECT SUM(secs) FROM $t WHERE kind='time' AND $wp");
            $dtime = $dv ? $psecs / $dv : null;
            $dclk = 0;
            foreach ($wpdb->get_results("SELECT target, COUNT(*) n FROM $t WHERE kind='click' AND $wp GROUP BY target") as $r) { $pp_ = self::partner($r->target); if ($pp_ === 'Amazon' || $pp_ === 'eBay') $dclk += (int)$r->n; }
        }
        // Roboter-Schätzung: nur für Seiten und Zeiten, ab denen sie das Signal „Bewegung“ senden (Version 0.23)
        $since_h = [];
        foreach ($wpdb->get_results("SELECT site, MIN(ts) m FROM $t WHERE kind='human' GROUP BY site") as $r_) $since_h[$r_->site] = $r_->m;
        $meas = $bots = $quiet = 0;
        if ($since_h) {
            $hum = [];
            foreach ($wpdb->get_results("SELECT DISTINCT site, day, visitor FROM $t WHERE kind='human' AND $w_all LIMIT 60000") as $r_) $hum[$r_->site . '|' . $r_->day . '|' . $r_->visitor] = 1;
            $rdev = ['mobil' => 0, 'tablet' => 0, 'desktop' => 0, 'unbekannt' => 0];
            foreach ($wpdb->get_results("SELECT site, day, visitor, MIN(ts) m, MAX(via='bot') b, MAX(device) dv FROM $t WHERE kind='view' AND $w_all GROUP BY site, day, visitor LIMIT 60000") as $r_) {
                if (!isset($since_h[$r_->site]) || $r_->m < $since_h[$r_->site]) continue;
                $meas++;
                $dk = $r_->dv !== '' && isset($rdev[$r_->dv]) ? $r_->dv : 'unbekannt';
                if ((int)$r_->b) { $bots++; $rdev[$dk]++; }
                elseif (!isset($hum[$r_->site . '|' . $r_->day . '|' . $r_->visitor])) { $quiet++; $rdev[$dk]++; }
            }
        }
        $rob = $meas ? ($bots + $quiet) / $meas : 0;
        echo '<div class="ms-kpis">';
        foreach ([
            [number_format_i18n($visitors), 'Besucher (je Tag gezählt)', $dl($visitors, $dvis)],
            [$uniq ? round(100 * $returners / $uniq) . ' %' : '–', 'Wiederkehrer (an mehr als einem Tag, innerhalb von ' . (int)self::opts()['salt_days'] . ' Tagen)'],
            [number_format_i18n($views), 'Seitenaufrufe', $dl($views, $dv)],
            [self::fmt_time($avg_time), 'Ø Verweildauer pro Aufruf', $dl($avg_time, $dtime)],
            [self::fmt_time($visitors ? ((int)$tm->s) / $visitors : 0), 'Ø Verweildauer pro Besucher und Tag'],
            [round((float)$tm->g) . ' %', 'Ø Scrolltiefe'],
            [number_format_i18n($partner_clicks), 'Klicks zu Amazon / eBay', $dl($partner_clicks, $dclk)],
            [$pct('any') . ' %', 'Besucher mit Klick auf Amazon oder eBay'],
        ] as $k) echo '<div class="ms-kpi"><b>' . esc_html($k[0]) . '</b><span>' . esc_html($k[1]) . '</span>' . ($k[2] ?? '') . '</div>';
        echo '</div>';
        ob_start(); echo '<div class="ms-kpis">';
        if ($meas >= 20) foreach ([
            [round(100 * $rob) . ' %', 'vermutlich Roboter (' . number_format_i18n($bots) . ' als automatisiert gemeldet, ' . number_format_i18n($quiet) . ' ganz ohne Maus, Touch oder Scrollen; gemessen an ' . number_format_i18n($meas) . ' Besuchern seit Version 0.23)'],
        ] as $k) echo '<div class="ms-kpi"><b>' . esc_html($k[0]) . '</b><span>' . esc_html($k[1]) . '</span>' . ($k[2] ?? '') . '</div>';
        echo '</div>';
        echo self::robot_overview($w_all, $meas, $bots, $quiet, $rdev ?? []);
        $robot_top = ob_get_clean();
        if ($meas >= 20 && !$incl) echo '<p class="ms-note">Die Zahlen oben zählen nur Menschen (' . round(100 * $rob) . ' % der Besucher wirken wie Roboter und sind herausgenommen). Alles zu den Robotern steht im Reiter „Roboter“.</p>';
        echo ($dv !== null ? '<p class="ms-note">Pfeile: Veränderung gegenüber dem gleich langen Zeitraum davor (' . esc_html($pfrom . ' bis ' . $pto) . ').</p>' : '');

        echo $fr['ee'];
        $cut('u');
        // Meistgeklickte Produkte
        $hidden = (array)get_option('mini_statistik_hidden', []);
        $nhid = 0;
        foreach ($hidden as $hk) if (isset($products[$hk])) { unset($products[$hk]); $nhid++; }
        uasort($products, fn($a, $b) => $b['n'] <=> $a['n']);
        $onerr = 'var f=this.dataset.f?this.dataset.f.split(\'|\'):[];if(f.length){this.src=f.shift();this.dataset.f=f.join(\'|\');}else{this.style.visibility=\'hidden\'}';
        $onload = 'if(this.naturalWidth<3){var f=this.dataset.f?this.dataset.f.split(\'|\'):[];if(f.length){this.src=f.shift();this.dataset.f=f.join(\'|\');}else{this.style.visibility=\'hidden\'}}';
        echo '<style>.ms-scroll{max-height:70vh;overflow:auto}#ms-produkte .ms-tbl thead th{position:sticky;top:0;background:#fff;z-index:2;box-shadow:0 1px 0 #dcdcde}</style><div class="ms-card" id="ms-produkte"><h2>Meistgeklickte Produkte (Amazon / eBay)</h2><p class="ms-note">Anzeigen: <select id="ms-plim"><option>10</option><option>25</option><option>50</option><option>100</option></select> Produkte · Spaltenüberschrift anklicken zum Sortieren</p><div class="ms-scroll"><table class="ms-tbl"><thead><tr><th></th><th>Produkt</th><th>Shop</th><th class="num">Klicks</th><th class="num">Bild</th><th class="num">Text</th><th class="num">kamen zurück</th><th class="num">Ø Zeit bis Rückkehr</th><th>Hauptsächlich auf</th><th>Letzter Klick</th><th></th></tr></thead><tbody>';
        foreach (array_slice($products, 0, 100, true) as $pk => $q) {
            arsort($q['names']); arsort($q['labels']); arsort($q['pages']);
            $name = $q['names'] ? array_key_first($q['names']) : ($q['labels'] ? array_key_first($q['labels']) : '(Produkt nicht erkannt)');
            $srcs = [];
            if ($q['img'] !== '') $srcs[] = $q['img'];
            if ($q['p'] === 'Amazon' && $q['item'] !== '') {
                $srcs[] = 'https://m.media-amazon.com/images/P/' . $q['item'] . '.01._SL160_.jpg';
                $srcs[] = 'https://ws-na.amazon-adsystem.com/widgets/q?_encoding=UTF8&MarketPlace=DE&ASIN=' . $q['item'] . '&ServiceVersion=20070822&ID=AsinImage&WS=1&Format=_SL160_';
                $srcs[] = 'https://images-na.ssl-images-amazon.com/images/P/' . $q['item'] . '.03._SL160_.jpg';
            }
            $thumb = $srcs
                ? '<img src="' . esc_url(array_shift($srcs)) . '" data-f="' . esc_attr(implode('|', $srcs)) . '" onerror="' . esc_attr($onerr) . '" onload="' . esc_attr($onload) . '" alt="" width="64" height="64" loading="lazy" referrerpolicy="no-referrer" style="object-fit:contain;border-radius:6px;background:#f6f7f7">'
                : '<div style="width:64px;height:64px;border-radius:6px;background:#f0f0f1;color:#a7aaad;display:flex;align-items:center;justify-content:center;font-size:11px;text-align:center">kein Bild</div>';
            $id = '';
            $unas = ($q['item'] === '' && $q['img'] === '' && !$q['names']);
            if ($unas) $thumb = '<div style="width:64px;height:64px;border-radius:6px;background:#fcf0f1;color:#d63638;display:flex;align-items:center;justify-content:center;font-size:11px;text-align:center">nicht zuordenbar</div>';
            if ($q['item'] !== '') {
                $hh = preg_match('/amzn\.|ebay\.us|link\.amazon/', $q['host']) ? ($q['p'] === 'Amazon' ? 'www.amazon.de' : 'www.ebay.de') : $q['host'];
                $href = $q['p'] === 'Amazon' ? 'https://' . $hh . '/dp/' . $q['item'] : 'https://' . $hh . '/itm/' . $q['item'];
                $id = '<a href="' . esc_url($href) . '" target="_blank" rel="noopener noreferrer">' . esc_html(($q['p'] === 'Amazon' ? 'ASIN ' : 'Artikel-Nr. ') . $q['item']) . '</a>';
            }
            $lbl = array_slice(array_keys($q['labels']), 0, 3);
            $sub = trim(($id ? $id . ' · ' : '') . ($lbl ? 'Linktext: „' . esc_html(implode('“, „', $lbl)) . '“' : ''), ' ·');
            $pr = $pret[$pk] ?? []; $rb = 0; $rd = [];
            foreach ($pr as $x) if ($x['type'] === 'back' || $x['type'] === 'view') { $rb++; $rd[] = $x['d']; }
            $back_cell = $pr ? '<b>' . round(100 * $rb / count($pr)) . ' %</b>' : '–';
            $time_cell = $rd ? self::fmt_time(array_sum($rd) / count($rd)) : '–';
            echo '<tr><td style="width:72px">' . $thumb . '</td><td><b>' . esc_html($name) . '</b>' . ($sub ? '<br><span class="ms-note">' . $sub . '</span>' : '') . '</td><td><span class="ms-pill ms-p-' . esc_attr($q['p']) . '">' . esc_html($q['p']) . '</span></td><td class="num"><b>' . (int)$q['n'] . '</b></td><td class="num">' . (int)$q['ni'] . '</td><td class="num">' . (int)$q['nt'] . '</td><td class="num">' . $back_cell . '</td><td class="num">' . $time_cell . '</td><td>' . implode('<br>', array_map(function ($pg, $n_) use ($unas) { return '<a href="' . esc_url('https://' . $pg) . '" target="_blank" rel="noopener noreferrer">' . esc_html($pg) . '</a>' . ($unas ? ' (' . (int)$n_ . ')' : ''); }, array_slice(array_keys($q['pages']), 0, $unas ? 4 : 1), array_slice(array_values($q['pages']), 0, $unas ? 4 : 1))) . '</td><td>' . ($q['lt'] ? esc_html(wp_date('d.m.y H:i', strtotime($q['lt'] . ' UTC'))) : '–') . '</td><td><form method="post">' . wp_nonce_field('ms_hide', '_wpnonce', true, false) . '<input type="hidden" name="pk" value="' . esc_attr($pk) . '"><button class="button button-small" name="ms_hide" value="hide" title="Aus dieser Liste ausblenden (Daten bleiben gespeichert)">ausblenden</button></form></td></tr>';
        }
        if (!$products) echo '<tr><td colspan="11">Noch keine Klicks auf Amazon oder eBay.</td></tr>';
        echo '</tbody></table></div>';
        if ($hidden) echo '<form method="post" style="margin-top:8px">' . wp_nonce_field('ms_hide', '_wpnonce', true, false) . '<button class="button button-small" name="ms_hide" value="show">Ausgeblendete Produkte wieder einblenden (' . count($hidden) . ')</button></form>';
        echo '<p class="ms-note">Zeigt bis zu 100 der meistgeklickten Produkte im gewählten Zeitraum (oben „Auswertung"). Produktname und Bild werden beim Klick aus der Seite gelesen. Text- und Kurzlinks werden dem Produkt zugeordnet, wenn auf derselben Seite Bild oder Name übereinstimmen. „Kamen zurück" = innerhalb von 3 Stunden wieder auf deiner Seite; „Ø Zeit" gilt nur für die, die zurückkamen. Bei wenigen Klicks sind die Werte nur grobe Hinweise.</p></div>';

        echo '<div class="ms-card"><h2>Welcher Anteil der Besucher klickt auf einen ausgehenden Link?</h2>';
        foreach ([['Amazon', 'amz', 'Amazon'], ['eBay', 'ebay', 'eBay'], ['Sonstige', 'oth', 'andere externe Seiten'], ['any', '', 'Amazon oder eBay (mindestens ein Klick)']] as $b) {
            $v = $pct($b[0]);
            echo '<div class="ms-row"><span class="n">' . esc_html($b[2]) . '</span><div class="ms-bar ' . $b[1] . '"><i style="width:' . min(100, $v * 2) . '%"></i></div><span class="v">' . number_format_i18n($v, 1) . ' %</span></div>';
        }
        echo '<p class="ms-note">Anteil an allen Besuchern im gewählten Zeitraum (Balken auf 50 % skaliert). Pro Besucher zählt ein Ziel nur einmal.</p></div>';

        echo '<div class="ms-card"><h2>Was passiert nach dem Klick auf Amazon / eBay?</h2><table class="ms-tbl"><thead><tr><th>Ziel</th><th class="num">Klicks</th><th class="num">kamen zurück</th><th class="num">davon sofort (Seite aus Speicher)</th><th class="num">davon mit neuem Aufruf</th><th class="num">kamen später wieder (neuer Besuch)</th><th class="num">nicht zurück</th><th class="num">Ø Zeit bis Rückkehr</th><th class="num">mittlere Zeit (Median)</th></tr></thead><tbody>';
        $all_d = []; $later_d = [];
        foreach ($ret as $pp => $list) {
            $n = count($list); if (!$n) continue;
            $b = $v = $l = 0; $ds = [];
            foreach ($list as $x) { if ($x['type'] === 'back') { $b++; $ds[] = $x['d']; } elseif ($x['type'] === 'view') { $v++; $ds[] = $x['d']; } elseif ($x['type'] === 'later') { $l++; $later_d[] = $x['d']; } }
            sort($ds); $m = count($ds); $all_d = array_merge($all_d, $ds);
            $med = $m ? ($m % 2 ? $ds[intdiv($m, 2)] : ($ds[$m / 2 - 1] + $ds[$m / 2]) / 2) : 0;
            echo '<tr><td><span class="ms-pill ms-p-' . esc_attr($pp) . '">' . esc_html($pp) . '</span></td><td class="num">' . $n . '</td><td class="num"><b>' . round(100 * ($b + $v) / $n) . ' %</b></td><td class="num">' . $b . '</td><td class="num">' . $v . '</td><td class="num">' . $l . '</td><td class="num">' . ($n - $b - $v - $l) . '</td><td class="num">' . ($m ? self::fmt_time(array_sum($ds) / $m) : '–') . '</td><td class="num">' . ($m ? self::fmt_time($med) : '–') . '</td></tr>';
        }
        if (!array_filter($ret)) echo '<tr><td colspan="9">Noch keine Klicks.</td></tr>';
        echo '</tbody></table>';
        if ($all_d) {
            $bk = ['unter 30 s' => 0, '30 s bis 2 min' => 0, '2 bis 5 min' => 0, '5 bis 15 min' => 0, 'über 15 min' => 0];
            foreach ($all_d as $d) { if ($d < 30) $bk['unter 30 s']++; elseif ($d < 120) $bk['30 s bis 2 min']++; elseif ($d < 300) $bk['2 bis 5 min']++; elseif ($d < 900) $bk['5 bis 15 min']++; else $bk['über 15 min']++; }
            $mx = max($bk); echo '<h3 style="margin:14px 0 6px;font-size:13px">Wie lange dauert es bis zur Rückkehr?</h3>';
            foreach ($bk as $l => $c) echo '<div class="ms-row"><span class="n">' . esc_html($l) . '</span><div class="ms-bar"><i style="width:' . round(100 * $c / max(1, $mx)) . '%"></i></div><span class="v">' . $c . '</span></div>';
        }
        if ($later_d) {
            $lb = ['am selben Tag später (nach über 3 Std.)' => 0, 'nach 1 bis 2 Tagen' => 0, 'nach mehr als 2 Tagen' => 0];
            foreach ($later_d as $d) { if ($d <= 86400) $lb['am selben Tag später (nach über 3 Std.)']++; elseif ($d <= 172800) $lb['nach 1 bis 2 Tagen']++; else $lb['nach mehr als 2 Tagen']++; }
            $mx = max($lb); echo '<h3 style="margin:14px 0 6px;font-size:13px">Wer später wiederkommt: nach wie langer Zeit?</h3>';
            foreach ($lb as $l2 => $c) echo '<div class="ms-row"><span class="n">' . esc_html($l2) . '</span><div class="ms-bar own"><i style="width:' . round(100 * $c / max(1, $mx)) . '%"></i></div><span class="v">' . $c . '</span></div>';
        }
        echo '<p class="ms-note">Gemessen wird die Zeit vom Klick bis zur Rückkehr auf deine Seite, nicht das Verhalten bei Amazon oder eBay selbst. „Kamen zurück" = innerhalb von 3 Stunden. „Später wieder" = neuer Besuch desselben Browsers, erkennbar nur innerhalb der eingestellten Wiedererkennungsdauer (' . (int)self::opts()['salt_days'] . ' Tage). „Nicht zurück" = in dieser Zeit nicht wieder gesehen. Ein anderes Gerät oder Browser wird nicht erkannt.</p></div>';

        $cut('k');
        // Partner-Klicks
        $pc = []; foreach ($by_partner as $k => $v) $pc[] = [$k, (int)$v];
        echo '<div class="ms-grid">';
        self::bars('Klicks nach Ziel', $pc, ['Amazon' => 'amz', 'eBay' => 'ebay', 'Sonstige' => 'oth', 'Eigene Seiten' => 'own']);
        echo '</div>'; $cut('k'); echo '<div class="ms-grid">';
        $ref = $wpdb->get_results("SELECT COALESCE(NULLIF(ref,''),'direkt / unbekannt') a, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY COALESCE(NULLIF(ref,''),'direkt / unbekannt') ORDER BY n DESC LIMIT 10");
        $kinds = [];
        foreach ($wpdb->get_results("SELECT COALESCE(NULLIF(ref,''),'') a, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY COALESCE(NULLIF(ref,''),'')") as $r) {
            $k = self::ref_kind(strtolower($r->a));
            $kinds[$k] = ($kinds[$k] ?? 0) + (int)$r->n;
        }
        arsort($kinds);
        self::bars('Herkunft nach Art', array_map(fn($k, $v) => [$k, $v], array_keys($kinds), array_values($kinds)));
        self::bars('Herkunft', array_map(fn($r) => [$r->a, (int)$r->n], $ref));
        $dev = $wpdb->get_results("SELECT COALESCE(NULLIF(device,''),'unbekannt') a, COUNT(*) n FROM $t WHERE kind='view' AND $w GROUP BY COALESCE(NULLIF(device,''),'unbekannt') ORDER BY n DESC");
        self::bars('Geräte', array_map(fn($r) => [$r->a, (int)$r->n], $dev));
        $cty = $wpdb->get_results("SELECT cc, COUNT(*) n FROM $t WHERE kind='view' AND cc <> '' AND $w GROUP BY cc ORDER BY n DESC LIMIT 10");
        self::bars('Länder (geschätzt)', array_map(fn($r) => [trim(self::flag($r->cc) . ' ' . self::country_name($r->cc)), (int)$r->n], $cty));
        echo '</div>';

        $cut('u');
        // Seiten im Detail
        $pv = $wpdb->get_results("SELECT site, path, COUNT(*) v FROM $t WHERE kind='view' AND $w GROUP BY site, path ORDER BY v DESC LIMIT 25");
        $pt = []; foreach ($wpdb->get_results("SELECT site, path, SUM(secs) s, AVG(scroll) g FROM $t WHERE kind='time' AND $w GROUP BY site, path") as $r) $pt[$r->site . $r->path] = $r;
        echo '<div class="ms-card"><h2>Seiten im Detail</h2><table class="ms-tbl"><thead><tr><th>Seite</th><th class="num">Aufrufe</th><th class="num">Ø Zeit</th><th class="num">Scrolltiefe</th><th class="num">Klicks extern</th><th class="num">Klickrate</th></tr></thead><tbody>';
        foreach ($pv as $r) {
            $k = $r->site . $r->path; $c = $click_by_page[$k] ?? 0; $x = $pt[$k] ?? null;
            echo '<tr><td>' . esc_html($k) . '</td><td class="num">' . (int)$r->v . '</td><td class="num">' . ($x ? self::fmt_time($x->s / $r->v) : '–') . '</td><td class="num">' . ($x ? round($x->g) . ' %' : '–') . '</td><td class="num">' . (int)$c . '</td><td class="num">' . round(100 * $c / $r->v) . ' %</td></tr>';
        }
        if (!$pv) echo '<tr><td colspan="6">Noch keine Daten.</td></tr>';
        echo '</tbody></table></div>';

        $cut('v');
        // Meistgeklickte Links
        usort($top_links, fn($a, $b) => $b[3] <=> $a[3]);
        echo '<div class="ms-card"><h2>Meistgeklickte Links <small><a href="#ms-produkte">→ zu den meistgeklickten Produkten</a></small></h2><p class="ms-note">Linktext, Ziel und Produkt öffnen das Ziel des Klicks (Produktseite bzw. Domain); „Auf Seite“ öffnet die Seite, auf der geklickt wurde. Bei Kurzlinks ohne erkannte Produktnummer führt nur die Seite weiter.</p><table class="ms-tbl"><thead><tr><th>Linktext</th><th>Ziel</th><th>Produkt</th><th>Auf Seite</th><th class="num">Klicks</th></tr></thead><tbody>';
        foreach (array_slice($top_links, 0, 20) as $l) {
            $lnk = function ($txt) use ($l) { return $l[7] !== '' ? '<a href="' . esc_url($l[7]) . '" target="_blank" rel="noopener noreferrer">' . esc_html($txt) . '</a>' : esc_html($txt); };
            echo '<tr><td>' . $lnk($l[0]) . '</td><td><span class="ms-pill ms-p-' . esc_attr($l[1]) . '">' . $lnk($l[1]) . '</span></td><td>' . ($l[5] !== '' ? $lnk($l[5]) : '') . '</td><td><a href="' . esc_url('https://' . $l[2]) . '" target="_blank" rel="noopener noreferrer">' . esc_html($l[2]) . '</a></td><td class="num">' . (int)$l[3] . '</td></tr>';
        }
        if (!$top_links) echo '<tr><td colspan="5">Noch keine Klicks.</td></tr>';
        echo '</tbody></table></div>';

        $cut('k');
        $sec['v'] = ($sec['v'] ?? '') . $fr['exit']; $sec['p'] = ($sec['p'] ?? '') . $fr['kpi'] . $fr['grid'] . $fr['warn'];

        self::ga_report($sel);

        $cut('u');
        // Sonstige externe Ziele
        $oth = [];
        foreach ($clicks as $c) {
            if (self::partner($c->target) !== 'Sonstige') continue;
            $o2 =& $oth[strtolower(preg_replace('/^www\./', '', $c->target))];
            if (!$o2) $o2 = ['n' => 0, 'labels' => [], 'pages' => []];
            $o2['n'] += $c->n;
            if ($c->label !== '') $o2['labels'][$c->label] = ($o2['labels'][$c->label] ?? 0) + $c->n;
            $o2['pages'][$c->site . $c->path] = ($o2['pages'][$c->site . $c->path] ?? 0) + $c->n;
            unset($o2);
        }
        uasort($oth, fn($a, $b) => $b['n'] <=> $a['n']);
        echo '<div class="ms-card"><h2>Sonstige externe Links (nicht Amazon/eBay)</h2><table class="ms-tbl"><thead><tr><th>Ziel-Domain</th><th class="num">Klicks</th><th>Linktext</th><th>Meist auf Seite</th></tr></thead><tbody>';
        foreach (array_slice($oth, 0, 30, true) as $h => $x) {
            arsort($x['labels']); arsort($x['pages']);
            echo '<tr><td>' . (preg_match('/^[a-z0-9.\-]+$/i', (string)$h) ? '<a href="' . esc_url('https://' . $h) . '" target="_blank" rel="noopener noreferrer">' . esc_html($h) . '</a>' : esc_html($h)) . '</td><td class="num"><b>' . (int)$x['n'] . '</b></td><td>' . esc_html(implode(' · ', array_slice(array_keys($x['labels']), 0, 3))) . '</td><td><a href="' . esc_url('https://' . array_key_first($x['pages'])) . '" target="_blank" rel="noopener noreferrer">' . esc_html(array_key_first($x['pages'])) . '</a></td></tr>';
        }
        if (!$oth) echo '<tr><td colspan="4">Noch keine Klicks auf sonstige Seiten.</td></tr>';
        echo '</tbody></table></div>';

        $cut('k'); ob_end_clean();
        $sec['k'] = '<div class="ms-card"><b>Klicks nach:</b> <a href="#" class="button button-primary ms-kvb" data-v="p">Produkt</a> <a href="#" class="button ms-kvb" data-v="s">Seite / Website</a></div><div id="ms-kv-p">' . ($sec['k'] ?? '') . '</div><div id="ms-kv-s" style="display:none">' . self::clicks_by_page($w, !$sel) . '</div><script>(function(){var b=document.querySelectorAll(".ms-kvb");b.forEach(function(x){x.addEventListener("click",function(e){e.preventDefault();var v=x.dataset.v;b.forEach(function(y){y.className="button ms-kvb"+(y===x?" button-primary":"");});document.getElementById("ms-kv-p").style.display=v==="p"?"":"none";document.getElementById("ms-kv-s").style.display=v==="s"?"":"none";});});})();</script>';
        $sec['b'] = self::visitors_report($w);
        $sec['q'] = self::quality_report($w, !$sel);
        $sec['m'] = self::browser_report($w);
        $sec['x'] = self::speed_report($w);
        $sec['s'] = self::search_report($w, !$sel, $visitors);
        $sec['r'] = ($robot_top ?? '') . self::robot_report($w_all);
        if (self::$remote === null) { ob_start(); AB1_Weiterlesen::tab(); $sec['w'] = ob_get_clean(); }
        $tabs = ['u' => 'Übersicht', 'k' => 'Klicks', 'v' => 'Verhalten auf den Seiten', 'p' => 'Pfade', 'b' => 'Besucher', 'q' => 'Qualität', 'm' => 'Browser & Verhalten', 'x' => 'Speed', 's' => 'Suche & 404', 'r' => 'Roboter', 'w' => 'Weiterlesen & Popup'];
        if (self::$remote !== null) unset($tabs['w']);
        echo self::status_banner(self::$remote);
        echo '<style>.ms-pane{display:none}.ms-pane.on{display:block}.ms-tabs{padding:8px 12px;position:sticky;top:32px;z-index:5}.ms-tabs a.button{margin-right:6px}</style><div class="ms-card ms-tabs">';
        foreach ($tabs as $tk => $tn) echo '<a href="#ms-t-' . $tk . '" data-t="' . $tk . '" class="button' . ($tk === 'u' ? ' button-primary' : '') . '">' . esc_html($tn) . '</a>';
        echo '</div>';
        foreach ($tabs as $tk => $tn) echo '<div class="ms-pane' . ($tk === 'u' ? ' on' : '') . '" id="ms-t-' . $tk . '">' . ($sec[$tk] ?? '') . '</div>';
        echo '<script>(function(){var a=document.querySelectorAll(".ms-tabs a"),p=document.querySelectorAll(".ms-pane");function show(k){var ok=0;a.forEach(function(x){if(x.dataset.t===k)ok=1;});if(!ok)k="u";a.forEach(function(x){x.className="button"+(x.dataset.t===k?" button-primary":"");});p.forEach(function(x){x.className="ms-pane"+(x.id==="ms-t-"+k?" on":"");});try{localStorage.setItem("ms_tab",k);}catch(e){}}
a.forEach(function(x){x.addEventListener("click",function(e){e.preventDefault();show(x.dataset.t);});});var k="u";try{k=localStorage.getItem("ms_tab")||"u";}catch(e){}show(k);})();</script>';
        echo '<script>(function(){function v(t){t=t.trim();var m=t.match(/^(\\d+) min(?: (\\d+) s)?/);if(m)return m[1]*60+(+m[2]||0);m=t.match(/^(\\d+) s\\b/);if(m)return +m[1];var n=parseFloat(t.replace(/\\./g,"").replace(",","."));return isNaN(n)?t.toLowerCase():n;}
document.querySelectorAll(".ms-tbl").forEach(function(tb){var b=tb.tBodies[0];if(!b||b.rows.length<2)return;tb.querySelectorAll("th").forEach(function(th,i){if(!th.textContent.trim())return;th.style.cursor="pointer";th.title="Zum Sortieren klicken";th.addEventListener("click",function(){var d=th.dataset.d==="a"?-1:1;th.dataset.d=d>0?"a":"d";var r=[].slice.call(b.rows);r.sort(function(x,y){var p=v(x.cells[i]?x.cells[i].textContent:""),q=v(y.cells[i]?y.cells[i].textContent:"");if(typeof p==="number"&&typeof q!=="number")return -1;if(typeof q==="number"&&typeof p!=="number")return 1;return (p<q?-1:p>q?1:0)*d;});r.forEach(function(x){b.appendChild(x);});});});});})();</script>';
        echo '<script>(function(){var s=document.getElementById("ms-plim"),t=document.querySelector("#ms-produkte .ms-tbl");if(!s||!t||!t.tBodies[0])return;var lim=10;try{lim=+localStorage.getItem("ms_plim")||10;}catch(e){}s.value=String(lim);if(!s.value)s.value="10";function ap(){var r=t.tBodies[0].rows,n=+s.value;for(var i=0;i<r.length;i++)r[i].style.display=i<n?"":"none";}
s.onchange=function(){try{localStorage.setItem("ms_plim",s.value);}catch(e){}ap();};t.querySelectorAll("th").forEach(function(th){th.addEventListener("click",function(){setTimeout(ap,0);});});ap();})();</script>';
        echo '<p class="ms-note">' . (self::opts()['keep_days'] > 0 ? 'Einzeldaten werden nach ' . (int)self::opts()['keep_days'] . ' Tagen gelöscht.' : 'Einzeldaten werden unbegrenzt aufbewahrt (einstellbar).') . ' IP-Adressen werden nicht gespeichert. Interne Suchbegriffe und 404-Seiten stehen im Reiter „Suche & 404“ (Suchbegriffe aus Google gibt es nur in der Google Search Console). Klicks werden nur als Zielseite (Domain), Produktnummer, Linktext und Bild-Adresse erfasst, nie mit Partner-IDs oder Query-Strings. Derselbe Browser wird ' . (int)self::opts()['salt_days'] . ' Tage lang wiedererkannt, danach ändert sich die Kennung.</p>';
    }
}
Mini_Statistik::init();
